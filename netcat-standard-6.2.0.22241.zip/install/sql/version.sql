--
-- Дамп данных таблицы `Settings`
--

INSERT INTO `Settings` (`Key`, `Value`, `Module`, `Catalogue_ID`) VALUES ('SystemID', '2', 'system', 0);

INSERT INTO `Patch` (`Patch_Name`, `Created`, `Description`) VALUES ('620', '2022-08-30 00:00:00', 'Обновление системы 6.2.0.22241');
UPDATE `Settings` SET `Value` = '6.2.0' WHERE `Key` = 'VersionNumber' AND `Module` = 'system';
UPDATE `Settings` SET `Value` = '22241' WHERE `Key` = 'LastPatchBuildNumber' AND `Module` = 'system';
UPDATE `Settings` SET `Value` = 'master' WHERE `Key` = 'LastPatchType' AND `Module` = 'system';

