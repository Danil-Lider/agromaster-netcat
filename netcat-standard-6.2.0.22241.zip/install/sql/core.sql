SET sql_mode='';

--
-- Структура таблицы `Catalogue`
--

CREATE TABLE IF NOT EXISTS `Catalogue` (
  `Catalogue_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Catalogue_Name` varchar(255) NOT NULL DEFAULT '',
  `Domain` varchar(128) NOT NULL DEFAULT '',
  `Template_ID` int(11) NOT NULL DEFAULT '1',
  `TemplateSettings` text,
  `Read_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Write_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Mirrors` text NOT NULL,
  `Priority` int(11) DEFAULT NULL,
  `Checked` smallint(6) NOT NULL DEFAULT '0',
  `Edit_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Checked_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Delete_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Subscribe_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Moderation_ID` int(11) NOT NULL DEFAULT '0',
  `Title_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `E404_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Rules_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Auth_Cabinet_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Auth_Profile_Modify_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Auth_Signup_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Netshop_Cart_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Netshop_Order_Success_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Netshop_Order_List_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Netshop_Delivery_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Netshop_Compare_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Netshop_Favorites_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Search_Result_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LastModified` datetime DEFAULT NULL,
  `LastModifiedType` int(11) DEFAULT '1',
  `Robots` text,
  `DisallowIndexing` int(11) DEFAULT '0',
  `Description` text,
  `Keywords` text,
  `Language` varchar(255) NOT NULL DEFAULT 'en',
  `ncOfflineText` text,
  `ncMobile` int(1) DEFAULT NULL,
  `ncMobileSrc` int(4) DEFAULT NULL,
  `ncMobileRedirect` int(1) DEFAULT NULL,
  `ncMobileIdentity` varchar(255) NOT NULL DEFAULT 'ncUserScreen',
  `ncResponsive` int(1) unsigned NOT NULL DEFAULT '0',
  `DisplayType` enum('traditional','shortpage','longpage_vertical','longpage_horizontal') NOT NULL DEFAULT 'traditional',
  `ncHTTPS` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  `Default_Class_ID` int(11) NOT NULL DEFAULT 0,
  `MainArea_Mixin_Settings` BLOB,
  `ncMode` enum('template_development','normal','demo') NOT NULL DEFAULT 'normal',
  PRIMARY KEY (`Catalogue_ID`),
  UNIQUE KEY `Domain` (`Domain`),
  KEY `Checked` (`Checked`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Class`
--

CREATE TABLE IF NOT EXISTS `Class` (
  `Class_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Class_Name` varchar(255) NOT NULL DEFAULT '',
  `Class_Group` varchar(64) NOT NULL DEFAULT 'Main',
  `Keyword` VARCHAR(64) NOT NULL DEFAULT '',
  `ObjectNameSingular` varchar(255) DEFAULT '',
  `ObjectNamePlural` varchar(255) DEFAULT '',
  `DaysToHold` int(11) NOT NULL DEFAULT '0',
  `AllowTags` smallint(6) NOT NULL DEFAULT '0',
  `FormPrefix` text,
  `FormSuffix` text,
  `RecordTemplate` text,
  `RecordsPerPage` int(11) NOT NULL DEFAULT '20',
  `MinRecordsInInfoblock` int(11) DEFAULT NULL,
  `MaxRecordsInInfoblock` int(11) DEFAULT NULL,
  `SortBy` varchar(255) NOT NULL DEFAULT '',
  `RecordTemplateFull` text,
  `TitleTemplate` varchar(255) DEFAULT NULL,
  `TitleList` varchar(255) DEFAULT NULL,
  `UseAltTitle` tinyint(4) DEFAULT '0',
  `AddTemplate` text NOT NULL,
  `EditTemplate` text NOT NULL,
  `AddActionTemplate` text NOT NULL,
  `EditActionTemplate` text NOT NULL,
  `SearchTemplate` text NOT NULL,
  `FullSearchTemplate` text NOT NULL,
  `SubscribeTemplate` text NOT NULL,
  `System_Table_ID` int(11) NOT NULL DEFAULT '0',
  `Settings` text NOT NULL,
  `AddCond` text NOT NULL,
  `EditCond` text NOT NULL,
  `SubscribeCond` text NOT NULL,
  `DeleteCond` text NOT NULL,
  `NL2BR` tinyint(4) NOT NULL DEFAULT '1',
  `UseCaptcha` tinyint(4) NOT NULL DEFAULT '0',
  `CheckActionTemplate` text NOT NULL,
  `DeleteActionTemplate` text NOT NULL,
  `CustomSettingsTemplate` text,
  `ClassDescription` text,
  `DeleteTemplate` text NOT NULL,
  `ClassTemplate` int(10) unsigned NOT NULL DEFAULT '0',
  `Main_ClassTemplate_ID` int(10) unsigned NOT NULL DEFAULT '0',
  `Type` enum('rss','useful','admin_mode','inside_admin','xml','trash','title','mobile','multi_edit','responsive') DEFAULT 'useful',
  `File_Mode` tinyint(1) NOT NULL DEFAULT '0',
  `File_Path` varchar(255) DEFAULT NULL,
  `File_Hash` char(32) NOT NULL DEFAULT '',
  `Priority` int(11) NOT NULL DEFAULT 0,
  `FieldsInTableView` text NOT NULL DEFAULT '',
  `IsAuxiliary` tinyint(1) NOT NULL DEFAULT '0',
  `IsOptimizedForMultipleMode` tinyint(1) NOT NULL DEFAULT '0',
  `DisableBlockMarkup` tinyint(1) NOT NULL DEFAULT '0',
  `DisableBlockListMarkup` tinyint(1) NOT NULL DEFAULT '0',
  `ObjectName` char(64) NOT NULL DEFAULT '',
  `Index_Mixin_Preset_ID` int(11) UNSIGNED DEFAULT NULL,
  `IndexItem_Mixin_Preset_ID` int(11) UNSIGNED DEFAULT NULL,
  `IsMultipurpose` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
  `CompatibleFields` TEXT NOT NULL,
  PRIMARY KEY (`Class_ID`),
  KEY `Class_Group` (`Class_Group`),
  KEY `ClassTemplate` (`ClassTemplate`),
  KEY `Keyword` (`Keyword`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Class_Multipurpose_Template_Cache`
--

CREATE TABLE IF NOT EXISTS `Class_Multipurpose_Template_Cache` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Class_ID` int(11) NOT NULL,
  `Compatible_Class_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Compatibility` (`Class_ID`,`Compatible_Class_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Classificator`
--

CREATE TABLE IF NOT EXISTS `Classificator` (
  `Classificator_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Classificator_Name` char(32) NOT NULL DEFAULT '',
  `Table_Name` char(32) NOT NULL DEFAULT '',
  `System` smallint(6) NOT NULL DEFAULT '0',
  `Sort_Type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Sort_Direction` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `CustomSettingsTemplate` text NULL DEFAULT NULL,
  PRIMARY KEY (`Classificator_ID`),
  UNIQUE KEY `Table_Name` (`Table_Name`),
  KEY `System` (`System`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `Classificator`
--

INSERT INTO `Classificator` (`Classificator_Name`, `Table_Name`, `System`, `Sort_Type`, `Sort_Direction`) VALUES
('Тип данных', 'TypeOfData', 1, 0, 0),
('Публикация объектов', 'TypeOfModeration', 1, 0, 0),
('Тип прав', 'TypeOfRight', 1, 0, 0),
('Группы пользователей', 'UserGroup', 1, 0, 0),
('Тип редактирования поля', 'TypeOfEdit', 1, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `Classificator_TypeOfData`
--

CREATE TABLE IF NOT EXISTS `Classificator_TypeOfData` (
  `TypeOfData_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TypeOfData_Name` char(64) NOT NULL DEFAULT '',
  `TypeOfData_Priority` int(11) DEFAULT NULL,
  `Value` text,
  `Checked` int(1) DEFAULT '1',
  `CustomSettings` text NULL DEFAULT NULL,
  PRIMARY KEY (`TypeOfData_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `Classificator_TypeOfData`
--

INSERT INTO `Classificator_TypeOfData` (`TypeOfData_ID`, `TypeOfData_Name`, `TypeOfData_Priority`, `Value`, `Checked`) VALUES
(1, 'Строка', 1, NULL, 1),
(2, 'Целое число', 2, NULL, 1),
(3, 'Текстовый блок', 3, NULL, 1),
(4, 'Список', 4, NULL, 1),
(5, 'Логическая переменная (истина или ложь)', 5, NULL, 1),
(6, 'Файл', 6, NULL, 1),
(7, 'Число с плавающей запятой', 7, NULL, 1),
(8, 'Дата и время', 8, NULL, 1),
(9, 'Множественный список', 9, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Classificator_TypeOfEdit`
--

CREATE TABLE IF NOT EXISTS `Classificator_TypeOfEdit` (
  `TypeOfEdit_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TypeOfEdit_Name` char(64) NOT NULL DEFAULT '',
  `TypeOfEdit_Priority` int(11) DEFAULT NULL,
  `Value` text,
  `Checked` int(1) DEFAULT '1',
  `CustomSettings` text NULL DEFAULT NULL,
  PRIMARY KEY (`TypeOfEdit_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `Classificator_TypeOfEdit`
--

INSERT INTO `Classificator_TypeOfEdit` (`TypeOfEdit_ID`, `TypeOfEdit_Name`, `TypeOfEdit_Priority`, `Value`, `Checked`) VALUES
(1, 'Доступно всем', 1, NULL, 1),
(2, 'Доступно только администраторам', 2, NULL, 1),
(3, 'Недоступно никому', 3, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Classificator_TypeOfModeration`
--

CREATE TABLE IF NOT EXISTS `Classificator_TypeOfModeration` (
  `TypeOfModeration_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TypeOfModeration_Name` char(64) NOT NULL DEFAULT '',
  `TypeOfModeration_Priority` int(11) DEFAULT NULL,
  `Value` text,
  `Checked` int(1) DEFAULT '1',
  `CustomSettings` text NULL DEFAULT NULL,
  PRIMARY KEY (`TypeOfModeration_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `Classificator_TypeOfModeration`
--

INSERT INTO `Classificator_TypeOfModeration` (`TypeOfModeration_ID`, `TypeOfModeration_Name`, `TypeOfModeration_Priority`, `Value`, `Checked`) VALUES
(1, 'после добавления', 1, NULL, 1),
(2, 'после проверки администратором', 2, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Classificator_TypeOfRight`
--

CREATE TABLE IF NOT EXISTS `Classificator_TypeOfRight` (
  `TypeOfRight_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TypeOfRight_Name` char(64) NOT NULL DEFAULT '',
  `TypeOfRight_Priority` int(11) DEFAULT NULL,
  `Value` text,
  `Checked` int(1) DEFAULT '1',
  `CustomSettings` text NULL DEFAULT NULL,
  PRIMARY KEY (`TypeOfRight_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `Classificator_TypeOfRight`
--

INSERT INTO `Classificator_TypeOfRight` (`TypeOfRight_ID`, `TypeOfRight_Name`, `TypeOfRight_Priority`, `Value`, `Checked`) VALUES
(1, 'Директор', 1, NULL, 1),
(2, 'Супервизор', 2, NULL, 1),
(3, 'Администратор', 3, NULL, 1),
(4, 'Модератор', 4, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Classificator_UserGroup`
--

CREATE TABLE IF NOT EXISTS `Classificator_UserGroup` (
  `UserGroup_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserGroup_Name` char(64) NOT NULL DEFAULT '',
  `UserGroup_Priority` int(11) DEFAULT NULL,
  `Value` text,
  `Checked` int(1) DEFAULT '1',
  `CustomSettings` text NULL DEFAULT NULL,
  PRIMARY KEY (`UserGroup_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `Classificator_UserGroup`
--

INSERT INTO `Classificator_UserGroup` (`UserGroup_ID`, `UserGroup_Name`, `UserGroup_Priority`, `Value`, `Checked`) VALUES
(1, 'все', 1, NULL, 1),
(2, 'зарегистрированные', 2, NULL, 1),
(3, 'уполномоченные', 3, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `CronTasks`
--

CREATE TABLE IF NOT EXISTS `CronTasks` (
  `Cron_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Cron_Minutes` int(10) unsigned NOT NULL DEFAULT '0',
  `Cron_Hours` int(10) unsigned NOT NULL DEFAULT '0',
  `Cron_Days` int(10) unsigned NOT NULL DEFAULT '0',
  `Cron_Months` int(10) unsigned NOT NULL DEFAULT '0',
  `Cron_Weekdays` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Cron_Script_URL` varchar(255) NOT NULL DEFAULT '',
  `Cron_Launch` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`Cron_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `CronTasks`
--

INSERT INTO `CronTasks` (`Cron_Minutes`, `Cron_Hours`, `Cron_Days`, `Cron_Months`, `Cron_Weekdays`, `Cron_Script_URL`, `Cron_Launch`) VALUES
(1, 0, 0, 0, 0, '/netcat/admin/mailer.php?number=50', 1147433797);

--
-- Структура таблицы `Documentation`
--

CREATE TABLE IF NOT EXISTS `Documentation` (
  `Documentation_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Type` enum('function','variable','macros','method','static') NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Signature` text NOT NULL,
  `ShortHelp` text NOT NULL,
  `FullHelp` text NOT NULL,
  `Module_ID` int(11) DEFAULT NULL,
  `Parent` varchar(255) NOT NULL,
  `Areas` varchar(255) NOT NULL,
  PRIMARY KEY (`Documentation_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=93 ;

--
-- Дамп данных таблицы `Documentation`
--

INSERT INTO `Documentation` (`Type`, `Name`, `Signature`, `ShortHelp`, `FullHelp`, `Module_ID`, `Parent`, `Areas`) VALUES
('function', 'browse_messages', 'browse_messages ( $cc_env, $range )', '<p>\r\n	Отображает блок навигации по страницам списка объектов компонента в формате «1 2 3 &gt;&gt;».</p>', '<p>Массив $cc_env является неизменным параметром данной функции и содержит переменные окружения текущего компонента раздела. Параметр $range определяет количество выводимых страниц. Вместо этой переменной обычно пишется число. Подразумевается, что из множества страниц одновременно будет показываться только список из $range страниц. Например, ваш листинг состоит из 20 страниц. Если $range=10, то, находясь на первой странице, вы будете видеть страницы с 1 по 10, находясь на 15-й странице, вы будете видеть страницы 10-20. Для настройки формата отображения используется массив $browse_msg[], значения которого указываются в настройках макета дизайна. Макропеременная %PAGE обозначает номер страницы, макропеременная %URL – ссылку на соответствующие страницы. Возможно также использование макропеременных %FROM и %TO, соответственно обозначающих номера начального и конечного объекта на странице.</p>\r\n<pre><code class=''language-php''>$browse_msg[prefix] = ""; // Префикс перед блоком навигации\r\n$browse_msg[suffix] = ""; // Суффикс после блока навигации\r\n$browse_msg[active] = "%PAGE"; // Формат вывода текущей страницы\r\n$browse_msg[unactive] = "<a href=%URL>%PAGE</a>"; // Формат вывода ссылок\r\n$browse_msg[divider] = " "; // Разделитель между ссылками</code></pre>', NULL, '', 'ClassForm_FormPrefix ClassForm_RecordTemplate ClassForm_FormSuffix ClassForm_RecordTemplateFull ClassForm_Settings'),
('function', 'nc_browse_cc', 'nc_browse_cc ( $template )', 'Выводит список ссылок по компонентам раздела в соответствии с шаблоном $template.', '', NULL, '', 'TemplateForm'),
('function', 'nc_browse_sub', 'nc_browse_sub( $browse_parent_sub, $browse_template, $ignore_check = 0, $where_cond = "", $level = 0 )', 'Выводит список подразделов раздела $parent_sub в соответствии с шаблоном $template.', 'C помощью флага $ignore_check можно игнорировать вывод только включённых разделов ( если $ignore_check равен 1, то выведутся все разделы ). С помощью $where_cond можно дополнить запрос в секции WHERE.', NULL, '', 'TemplateForm'),
('function', 'nc_browse_level', 'nc_browse_level( $level, $browse_template )', 'Выводит список разделов уровня $level в соответствии с шаблоном $template.', 'Обратите внимание, что нумерация уровней начинается с нуля, т.е. Для вывода списка разделов верхнего уровня первый параметр функции должна быть равен нулю.', NULL, '', 'TemplateForm'),
('function', 'nc_browse_path', 'nc_browse_path( $browse_template )', 'Выводит навигацию типа "хлебные крошки" (путь до текущей страницы) в соответствии с шаблоном $template.', '', NULL, '', 'TemplateForm'),
('function', 'nc_browse_catalogue', 'nc_browse_catalogue( $browse_template )', 'Функция выводит список сайтов (блок навигации) в соответствии с\r\nшаблоном, описанным в хэш-массиве $template', '<div>\r\n	Массив должен иметь&nbsp;элементы со следующими индексами:</div>\r\n<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Индексы</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					prefix</td>\r\n				<td>\r\n					выводится перед списком</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					suffix</td>\r\n				<td>\r\n					выводится после списка</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					active</td>\r\n				<td>\r\n					шаблон вывода активного элемента списка (а данном случае это&nbsp;касается текущего сайта)</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					active_link</td>\r\n				<td>\r\n					шаблон вывода активного элемента списка в том случае, если ссылка&nbsp;на этот элемент идентична адресу текущей страницы</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					unactive</td>\r\n				<td>\r\n					<div>\r\n						шаблон вывода неактивного элемента списка (в данном случае это&nbsp;касается всех сайтов, кроме текущего)</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					divider</td>\r\n				<td>\r\n					шаблон разделителя между элементами списка</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					sortby</td>\r\n				<td>\r\n					признак сортировки элементов</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	&nbsp;</p>', NULL, '', 'TemplateForm'),
('function', 'nc_browse_path_range', 'nc_browse_path_range( $from, $to, $browse_template, $reverse = 0, $show = 0 )', 'Функция аналогична s_browse_path(), но выводит только путь указанного\r\nдиапазона (минимальное значение $from – (-1), максимальное значение\r\n$to - $sub_level_count), в соответствии с шаблоном, описанным в\r\nмассиве $template.', '', NULL, '', 'TemplateForm'),
('function', 'nc_put_field', 'nc_put_field (string $field_name, [string $style, [int $classID, [bool $caption]]] )', 'Функция генерирует поле любого типа.', '<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры&nbsp;</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					параметры отображения поля, например: «size=''50'' class=''my_field''»</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					<div>\r\n						идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					<div>\r\n						выводить или не выводить описание над генерируемым полем</div>\r\n				</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_list_field', 'nc_list_field ( string $field_name, [string $style, [int $classID, [bool $caption, [mixed $selected, [mixed $disabled, [bool $ignore_check]]]]]] )', 'Функция генерирует поле типа «Список».', '<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					<div>\r\n						параметры отображения поля, например:&nbsp;«class=''my_field''»</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					<div>\r\n						идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить или не выводить описание над генерируемым полем</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$selected&nbsp;(опционально)&nbsp;</td>\r\n				<td>\r\n					выбранный элемент списка</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$disabled&nbsp;(опционально)</td>\r\n				<td>\r\n					выключенный элемент списка</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$ignore_check&nbsp;(опционально)</td>\r\n				<td>\r\n					игнорировать выборку только включенных</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>\r\n<p>\r\n	&nbsp;</p>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_file_field', 'nc_file_field ( string $field_name, [string $style, [int $classID, [bool $caption]]] )', 'Функция генерирует поле типа «Файл».', '<div>\r\n	В большинстве случаев она</div>\r\n<div>\r\n	применяется в альтернативных формах компонента, чтобы вывести информацию о поле типа Файл.</div>\r\n<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить или не выводить описание над генерируемым полем</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$selected&nbsp;(опционально)</td>\r\n				<td>\r\n					выбранный элемент списка</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$disabled&nbsp;(опционально)</td>\r\n				<td>\r\n					выключенный элемент списка</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$ignore_check&nbsp;(опционально)</td>\r\n				<td>\r\n					игнорировать выборку только включенных</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_bool_field', 'nc_bool_field ( string $field_name, [string $style, [int $classID, [bool $caption]]] )', 'Функция генерирует поле типа «Логическая переменная».', '<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить или не выводить описание над генерируемым полем</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_date_field', 'nc_date_field ( string $field_name, [string $style, [int $classID, [bool $caption, [string $dateDiv, [string $timeDiv]]]]] )', 'Функция генерирует поле типа «Дата и время».', '<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить или не выводить описание над генерируемым полем</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$dateDiv&nbsp;(опционально)</td>\r\n				<td>\r\n					разделитель полей для даты, по умолчанию "-"</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$timeDiv&nbsp;(опционально)</td>\r\n				<td>\r\n					разделитель полей для времени, по умолчанию ":"</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_text_field', 'nc_text_field ( string $field_name, [string $style, [int $classID, [bool $caption, [bool $bbcode]]]] )', 'Функция генерирует поле типа «Текстовый блок».', '<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить или не выводить описание над генерируемым полем</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$bbcode&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить панельку с BB-кодами (для панельки нужны стили CSS в&nbsp;макете дизайна!), по умолчанию отключено</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_string_field', 'nc_string_field ( string $field_name, [string $style, [int $classID, [bool $caption]]] )', 'Функция генерирует поле типа «Строка».', '<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить или не выводить описание над генерируемым полем</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_int_field', 'nc_int_field ( string $field_name, [string $style, [int $classID, [bool $caption]]] )', 'Функция генерирует поле типа «Целое число».', '<div>\r\n	<table>\r\n		<thead>\r\n			<tr>\r\n				<th scope="col">\r\n					Параметры</th>\r\n				<th scope="col">\r\n					Описание</th>\r\n			</tr>\r\n		</thead>\r\n		<tbody>\r\n			<tr>\r\n				<td>\r\n					$field_name</td>\r\n				<td>\r\n					имя поля в текущем компоненте или компоненте $classID</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$style&nbsp;(опционально)</td>\r\n				<td>\r\n					параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$classID&nbsp;(опционально)</td>\r\n				<td>\r\n					идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n					$caption&nbsp;(опционально)</td>\r\n				<td>\r\n					выводить или не выводить описание над генерируемым полем</td>\r\n			</tr>\r\n		</tbody>\r\n	</table>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_float_field', 'nc_float_field ( string $field_name, [string $style, [int $classID, [bool $caption]]] )', 'Функция генерирует поле типа «Число с плавающей запятой».', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$field_name</td>\r\n			<td>\r\n				имя поля в текущем компоненте или компоненте $classID</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$style&nbsp;(опционально)</td>\r\n			<td>\r\n				параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$classID</td>\r\n			<td>\r\n				идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$caption</td>\r\n			<td>\r\n				выводить или не выводить описание над генерируемым полем</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_multilist_field', 'nc_multilist_field ( string $field_name, [string $style, [string $type, [int $classID, [bool $caption, [string $selected, [bool $disabled, [bool $getData]]]]]] )', 'Функция генерирует поле типа «Множественный выбор»', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$field_name</td>\r\n			<td>\r\n				имя поля в текущем компоненте или компоненте $classID</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$style&nbsp;(опционально)</td>\r\n			<td>\r\n				параметры отображения поля, например:&nbsp;«size=''50''»</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$type (опционально)</td>\r\n			<td>\r\n				тип: "select", "select:N", "checkbox", по умолчанию - "select:3"</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$classID (опционально)</td>\r\n			<td>\r\n				идентификатор компонента, используется например, при выводе&nbsp;формы через функцию s_list_class() его следует указывать, по&nbsp;умолчанию этот параметр можно не задавать</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$caption (опционально)</td>\r\n			<td>\r\n				&nbsp;выводить или не выводить описание над генерируемым полем</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$selected (опционально)</td>\r\n			<td>\r\n				выбранные элементы. Передаются через строку, где id выбранных&nbsp;элементов разделены между собой символами ''[пробел]'', ''.'', '','' , '';''</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$disabled &nbsp;(опционально)</td>\r\n			<td>\r\n				недоступные&nbsp;элементы.&nbsp;Формат&nbsp;аргумента&nbsp;аналогичен</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				<div>\r\n					$getData&nbsp;(опционально)</div>\r\n			</td>\r\n			<td>\r\n				принудительно вытаскивать из базы</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_list_select', 'nc_list_select (string $classificator_name, [string $field_name, [int $current_value, [int $sort_type, [int $sort_direction, [string $template_prefix, [string $template_object, [string $template_suffix, [string $template_any, [bool $ignore_check]]]]]]]]])', 'Данная функция позволяет генерировать HTML списки из Списков\r\nNetCat.', '<p>\r\n	В большинстве случаев она применяется в альтернативных формах компонента, чтобы вывести информацию о поле типа Список.</p>\r\n<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$classificator_name</td>\r\n			<td>\r\n				имя списка, например, Gallery, обязательный параметр</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$field_name имя&nbsp;(опционально)</td>\r\n			<td>\r\n				поля в компоненте (без префикса f_, например, Field)</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$current_value (опционально)</td>\r\n			<td>\r\n				выбранный элемент списка&nbsp;(например, $f_Field_id, если мы используем функцию в&nbsp;альтернативной форме добавления/изменения)</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$sort_type (опционально)</td>\r\n			<td>\r\n				поле сортировки: 0 – ID (по умолчанию), 1 – имя, 2 - приоритет</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$sort_direction (опционально)</td>\r\n			<td>\r\n				порядок сортировки: 0 – восходящий (по умолчанию), 1 –&nbsp;нисходящий)</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$template_prefix (опционально)</td>\r\n			<td>\r\n				темплейт префикса списка, по умолчанию: "&lt;select name=''f_\\$field_name''&gt;\\r\\n"</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$template_suffix (опционально)</td>\r\n			<td>\r\n				темплейт суффикса списка, по умолчанию: "&lt;/select&gt;\\r\\n"</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$template_any (опционально)</td>\r\n			<td>\r\n				темплейт для первого нулевого элемента списка, если поле&nbsp;может быть пустым, по умолчанию:&nbsp;&lt;option value=''''&gt;--выбрать--&lt;/option&gt;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$ignore_check</td>\r\n			<td>\r\n				игнорировать выборку только включенных</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	<strong>Внимание!</strong> Не забывайте экранировать кавычки!</p>\r\n<div>\r\n	<div>\r\n		Поле $template_prefix имеет «константу». Переменная, а точнее запись</div>\r\n	<div>\r\n		вида «\\$field_name», автоматически заменится на указанный в вызове</div>\r\n	<div>\r\n		функции параметр $field_name.</div>\r\n	<div>\r\n		Поле $template_object имеет 3 «константы»: «\\$value_id», «\\</div>\r\n	<div>\r\n		$value_selected» и «\\$value_name», которые отвечают за подстановку ID,</div>\r\n	<div>\r\n		выбранной записи и название элемента.</div>\r\n</div>', NULL, '', 'ClassForm_AddTemplate ClassForm_AddCond ClassForm_AddActionTemplate ClassForm_EditTemplate ClassForm_EditCond ClassForm_EditActionTemplate ClassForm_CheckActionTemplate'),
('function', 'nc_message_link', 'nc_message_link ( int $message_id, int $class_id, [$action=''''] )', 'Функция позволяет получить относительный путь к объекту (без домена)\r\nпо номеру (ID) этого объекта и номеру (ID) компонента, которому он\r\nпринадлежит.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$message_id</td>\r\n			<td>\r\n				номер объекта</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$class_id</td>\r\n			<td>\r\n				номер компонента</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$action&nbsp;(опционально)</td>\r\n			<td>\r\n				действие с объектом:<br />\r\n				edit — редактирование<br />\r\n				delete — удаление<br />\r\n				drop — удаление без подтверждения<br />\r\n				checked — смена статуса,<br />\r\n				по умолчанию — просмотр&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; .</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	Будьте внимательны, не путайте номера компонента и номер компонента раздела. Номер компонента Вы можете узнать, например, в разделе «Список компонентов» системы администрирования.</p>', NULL, '', 'ClassForm TemplateForm'),
('function', 'parentofmessage', 'parentofmessage ( int $message_id, int $class_id )', 'Возвращает номер объекта – родителя «ветки» объектов (может\r\nиспользоваться в иерархическом форуме), в которой, в частности,\r\nсодержится объект с номером $message_id.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$message_id</td>\r\n			<td>\r\n				номер объекта</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$class_id</td>\r\n			<td>\r\n				номер компонента</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm TemplateForm'),
('function', 's_list_class', 's_list_class ( int $sub, int $cc, [char $params, [bool $show_in_admin_mode]] )', '<div>\r\n	Функция выводит "верхние" объекты из раздела $sub компонента раздела $cc с параметрами $params.</div>', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$sub</td>\r\n			<td>\r\n				номер раздела</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$cc</td>\r\n			<td>\r\n				номер компонента в разделе</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$params&nbsp;(опционально)</td>\r\n			<td>\r\n				может содержать произвольный состав параметров. Все они&nbsp;могут быть обработаны в тексте шаблона вывода объекта.&nbsp;Параметры подаются в URL-формате: &amp;param1=12&amp;param2=46.</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$show_in_admin_mode (опционально)&nbsp;</td>\r\n			<td>\r\n				если он имеет значение TRUE (истина), этот блок будет выведен&nbsp;и в режиме администрирования, иначе только в обычном режиме&nbsp;работы сайта</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_usergroup_create', 'nc_usergroup_create ( string $name )', 'Функция создает группу пользователей именем $name.', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_usergroup_rename', 'nc_usergroup_rename ( int $PermissionGroupID, string $name )', 'Функция переименовывает группу пользователей.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$PermissionGroupID</td>\r\n			<td>\r\n				идентификатор группы</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$name</td>\r\n			<td>\r\n				имя группы</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_usergroup_delete', 'nc_usergroup_delete ( mixed $PermissionGroupID )', 'Функция удаляет группу(-ы) пользователей по идентификатору группы\r\nили массиву с идентификаторами групп $PermissionGroupID.', 'Группу нельзя удалить, если есть хотя бы один пользователь, который\r\nсостоит только в этой группе. Функция возвращает массив с номерами\r\nудаленных групп.', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_usergroup_add_to_group', 'nc_usergroup_add_to_group ( int $UserID, int $PermissionGroupID )', 'Функция добавляет пользователя в группу.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$UserID</td>\r\n			<td>\r\n				идентификатор пользователя</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$PermissionGroupID</td>\r\n			<td>\r\n				идентификатор группы&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_usergroup_remove_from_group', 'nc_usergroup_remove_from_group ( int $UserID, int $PermissionGroupID )', 'Функция исключает пользователя из группы. (Пользователь должен\r\nсостоять хотя бы в одной группе.)', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$UserID</td>\r\n			<td>\r\n				идентификатор пользователя</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$PermissionGroupID</td>\r\n			<td>\r\n				идентификатор группы</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_usergroup_get_users_from_group', 'nc_usergroup_get_users_from_group ( int $PermissionGroupID , [int $output_type])', 'Функция возвращает всех пользователей, находящихся в группе\r\nPermissionGroupID.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$PermissionGroupID</td>\r\n			<td>\r\n				идентификатор группы</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$output_type&nbsp;(опционально)</td>\r\n			<td>\r\n				тип выходного массива:<br />\r\n				&nbsp;0: просто номера пользователей [0] =&gt; user1 id, [1] =&gt; user2&nbsp;id<br />\r\n				1: [group_id][user_id] =&gt; Login</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_usergroup_get_group_by_user', 'nc_usergroup_get_group_by_user ( int $UserID , int $output_type = 0 )', 'Функция возвращает все группы, в которых состоит пользователь.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$UserID</td>\r\n			<td>\r\n				идентификатор пользователя</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$output_type&nbsp;(опционально)</td>\r\n			<td>\r\n				тип выходного массива:<br />\r\n				0:&nbsp;на выходе одномерный числовой массив, значения&nbsp;элементов которых соответствует идентификатором групп<br />\r\n				1: на выходе одномерный массив, значения элементов&nbsp;которых соответствует названиям групп, а&nbsp;индекс -&nbsp;номерам групп</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', NULL, '', 'ClassForm TemplateForm'),
('function', 'is_even', 'is_even ( int $param )', '<p>Проверяет параметр на четность.</p>', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'listQuery', 'listQuery (char $sql_query, [char $output_template, [char $divider]] )', '<p>Функция производит запрос $sql_query к базе данных, форматирует в\r\nсоответствии с шаблоном $output_template и выводит\r\nрезультаты\r\nзапроса.</p>', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$sql_query</td>\r\n			<td>\r\n				запрос к БД</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$output_template&nbsp;(опционально)&nbsp;</td>\r\n			<td>\r\n				шаблон вывода результатов запроса</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$divider (опционально)&nbsp;</td>\r\n			<td>\r\n				разделитель между результатами</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	В шаблоне $output_template могут использоваться обращения к массиву $data[] с маскировочным слешем перед знаком $: \\$data[Name].</p>\r\n<p>\r\n	В качестве индексов массива используются названия столбцов таблиц, из которых происходит выборка.</p>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_bbcode', 'nc_bbcode ( string $text, [string $cut_link, [bool $cut_full, [array $codes]]] )', 'Обрабатывает текст с BB-кодами.', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_bbcode_bar', 'nc_bbcode_bar ( string $winID, string $formID, string $textareaID, [bool $help, [array $codes="", [string $prefix="", [string $suffix=""]]]] )', 'Отображает панельку вставки BB-кодов.', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_bbcode_clear', 'nc_bbcode_clear ( string $text )', 'Функция очистки текста от BB-кодов (кроме URL).', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_array_to_string', 'nc_array_to_string ( array $arr, array $template )', 'Переводит массив в строку по шаблону.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$arr</td>\r\n			<td>\r\n				непосредственно сам массив</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$template</td>\r\n			<td>\r\n				массив с шаблонами, должен иметь следующие ключи:<br />\r\n				prefix<br />\r\n				element<br />\r\n				divider<br />\r\n				suffix</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<div>\r\n	В элементе с ключом element можно использовать макропеременные:</div>\r\n<div>\r\n	1. %ELEMENT - текущий элемент массива $arr</div>\r\n<div>\r\n	2. %KEY - его ключ</div>\r\n<div>\r\n	3. %I - номер по порядку (отсчет начинается с 1 )</div>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_mail2queue', 'nc_mail2queue ( string $recipient, string $from, string $subject, string $message )', 'Функция является частью функционала по рассылке писем. Указанное\r\nписьмо кладется в таблицу БД mail_queue, откуда в дальнейшем будет\r\nразослано скриптом /netcat/admin/mailer.php.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$recipient</td>\r\n			<td>\r\n				содержит адрес получателя</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$from</td>\r\n			<td>\r\n				содержит координаты отправителя</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$subject</td>\r\n			<td>\r\n				тема письма</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$message</td>\r\n			<td>\r\n				сообщение&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	При желании Вы можете отсылать даже письма с файлами – для этого при помощи каких-либо средств необходимо сгенерировать правильный $message. Однако учтите, что письмо кладется в БД ровно столько раз, сколько подписчиков его должны получить, и при большом вложенном файле размер БД может значительно вырасти.</p>\r\n<p>\r\n	Файл /netcat/admin/mailer.php, отвечает за порционную рассылку писем. Количество писем задается параметром number, если не указано – высылается 20 писем из очереди. Этот скрипт должен быть добавлен в CRON Вашего сервера (каждую минуту, /netcat/admin/mailer.php?number=20). При наличии писем в очереди они будут отсылаться порциями. При отсутствии писем скрипт ничего делать не будет.</p>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_file_path', 'nc_file_path ( int $class_id, int $message_id, mixed $field_name, [string $file_name_prefix] )', 'Функция позволяет получить путь к файлу, указанному в определенном\r\nполе, по номеру (ID) этого объекта и номеру (ID) компонента, которому\r\nон принадлежит.', '<table>\r\n	<thead>\r\n		<tr>\r\n			<th scope="col">\r\n				Параметры</th>\r\n			<th scope="col">\r\n				Описание</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				$class_id</td>\r\n			<td>\r\n				номер компонента (для системных таблиц – название&nbsp;таблицы, допустимые значения – “Catalogue”, “Subdivision”,&nbsp;“User”, “Template”)</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$message_id</td>\r\n			<td>\r\n				номер объекта</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$field_name</td>\r\n			<td>\r\n				название поля или его идентификатор в компоненте</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n				$file_name_prefix (опционально)&nbsp;</td>\r\n			<td>\r\n				укажите “h_”, если хотите получить ссылку для скачивания&nbsp;файла под оригинальным именем (подробнее см. в&nbsp;разделе «Файловая система» настоящего руководства)</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	Будьте внимательны, не путайте номера компонента и номер компонента в разделе. Номер компонента вы можете узнать, например, в разделе «Список компонентов» системы администрирования.</p>\r\n<p>\r\n	Если в указанном поле файл не был закачан, функция возвращает NULL. При неправильно указанном имени или идентификаторе поля функция сообщит об ошибке и вернет NULL.</p>', NULL, '', 'ClassForm TemplateForm'),
('function', 'nc_get_visual_settings', 'nc_get_visual_settings ( int $cc )', 'Функция возвращает текущие визуальные настройки компонента в\r\nразделе по его идентификатору $cc.', 'Возвращаемый результат — массив данных.', NULL, '', 'ClassForm TemplateForm'),
('function', 'opt', 'opt ( $flag, $string )', 'Функция выводит строку $string в случае если $flag не ложь, не имеет\r\nпустое значение или не ноль.', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'opt_case', 'opt_case ( $flag, $string1, $string2 )', 'Выводит строку $string1 в случае если $flag не ложь, не имеет пустое\r\nзначение или не ноль; в противном случае выводит строку $string2.', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'encode_host', 'encode_host ( string $host )', '<p>Функция возвращает закодированное в punycode значение параметра\r\n$host, содержащее доменное имя.</p>', '', NULL, '', 'ClassForm TemplateForm'),
('function', 'decode_host', 'decode_host ( string $host )', '<p>Функция возвращает декодированное значение параметра\r\n$host содержащее доменное имя в формате punycode.</p>', '', NULL, '', 'ClassForm TemplateForm'),
('variable', 'cc', 'cc', 'Номер (ID) текущего инфоблока.', 'Переменной присваивается значение поля Sub_Class_ID таблицы Sub_Class, соответствующее текущему инфоблоку.', NULL, '', 'ClassForm TemplateForm'),
('variable', 'cc_array[]', 'cc_array', 'Массив номеров инфоблоков в текущем разделе.', 'Массив индексов (номеров) компонентов текущего раздела, отсортированных по приоритету. Нулевой элемент ($cc_array[0]) – компонент с наименьшим приоритетом.', NULL, '', 'ClassForm TemplateForm');
INSERT INTO `Documentation` (`Type`, `Name`, `Signature`, `ShortHelp`, `FullHelp`, `Module_ID`, `Parent`, `Areas`) VALUES
('variable', 'admin_mode', 'admin_mode', 'Определение текущего режима страницы.', 'Логическая переменная. Если страница находится в режиме просмотра, то равна FALSE, если в режиме администирования - TRUE.', NULL, '', 'ClassForm TemplateForm'),
('variable', 'catalogue', 'catalogue', 'Номер (ID) текущего сайта.', 'Переменной присваивается значение поля Catalogue_ID таблицы Catalogue, соответствующее текущему сайту.', NULL, '', 'ClassForm TemplateForm'),
('variable', 'AUTH_USER_ID', 'AUTH_USER_ID', 'Номер авторизованного пользователя.', 'Номер (ID) в таблице User пользователя, авторизованного на странице. Если посетитель не авторизован, содержит 0.', NULL, '', 'ClassForm TemplateForm'),
('variable', 'current_catalogue[]', 'current_catalogue', 'Массив свойств текущего сайта.', 'Хэш-массив всех свойств текущего сайта (атрибутов таблицы Catalogue). Пример: $current_catalogue[''Catalogue_ID''].', NULL, '', 'ClassForm TemplateForm'),
('variable', 'current_cc[]', 'current_cc', 'Массив свойств текущего раздела.', 'Хэш-массив всех свойств текущего сайта (атрибутов таблицы Sub_Class). Пример: $current_cc[''Sub_Class_Name''].', NULL, '', 'ClassForm TemplateForm'),
('variable', 'current_sub[]', 'current_sub', 'Массив свойств текущего раздела.', 'Хэш-массив всех свойств текущего сайта (атрибутов таблицы Subdivision). Пример: $current_sub[''Subdivision_Name''].', NULL, '', 'ClassForm TemplateForm'),
('variable', 'current_user[]', 'current_user', 'Массив свойств текущего раздела.', 'Хэш-массив всех свойств текущего сайта (атрибутов таблицы User). Пример: $current_user[''Login'']. Массив определен только в случае, когда посетитель авторизован на сайте (то есть при наличии модуля "Личный кабинет"). Если модуля нет, номер авторизованного пользователя хранится в переменной $AUTH_USER_ID.', NULL, '', 'ClassForm TemplateForm'),
('variable', 'nc_parent_template_folder_path', 'nc_parent_template_folder_path', 'URI папки макета дизайна.', 'Переменная содержит относительную ссылку (URI) на папку текущего макета дизайна (или корневого макета, если текущий макет является дочерним, а не корневым). В этой папке и/или ее подпапках рекомендуется хранить картинки, CSS-файлы и пр., необходимые для работы макета.', NULL, '', 'TemplateForm'),
('variable', 'template_settings[]', 'template_settings', 'Массив, содержащий пользовательские настройки макета.', 'Если у макета заданы пользовательские настройки, этот хэш-массив содержит их значение (эти значения проставляются в настройках сайта или раздела, к которому подключен макет).', NULL, '', 'TemplateForm'),
('macros', 'NAME', 'NAME', 'Название раздела.', '', NULL, '', 'TemplateForm_Settings'),
('macros', 'Footer', 'Footer', 'Вывод футера родительского макета.', 'Если макет имеет родителя, эта макропеременная будет содержать текст футера (нижней части) родительского макета.', NULL, '', 'TemplateForm_Header TemplateForm_Footer'),
('macros', 'Header', 'Header', 'Вывод хедера родительского макета.', 'Если макет имеет родителя, эта макропеременная будет содержать текст хедера (верхней части) родительского макета.', NULL, '', 'TemplateForm_Header TemplateForm_Footer'),
('variable', 'begRow', 'begRow', 'Порядковый номер объекта, с которого начинается вывод списка объектов на текущей странице.', 'Нумерация начинается с первого объекта на первой странице. Таким образом, если объекты какого-либо компонента выводятся по 15 штук на странице, на второй странице листинга значение $begRow будет равно 16.', NULL, '', 'ClassForm_FormPrefix ClassForm_RecordTemplate ClassForm_FormSuffix ClassForm_RecordTemplateFull'),
('macros', 'URL', 'URL', 'Ссылка на сайт/раздел/компонент.', '', NULL, '', 'TemplateForm_Settings'),
('macros', 'PARENT_SUB', 'PARENT_SUB', 'Номер родительского раздела (только для разделов).', '', NULL, '', 'TemplateForm_Settings'),
('macros', 'KEYWORD', 'KEYWORD', 'Ключевое слово раздела (только для разделов).', '', NULL, '', 'TemplateForm_Settings'),
('macros', 'SUB', 'SUB', 'Номер раздела (только для разделов).', '', NULL, '', 'TemplateForm_Settings'),
('macros', 'COUNTER', 'COUNTER', 'Номер выводимого элемента в списке (начиная с нуля).', '', NULL, '', 'TemplateForm_Settings'),
('variable', 'ccLink', 'ccLink', 'Содержит путь (URI) к текущему инфоблоку.', '', NULL, '', 'ClassForm_RecordTemplate'),
('variable', 'f_AdminCommon', 'f_AdminCommon', 'Панелька управления инфоблоком.', 'В режиме администрирования выводит панельку операций с инфоблоком: добавление объекта, настройка инфоблока, редактирование текста шаблона компонента, удаления объектов. Если в шаблоне вывода объекта в списке эта переменная указана не будет, вы не сможете изменить или удалить объекты этого компонента стандартными средствами системы.', NULL, '', 'ClassForm_FormPrefix ClassForm_RecordTemplate ClassForm_FormSuffix ClassForm_RecordTemplateFull'),
('variable', 'endRow', 'endRow', 'Порядковый номер объекта, которым кончается вывод списка объектов на текущей странице.', 'Нумерация начинается с первого объекта на первой странице. Таким образом, если объекты какого-либо компонента выводятся по 15 штук на странице, на второй странице листинга значение $endRow будет равно 30.', NULL, '', 'ClassForm_FormPrefix ClassForm_RecordTemplate ClassForm_FormSuffix ClassForm_RecordTemplateFull'),
('variable', 'f_AdminButtons', 'f_AdminButtons', 'Панелька управления объектом.', 'В режиме администрирования выводит панельку операций с объектами: изменения, удаления, включения-выключения, копирования. Если в шаблоне вывода объекта в списке или объекта на одной странице эта переменная указана не будет, вы не сможете изменить или удалить объекты этого компонента стандартными средствами системы.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_Checked', 'f_Checked', 'Истина, если объект включен, и наоборот.', 'Используется в шаблоне вывода объекта в списке и на отдельной странице.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_Created', 'f_Created', 'Дата и время создания объекта.', 'Дата и время создания (добавления) объекта в формате "гггг-мм-дд чч:мм:сс". Помимо полного формата вывода даты и времени доступны переменные $f_Created_year, $f_Created_month, $f_Created_day, $f_Created_hours, $f_Created_minutes, $f_Created_seconds, содержащие соответственно год, месяц, день, час, минуту и секунду добавления объекта. Используется в шаблоне вывода объекта в списке и на отдельной странице.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_IP', 'f_IP', 'IP-адрес посетителя, добавившего объект.', 'Используется в шаблоне вывода объекта в списке и на отдельной странице.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_LastIP', 'f_LastIP', 'IP-адрес посетителя, последним изменившего объект.', '', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_LastUpdated', 'f_LastUpdated', 'Дата и время последнего изменения этого объекта.', 'Используется в шаблоне вывода объекта в списке и на отдельной странице.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_LastUserAgent', 'f_LastUserAgent', 'UserAgent пользователя, последним изменившего объект.', 'Используется в шаблоне вывода объекта в списке и на отдельной странице.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_LastUserID', 'f_LastUserID', 'Номер пользователя, последним изменившего объект.', '', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_RowID', 'f_RowID', 'Номер (ID) объекта в таблице БД (MessageXX).', 'Используется в шаблоне вывода объекта в списке и на отдельной странице.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'f_RowNum', 'f_RowNum', 'Порядковый номер объекта на странице.', 'Нумерация начинается с первого объекта, отображенного на странице. Используется в шаблоне вывода объекта в списке и на отдельной странице.', NULL, '', 'ClassForm_RecordTemplate'),
('variable', 'f_title', 'f_title', 'Заголовок текущей страницы.', 'Выводит название текущего раздела за исключением случая, когда текущая страница представляет собой вывод одного объекта на странице и поле «Заголовок страницы» данного компонента определено.', NULL, '', 'TemplateForm'),
('variable', 'nc_next_object', 'nc_next_object', 'Ссылка на следующий объект в списке.', 'Данная переменная содержит ссылку на "следующий" объект относительно текущего. Для определения порядка объектов используется переменная $query_order из системных настройках, а если она не задана — то значение поля "Сортировать объекты по" в настройках инфоблока.', NULL, '', 'ClassForm_RecordTemplate'),
('variable', 'nc_prev_object', 'nc_prev_object', 'Ссылка на предыдущий объект в списке.', 'Данная переменная содержит ссылку на "предыдущий" объект относительно текущего. Для определения порядка объектов используется переменная $query_order из системных настройках, а если она не задана — то значение поля "Сортировать объекты по" в настройках инфоблока.', NULL, '', 'ClassForm_RecordTemplate'),
('variable', 'fullDateLink ', 'fullDateLink', 'Ссылка на страницу с полным выводом объекта в виде\r\n«.../2002/02/02/message_2.html».', 'Устанавливается в случае если в компоненте имеется поле типа «Дата и время» с форматом «event»,иначе значение переменной идентично значению $fullLink.', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'fullLink', 'fullLink', 'Ссылка на страницу с полным выводом объекта.', 'Ссылка формируется в «человеко-понятном» формате: /URLРаздела/КлючСловоКомпонентаРаздела_КлючСловоОбъекта.html или /URLРаздела/КлючСловоОбъекта.html, например, /about/team/ivanov.html', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'editLink', 'editLink', 'Ссылка на страницу редактирования объекта.', '', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'deleteLink', 'deleteLink', 'Ссылка на страницу удаления объекта.', '', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'dropLink', 'dropLink', 'Ссылка на страницу удаления объекта без подтверждения.', '', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'checkedLink', 'checkedLink', 'Ссылка на страницу включения-выключения объекта.', '', NULL, '', 'ClassForm_RecordTemplate ClassForm_RecordTemplateFull'),
('variable', 'prevLink', 'prevLink', 'Переменная содержит ссылку на следующую страницу в листинге компонента.', 'Если текущее положение в списке – его конец, то переменная пустая.', NULL, '', 'ClassForm_RecordTemplate'),
('variable', 'nextLink', 'nextLink', 'Переменная содержит ссылку на следующую страницу в листинге компонента.', 'Если текущее положение в списке – его конец, то\r\nпеременная пустая.', NULL, '', 'ClassForm_RecordTemplate'),
('variable', 'parent_sub_tree[]', 'parent_sub_tree', 'Массивы свойств раздела различных уровней вложенности в реверсивном порядке.', 'От текущего раздела $parent_sub_tree[0] до свойств головного сайта $parent_sub_tree[$sub_level_count-1].', NULL, '', 'ClassForm TemplateForm'),
('variable', 'recNum', 'recNum', 'Максимальное количество объектов для вывода.', 'Переменную можно подать в адресной строке (/news/?recNum=3), в функции s_list_class(), в системных настройках компонента.', NULL, '', 'ClassForm_RecordTemplate'),
('variable', 'sub', 'sub', 'Номер(ID) текущего раздела.', '', NULL, '', 'ClassForm TemplateForm'),
('variable', 'sub_level_count', 'sub_level_count', 'Переменная содержит текущий уровень вложенности навигации.', '', NULL, '', 'TemplateForm'),
('variable', 'subHost', 'subHost', 'Переменная содержит текущий хост (домен) вида «www.company.ru».', '', NULL, '', 'ClassForm TemplateForm'),
('variable', 'subLink', 'subLink', 'Переменная содержит URI текущего раздела вида «/about/news/».', '', NULL, '', 'ClassForm TemplateForm'),
('variable', 'totRows', 'totRows', 'Содержит общее количество объектов данного компонента раздела.', '', NULL, '', 'ClassForm_FormPrefix ClassForm_RecordTemplate ClassForm_FormSuffix ClassForm_RecordTemplateFull');

--
-- Структура таблицы `Field`
--

CREATE TABLE IF NOT EXISTS `Field` (
  `Field_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Class_ID` int(11) NOT NULL DEFAULT '0',
  `Field_Name` char(64) NOT NULL DEFAULT '',
  `Description` char(255) NOT NULL DEFAULT '',
  `TypeOfData_ID` int(11) NOT NULL DEFAULT '1',
  `Format` text DEFAULT NULL,
  `Extension` text NOT NULL DEFAULT '',
  `NotNull` smallint(6) NOT NULL DEFAULT '1',
  `Priority` int(11) NOT NULL DEFAULT '0',
  `DoSearch` smallint(6) NOT NULL DEFAULT '1',
  `DefaultState` char(255) DEFAULT NULL,
  `Inheritance` smallint(6) NOT NULL DEFAULT '0',
  `System_Table_ID` int(11) NOT NULL DEFAULT '0',
  `Widget_Class_ID` int(11) NOT NULL DEFAULT '0',
  `TypeOfEdit_ID` int(11) NOT NULL DEFAULT '1',
  `Checked` tinyint(1) NOT NULL DEFAULT '1',
  `InTableView` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Field_ID`),
  KEY `TypeOfData_ID` (`TypeOfData_ID`),
  KEY `System_Table_ID` (`System_Table_ID`),
  KEY `Widget_Class_ID` (`Widget_Class_ID`),
  KEY `TypeOfEdit_ID` (`TypeOfEdit_ID`),
  KEY `Class_ID_2` (`Class_ID`,`TypeOfData_ID`),
  KEY `Checked` (`Checked`),
  KEY `netshop_field_index` (`Field_Name`, `Class_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Структура таблицы `Filetable`
--

CREATE TABLE IF NOT EXISTS `Filetable` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Real_Name` text NOT NULL,
  `Virt_Name` char(32) NOT NULL DEFAULT '',
  `File_Path` char(64) NOT NULL DEFAULT '',
  `File_Type` char(64) DEFAULT NULL,
  `File_Size` int(10) unsigned NOT NULL DEFAULT '0',
  `Message_ID` int(10) unsigned NOT NULL DEFAULT '0',
  `Field_ID` int(10) unsigned NOT NULL DEFAULT '0',
  `Content_Disposition` int(1) DEFAULT '0',
  `Download` int(11) NOT NULL DEFAULT '0',
  `Deleted` int(1) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `File_Path` (`File_Path`),
  KEY `Field_ID` (`Field_ID`),
  KEY `Message_ID_2` (`Message_ID`,`Field_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `MailTmp`
--

CREATE TABLE IF NOT EXISTS `MailTmp` (
  `MailTmp_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Subject` text,
  `Message` text,
  PRIMARY KEY (`MailTmp_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Mail_Attachment`
--

CREATE TABLE `Mail_Attachment` (
  `Mail_Attachment_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Type` varchar(255) NOT NULL,
  `Filename` text,
  `Extension` varchar(10) NOT NULL,
  `Content_Type` varchar(100) NOT NULL,
  `Path` text,
  PRIMARY KEY (`Mail_Attachment_ID`)
)ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Mail_Queue`
--

CREATE TABLE IF NOT EXISTS `Mail_Queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `time_to_send` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sent_time` datetime DEFAULT NULL,
  `id_user` bigint(20) NOT NULL DEFAULT '0',
  `ip` varchar(20) NOT NULL DEFAULT 'unknown',
  `sender` varchar(50) NOT NULL DEFAULT '',
  `recipient` varchar(50) NOT NULL DEFAULT '',
  `headers` text NOT NULL,
  `body` longtext NOT NULL,
  `try_sent` tinyint(4) NOT NULL DEFAULT '0',
  `delete_after_send` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `time_to_send` (`time_to_send`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Mixin_Preset` (
  `Mixin_Preset_ID` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Mixin_Preset_Name` VARCHAR(255),
  `Mixin_Settings` BLOB,
  `Class_Template_ID` INT(11) UNSIGNED NOT NULL DEFAULT '0',
  `Scope` ENUM('Index', 'IndexItem', 'Full' /*, 'Add', 'Delete', 'Edit', 'Search', 'Subscribe' */) NOT NULL DEFAULT 'index',
  PRIMARY KEY (`Mixin_Preset_ID`),
  KEY `Class_Template_ID` (`Class_Template_ID`)
);

-- --------------------------------------------------------

--
-- Структура таблицы `Module`
--

CREATE TABLE IF NOT EXISTS `Module` (
  `Module_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Module_Name` varchar(255) NOT NULL DEFAULT '',
  `Keyword` varchar(255) NOT NULL DEFAULT '',
  `Description` text NOT NULL,
  `Parameters` text NOT NULL,
  `Example_URL` varchar(255) NOT NULL DEFAULT '',
  `Help_URL` varchar(255) NOT NULL DEFAULT '',
  `Installed` tinyint(4) NOT NULL DEFAULT '0',
  `Number` varchar(16) NOT NULL DEFAULT '',
  `Inside_Admin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `PerSitePermissions` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Checked` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`Module_ID`),
  KEY `Checked` (`Checked`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Module_Catalog`
--

CREATE TABLE IF NOT EXISTS `Module_Catalog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Module_ID` int(11) NOT NULL,
  `Catalogue_ID` int(11) NOT NULL,
  `Inside_Admin` int(4) NOT NULL,
  `Checked` int(4) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Module_ID` (`Module_ID`),
  KEY `Catalogue_ID` (`Catalogue_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Multifield`
--

CREATE TABLE IF NOT EXISTS `Multifield` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Field_ID` int(10) unsigned NOT NULL,
  `Message_ID` int(10) unsigned NOT NULL,
  `Priority` int(10) unsigned DEFAULT NULL,
  `Name` text,
  `Size` int(10) unsigned NOT NULL,
  `Path` text,
  `Preview` text,
  PRIMARY KEY (`ID`),
  KEY `ixField_ID` (`Field_ID`),
  KEY `ixMessage_ID` (`Message_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Patch`
--

CREATE TABLE IF NOT EXISTS `Patch` (
  `Patch_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Patch_Name` char(32) NOT NULL DEFAULT '',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Description` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`Patch_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `Patch`
--

-- INSERT INTO `Patch` (`Patch_Name`, `Created`, `Description`) VALUES
-- ('540', '2014-07-01 00:00:00', 'Обновление системы 5.4.0');

--
-- Структура таблицы `Permission`
--

CREATE TABLE IF NOT EXISTS `Permission` (
  `Permission_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL DEFAULT '0',
  `AdminType` int(11) NOT NULL DEFAULT '0',
  `Catalogue_ID` int(11) NOT NULL DEFAULT '0',
  `PermissionSet` int(11) NOT NULL DEFAULT '0',
  `PermissionGroup_ID` int(11) NOT NULL DEFAULT '0',
  `PermissionBegin` datetime DEFAULT NULL,
  `PermissionEnd` datetime DEFAULT NULL,
  PRIMARY KEY (`Permission_ID`),
  KEY `User_ID` (`User_ID`),
  KEY `AdminType` (`AdminType`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `Permission`
--

INSERT INTO `Permission` (`Permission_ID`, `User_ID`, `AdminType`, `Catalogue_ID`, `PermissionSet`, `PermissionGroup_ID`, `PermissionBegin`, `PermissionEnd`) VALUES
(1, 1, 7, 0, 0, 0, NULL, NULL);

--
-- Структура таблицы `PermissionGroup`
--

CREATE TABLE IF NOT EXISTS `PermissionGroup` (
  `PermissionGroup_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PermissionGroup_Name` char(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`PermissionGroup_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `PermissionGroup`
--

INSERT INTO `PermissionGroup` (`PermissionGroup_ID`, `PermissionGroup_Name`) VALUES
(1, 'Администраторы'),
(2, 'Внешние пользователи');

--
-- Структура таблицы `Permission`
--

CREATE TABLE IF NOT EXISTS `Module_Permission` (
  `Module_Permission_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL DEFAULT '0',
  `PermissionGroup_ID` int(11) NOT NULL DEFAULT '0',
  `Catalogue_ID` int(11) NOT NULL DEFAULT '0',
  `Module_Keyword` varchar(255),
  `PermissionType` varchar(255),
  `PermissionBegin` datetime DEFAULT NULL,
  `PermissionEnd` datetime DEFAULT NULL,
  PRIMARY KEY (`Module_Permission_ID`),
  KEY `User_ID` (`User_ID`),
  KEY `PermissionGroup_ID` (`PermissionGroup_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

--
-- Структура таблицы `Redirect`
--

CREATE TABLE IF NOT EXISTS `Redirect` (
  `Redirect_ID` int(11) NOT NULL AUTO_INCREMENT,
  `OldURL` varchar(255) NOT NULL DEFAULT '',
  `NewURL` varchar(255) NOT NULL DEFAULT '',
  `Header` int(3) DEFAULT '301',
  `Group_ID` int(11) DEFAULT 1,
  `Checked` int(3) DEFAULT 1,
  PRIMARY KEY (`Redirect_ID`),
  UNIQUE KEY `OldURL` (`OldURL`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `Redirect`
--

INSERT INTO `Redirect` (`OldURL`, `NewURL`, `Header`, `Group_ID`, `Checked`) VALUES
('example.net/about/*/vasya/*/', 'example.net/*2/*1/', 301, 1, 1),
('example.net/url/*/index.html', 'example.net/url/index.html', 301, 1, 1);

--
-- Структура таблицы `Redirect_Group`
--

CREATE TABLE IF NOT EXISTS `Redirect_Group` (
  `Redirect_Group_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Redirect_Group_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `Redirect_Group`
--

INSERT INTO `Redirect_Group` (`Redirect_Group_ID`, `Name`) VALUES
(1, 'Основная группа');
--
-- Структура таблицы `Session`
--

CREATE TABLE IF NOT EXISTS `Session` (
  `Session_ID` char(32) NOT NULL DEFAULT '',
  `User_ID` int(11) NOT NULL DEFAULT '0',
  `SessionStart` int(11) NOT NULL DEFAULT '0',
  `SessionTime` int(11) NOT NULL DEFAULT '0',
  `UserIP` bigint(11) NOT NULL DEFAULT '0',
  `LoginSave` tinyint(1) NOT NULL DEFAULT '0',
  `Catalogue_ID` int(11) NOT NULL DEFAULT '0',
  `Subdivision_ID` int(11) NOT NULL DEFAULT '0',
  `AuthVariant` int(11) DEFAULT '1',
  PRIMARY KEY (`Session_ID`),
  KEY `User_ID` (`User_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Settings`
--

CREATE TABLE IF NOT EXISTS `Settings` (
  `Settings_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Key` varchar(255) NOT NULL,
  `Value` text NOT NULL,
  `Module` varchar(255) NOT NULL DEFAULT 'system',
  `Catalogue_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Settings_ID`),
  KEY `Catalogue_ID` (`Catalogue_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `Settings`
--

INSERT INTO `Settings` (`Key`, `Value`, `Module`, `Catalogue_ID`) VALUES
('VersionNumber', '6.2', 'system', 0),
('UserEmailField', 'Email', 'system', 0),
('PatchCheck', '0', 'system', 0),
('LastPatch', '0', 'system', 0),
('LastPatchBuildNumber', '', 'system', 0),
('LastPatchType', '', 'system', 0),
('EditDesignTemplateID', '2', 'system', 0),
('EditorType', '3', 'system', 0),
('InlineEditConfirmation', '0', 'system', 0),
('CkeditorEmbedEditor', '1', 'system', 0),
('CkeditorPanelFull', '1', 'system', 0),
('CkeditorPanelInline', '2', 'system', 0),
('AdminButtons', '', 'system', 0),
('AdminCommon', '', 'system', 0),
('AdminButtonsType', '', 'system', 0),
('AdminParameters', '', 'system', 0),
('RemindSave', '1', 'system', 0),
('PacketOperations', '', 'system', 0),
('TextareaResize', '', 'system', 0),
('DisableBlockMarkup', '0', 'system', 0),
('QuickBar', '1', 'system', 0),
('SyntaxEditor', '1', 'system', 0),
('UseToken', '4', 'system', 0),
('AdminNoticeResponse', 'a:6:{s:10:"next_patch";i:0;s:3:"lic";i:1;s:7:"support";i:0;s:8:"linkcopy";s:42:"https://netcat.ru/forclients/my/copies/";s:7:"crpatch";i:0;s:11:"crpatchlink";s:0:"";}', 'system', 0),
('TrashUse', '1', 'system', 0),
('TrashLimit', '20', 'system', 0),
('FieldUsage', 'a:12:{s:13:"last_modified";s:12:"LastModified";s:18:"last_modified_type";s:16:"LastModifiedType";s:8:"language";s:8:"Language";s:8:"keywords";s:8:"Keywords";s:11:"description";s:11:"Description";s:5:"title";s:5:"Title";s:15:"sitemap_include";s:16:"IncludeInSitemap";s:18:"sitemap_changefreq";s:17:"SitemapChangefreq";s:16:"sitemap_priority";s:15:"SitemapPriority";s:9:"smo_title";s:11:"ncSMO_Title";s:15:"smo_description";s:17:"ncSMO_Description";s:9:"smo_image";s:11:"ncSMO_Image";}', 'system', 0),
('CKEditorSkin', 'moono', 'system', 0),
('ProductNumber', '', 'system', 0),
('ProjectName', 'Мой сайт', 'system', 0),
('SpamFromName', 'admin', 'system', 0),
('SpamFromEmail', '', 'system', 0),
('SpamMailAdditionalParameters', '-f%s', 'system', 0),
('Code', '', 'system', 0),
('SecretKey', 'd41d8cd98f00b204e9800998ecf8427e', 'system', 0),
('CKEditorFileSystem', '', 'system', 0),
('CMEmbeded', '1', 'system', 0),
('CMDefault', '1', 'system', 0),
('CMAutocomplete', '1', 'system', 0),
('CMHelp', '1', 'system', 0),
('JSLoadjQueryDollar', '1', 'system', 0),
('JSLoadjQueryExtensionsAlways', '1', 'system', 0),
('JSLoadModulesScripts', '1', 'system', 0),
('MinifyStaticFiles', '1', 'system', 0),
('AutosaveType', 'keyboard', 'system', 0),
('AutosavePeriod', '60', 'system', 0),
('AutosaveNoActive', '1', 'system', 0),
('InlineImageCropUse', '0', 'system', 0),
('DragMode', 'confirm', 'system', 0),
('SecurityInputFilterSQL', '4', 'system', 0),
('SecurityInputFilterPHP', '4', 'system', 0),
('SecurityInputFilterXSS', '4', 'system', 0),
('SecurityFilterEmailAlertEnabled', '1', 'system', 0),
('SecurityFilterEmailAlertAddress', '', 'system', 0),
('AuthCaptchaEnabled', '1', 'system', 0),
('AuthCaptchaAttempts', '3', 'system', 0),
('ExportLimitSize', '200', 'system', 0),
('StoreVersions', '0', 'system', 0);


--
-- Структура таблицы `SQLQueries`
--

CREATE TABLE IF NOT EXISTS `SQLQueries` (
  `SQL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `SQL_text` text,
  UNIQUE KEY `SQL_ID` (`SQL_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Subdivision`
--

CREATE TABLE IF NOT EXISTS `Subdivision` (
  `Subdivision_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` int(11) NOT NULL DEFAULT '0',
  `Parent_Sub_ID` int(11) NOT NULL DEFAULT '0',
  `Subdivision_Name` varchar(255) NOT NULL DEFAULT '',
  `Template_ID` int(11) DEFAULT NULL,
  `ExternalURL` varchar(255) DEFAULT NULL,
  `EnglishName` varchar(64) NOT NULL DEFAULT '',
  `LastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LastModified` datetime DEFAULT NULL,
  `LastModifiedType` int(11) DEFAULT '0',
  `Hidden_URL` varchar(255) NOT NULL DEFAULT '',
  `Read_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Write_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Priority` int(11) DEFAULT NULL,
  `Checked` smallint(6) NOT NULL DEFAULT '0',
  `Edit_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Checked_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Delete_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Subscribe_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Moderation_ID` int(11) NOT NULL DEFAULT '0',
  `Favorite` smallint(6) NOT NULL DEFAULT '0',
  `TemplateSettings` text,
  `UseMultiSubClass` tinyint(1) NOT NULL DEFAULT '1',
  `UseEditDesignTemplate` tinyint(1) NOT NULL DEFAULT '0',
  `DisallowIndexing` int(11) DEFAULT '-1',
  `Description` text,
  `Keywords` text,
  `Title` varchar(255) DEFAULT NULL,
  `ncH1` varchar(255) DEFAULT NULL,
  `ncImage` TEXT,
  `ncIcon` TEXT,
  `ncSMO_Title` VARCHAR(255) NULL DEFAULT NULL,
  `ncSMO_Description` TEXT,
  `ncSMO_Image` TEXT,
  `Language` varchar(255) DEFAULT NULL,
  `DisplayType` enum('inherit', 'traditional','shortpage','longpage_vertical','longpage_horizontal') NOT NULL DEFAULT 'inherit',
  `LabelColor` varchar(6) DEFAULT NULL,
  `MainArea_Mixin_Settings` BLOB,
  `ncDisallowMoveAndDelete` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`Subdivision_ID`),
  UNIQUE KEY `Hidden_URL` (`Catalogue_ID`,`Parent_Sub_ID`,`EnglishName`),
  KEY `Parent_Sub_ID` (`Parent_Sub_ID`),
  KEY `Checked` (`Checked`),
  UNIQUE KEY `Catalogue_ID_Hidden_URL` (`Catalogue_ID`, `Hidden_URL`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Sub_Class`
--

CREATE TABLE IF NOT EXISTS `Sub_Class` (
  `Sub_Class_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Subdivision_ID` int(11) NOT NULL DEFAULT '0',
  `AreaKeyword` varchar(255) NOT NULL DEFAULT '',
  `Class_ID` int(11) NOT NULL DEFAULT '0',
  `Parent_Sub_Class_ID` int(11) NOT NULL DEFAULT '0',
  `Sub_Class_Name` varchar(255) NOT NULL DEFAULT '',
  `Priority` int(11) NOT NULL DEFAULT '0',
  `Read_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Write_Access_ID` int(11) NOT NULL DEFAULT '0',
  `EnglishName` varchar(64) DEFAULT NULL,
  `Checked` smallint(6) NOT NULL DEFAULT '0',
  `Catalogue_ID` int(11) NOT NULL DEFAULT '0',
  `Edit_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Checked_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Delete_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Subscribe_Access_ID` int(11) NOT NULL DEFAULT '0',
  `Moderation_ID` int(11) NOT NULL DEFAULT '0',
  `DaysToHold` int(11) DEFAULT NULL,
  `AllowTags` int(11) NOT NULL DEFAULT '-1',
  `RecordsPerPage` int(11) DEFAULT NULL,
  `MinRecordsInInfoblock` int(11) DEFAULT NULL,
  `MaxRecordsInInfoblock` int(11) DEFAULT NULL,
  `SortBy` varchar(255) NOT NULL DEFAULT 'a.`Priority` ASC, a.`Message_ID` ASC',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DefaultAction` enum('index','add','search','subscribe') NOT NULL DEFAULT 'index',
  `NL2BR` tinyint(4) NOT NULL DEFAULT '-1',
  `UseCaptcha` tinyint(4) NOT NULL DEFAULT '-1',
  `CustomSettings` text,
  `Class_Template_ID` int(10) unsigned NOT NULL DEFAULT '0',
  `isNaked` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `AllowRSS` tinyint(4) DEFAULT '0',
  `AllowXML` tinyint(4) DEFAULT '0',
  `SrcMirror` int(11) NOT NULL DEFAULT '0',
  `Edit_Class_Template` int(11) NOT NULL,
  `Admin_Class_Template` int(11) NOT NULL DEFAULT '0',
  `TableViewMode` tinyint(1)  NOT NULL DEFAULT '0',
  `Condition` text NOT NULL,
  `ConditionQuery` text NOT NULL,
  `ConditionOffset` int(11) NOT NULL DEFAULT '0',
  `ConditionLimit` int(11) DEFAULT NULL,
  `Index_Mixin_Preset_ID` int(11) NOT NULL DEFAULT '-1',
  `Index_Mixin_Settings` blob,
  `Index_Mixin_BreakpointType` enum('block', 'viewport') NOT NULL DEFAULT 'block',
  `IndexItem_Mixin_Preset_ID` int(11) NOT NULL DEFAULT '-1',
  `IndexItem_Mixin_Settings` blob,
  `IndexItem_Mixin_BreakpointType` enum('block', 'viewport') NOT NULL DEFAULT 'block',
  `AreaCondition_Action_Add` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `AreaCondition_Action_Delete` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `AreaCondition_Action_Edit` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `AreaCondition_Action_Full` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `AreaCondition_Action_Index` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `AreaCondition_Action_Search` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `AreaCondition_Action_Subscribe` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `IsMainContainer` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `ncDisallowMoveAndDelete` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `HasFilter` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`Sub_Class_ID`),
  UNIQUE KEY `EnglishName` (`Catalogue_ID`,`Subdivision_ID`,`EnglishName`),
  KEY `Class_ID` (`Class_ID`),
  KEY `Checked` (`Checked`),
  KEY `Catalogue_Area` (`Catalogue_ID`, `AreaKeyword`),
  KEY `Class_Template_ID` (`Class_Template_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Sub_Class_AreaCondition_Subdivision` (
  `Condition_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Sub_Class_ID` int(11) NOT NULL,
  `Subdivision_ID` int(11) NOT NULL,
  `IncludeChildren` tinyint(1) UNSIGNED DEFAULT '0',
  PRIMARY KEY (`Condition_ID`),
  UNIQUE KEY (`Sub_Class_ID`, `Subdivision_ID`)
);

CREATE TABLE IF NOT EXISTS `Sub_Class_AreaCondition_Subdivision_Exception` (
  `Condition_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Sub_Class_ID` int(11) NOT NULL,
  `Subdivision_ID` int(11) NOT NULL,
  `IncludeChildren` tinyint(1) UNSIGNED DEFAULT '0',
  PRIMARY KEY (`Condition_ID`),
  UNIQUE KEY (`Sub_Class_ID`, `Subdivision_ID`)
);

CREATE TABLE IF NOT EXISTS `Sub_Class_AreaCondition_Class` (
  `Condition_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Sub_Class_ID` int(11) NOT NULL,
  `Class_ID` int(11) NOT NULL,
  PRIMARY KEY (`Condition_ID`),
  UNIQUE KEY (`Sub_Class_ID`, `Class_ID`)
);

CREATE TABLE IF NOT EXISTS `Sub_Class_AreaCondition_Class_Exception` (
  `Condition_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Sub_Class_ID` int(11) NOT NULL,
  `Class_ID` int(11) NOT NULL,
  PRIMARY KEY (`Condition_ID`),
  UNIQUE KEY (`Sub_Class_ID`, `Class_ID`)
);

CREATE TABLE IF NOT EXISTS `Sub_Class_AreaCondition_Message` (
  `Condition_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Sub_Class_ID` int(11) NOT NULL,
  `Class_ID` int(11) NOT NULL,
  `Message_ID` int(11) NOT NULL,
  PRIMARY KEY (`Condition_ID`),
  UNIQUE KEY (`Sub_Class_ID`, `Class_ID`, `Message_ID`)
);

-- --------------------------------------------------------

--
-- Структура таблицы `SystemMessage`
--

CREATE TABLE IF NOT EXISTS `SystemMessage` (
  `SystemMessage_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Description` varchar(255) NOT NULL DEFAULT '',
  `Checked` tinyint(4) NOT NULL DEFAULT '0',
  `Message` text NOT NULL,
  PRIMARY KEY (`SystemMessage_ID`),
  KEY `Checked` (`Checked`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `System_Table`
--

CREATE TABLE IF NOT EXISTS `System_Table` (
  `System_Table_ID` int(11) NOT NULL AUTO_INCREMENT,
  `System_Table_Name` char(32) NOT NULL DEFAULT '',
  `System_Table_Rus_Name` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`System_Table_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `System_Table`
--

INSERT INTO `System_Table` (`System_Table_ID`, `System_Table_Name`, `System_Table_Rus_Name`) VALUES
(1, 'Catalogue', 'TOOLS_SYSTABLE_SITES'),
(2, 'Subdivision', 'TOOLS_SYSTABLE_SECTIONS'),
(3, 'User', 'TOOLS_SYSTABLE_USERS'),
(4, 'Template', 'TOOLS_SYSTABLE_TEMPLATE');

--
-- Структура таблицы `Template`
--

CREATE TABLE IF NOT EXISTS `Template` (
  `Template_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Keyword` VARCHAR(64) NOT NULL DEFAULT '',
  `Description` varchar(64) NOT NULL DEFAULT '',
  `Parent_Template_ID` int(11) NOT NULL DEFAULT '0',
  `Settings` text NOT NULL,
  `CustomSettings` text,
  `Header` text NOT NULL,
  `Footer` text NOT NULL,
  `File_Mode` tinyint(1) NOT NULL DEFAULT '0',
  `File_Path` varchar(255) DEFAULT NULL,
  `File_Hash` char(32) NOT NULL DEFAULT '',
  `Priority` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Template_ID`),
  KEY `Keyword` (`Keyword`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `Template`
--

INSERT INTO `Template` (`Template_ID`, `Keyword`, `Description`, `Parent_Template_ID`, `Settings`, `CustomSettings`, `Header`, `Footer`, `File_Mode`, `File_Path`, `File_Hash`) VALUES
(1, 'netcat_default', 'Универсальный макет Netcat 6', 0, '', '', '', '', 1, '/netcat_default/', '85a5c32b2423855b0f09061890798c0b'),
(2, 'netcat_inside_admin', 'Редактирование объектов', 0, '', '', '', '', 1, '/netcat_inside_admin/', 'aa0a5a3739a0b69ed720abd4c0bb53c8');
--
-- Структура таблицы `Template_Partial`
--

CREATE TABLE IF NOT EXISTS `Template_Partial` (
  `Template_Partial_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Template_ID` int(11) NOT NULL,
  `Keyword` varchar(64) NOT NULL,
  `Description` varchar(255) NOT NULL DEFAULT '',
  `EnableAsyncLoad` tinyint(1) UNSIGNED DEFAULT '0',
  PRIMARY KEY (`Template_Partial_ID`),
  UNIQUE KEY `Keyword` (`Template_ID`, `Keyword`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Структура таблицы `Trash_Data`
--

CREATE TABLE IF NOT EXISTS `Trash_Data` (
  `Trash_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Type` int(3) NOT NULL,
  `Message_ID` int(11) NOT NULL,
  `Class_ID` int(11) NOT NULL,
  `Subdivision_ID` int(11) NOT NULL,
  `Sub_Class_ID` int(11) NOT NULL,
  `System_Table_ID` int(3) NOT NULL,
  `Created` datetime NOT NULL,
  `XML_Filename` char(255) DEFAULT NULL,
  `XML_Filesize` int(10) NOT NULL,
  `IP` char(15) DEFAULT NULL,
  `UserAgent` char(255) DEFAULT NULL,
  `User_ID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Trash_ID`),
  KEY `User_ID` (`User_ID`),
  KEY `Message_ID` (`Message_ID`),
  KEY `Class_ID` (`Class_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Password` varchar(45) NOT NULL DEFAULT '',
  `PermissionGroup_ID` int(11) NOT NULL,
  `Checked` tinyint(4) NOT NULL DEFAULT '0',
  `Language` varchar(255) NOT NULL DEFAULT 'Russian',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Confirmed` tinyint(4) NOT NULL DEFAULT '0',
  `RegistrationCode` varchar(255) NOT NULL DEFAULT '',
  `Keyword` varchar(255) DEFAULT NULL,
  `Catalogue_ID` int(11) NOT NULL DEFAULT '0',
  `InsideAdminAccess` tinyint(4) NOT NULL DEFAULT '0',
  `Auth_Hash` text,
  `UserType` enum('normal','pseudo','vk','fb','twitter','openid', 'oauth') NOT NULL DEFAULT 'normal',
  `Email` char(255) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `ncAttemptAuth` int DEFAULT 0,
  PRIMARY KEY (`User_ID`),
  KEY `PermissionGroup_ID` (`PermissionGroup_ID`),
  KEY `Checked` (`Checked`),
  KEY `Confirmed` (`Confirmed`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- (не относится к модулю auth несмотря на название)
--

CREATE TABLE IF NOT EXISTS `Auth_FailedAttempt` (
  `RemoteHash` char(32),
  `LastAttempt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `AttemptCount` int(11),
  PRIMARY KEY (`RemoteHash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Дамп данных таблицы `Field`
--

INSERT INTO `Field` (`Class_ID`, `Field_Name`, `Description`, `TypeOfData_ID`, `Format`, `NotNull`, `Priority`, `DoSearch`, `DefaultState`, `Inheritance`, `System_Table_ID`, `Widget_Class_ID`, `TypeOfEdit_ID`, `Checked`) VALUES
(0, 'Email', 'Email', 1, 'email', 1, 2, 1, '', 0, 3, 0, 1, 1),
(0, 'Name', 'Имя пользователя', 1, '', 0, 3, 1, '', 0, 3, 0, 1, 1);
--
-- Дамп данных таблицы `User`
--

INSERT INTO `User` (`User_ID`, `Password`, `PermissionGroup_ID`, `Checked`, `Language`, `Created`, `LastUpdated`, `Email`, `Confirmed`, `RegistrationCode`, `Keyword`, `Name`, `Catalogue_ID`, `InsideAdminAccess`, `Auth_Hash`, `UserType`) VALUES
(1, '', 1, 1, 'Russian', NOW(), NOW(), '', 0, '', '', 'admin@example.com', 0, 1, NULL, 'normal');

--
-- Структура таблицы `User_Group`
--

CREATE TABLE IF NOT EXISTS `User_Group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) NOT NULL,
  `PermissionGroup_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `User_ID` (`User_ID`),
  KEY `PermissionGroup_ID` (`PermissionGroup_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `User_Group`
--

INSERT INTO `User_Group` (`ID`, `User_ID`, `PermissionGroup_ID`) VALUES
(1, 1, 1);


CREATE TABLE `Block_Widget` (
  `Block_Widget_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` int(11) NOT NULL,
  `Priority` int(11) NOT NULL,
  `Checked` smallint(6) NOT NULL DEFAULT '1',
  `Widget_ID` int(11) NOT NULL,
  `Widget_Class_ID` int(11) NOT NULL,
  `Block_Key` varchar(64) NOT NULL DEFAULT '',
  `LastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Widget_Settings` text,
  PRIMARY KEY (`Block_Widget_ID`),
  KEY `Catalogue_ID` (`Catalogue_ID`),
  KEY `Block_Key` (`Block_Key`),
  KEY `Widget_ID` (`Widget_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Структура таблицы `Widget`
--

CREATE TABLE IF NOT EXISTS `Widget` (
  `Widget_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Widget_Class_ID` int(11) NOT NULL DEFAULT '0',
  `Name` varchar(255) NOT NULL,
  `Keyword` varchar(255) NOT NULL,
  `Result` text NOT NULL,
  `User_ID` int(11) NOT NULL DEFAULT '0',
  `LastUser_ID` int(11) NOT NULL DEFAULT '0',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Widget_ID`),
  KEY `Widget_Class_ID` (`Widget_Class_ID`),
  KEY `User_ID` (`User_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Widget_Class`
--

CREATE TABLE IF NOT EXISTS `Widget_Class` (
  `Widget_Class_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Keyword` varchar(255) NOT NULL,
  `Description` text,
  `Category` text,
  `InDevelop` tinyint(4) NOT NULL DEFAULT '0',
  `Template` text NOT NULL,
  `Settings` text NOT NULL,
  `AddForm` text NOT NULL,
  `EditForm` text NOT NULL,
  `User_ID` int(11) NOT NULL DEFAULT '0',
  `LastUser_ID` int(11) NOT NULL DEFAULT '0',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LastUpdated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `WidgetDisallow` tinyint(4) NOT NULL DEFAULT '0',
  `Update` int(11) NOT NULL DEFAULT '0',
  `File_Mode` tinyint(1) NOT NULL DEFAULT '0',
  `File_Path` varchar(255) DEFAULT NULL,
  `AfterSaveAction` text NOT NULL DEFAULT '',
  `BeforeSaveAction` text NOT NULL DEFAULT '',
  `IsStatic` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`Widget_Class_ID`),
  KEY `User_ID` (`User_ID`),
  KEY `LastUser_ID` (`LastUser_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Widget_Field`
--

CREATE TABLE IF NOT EXISTS `Widget_Field` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Widget_ID` int(11) NOT NULL DEFAULT '0',
  `Field_ID` int(11) NOT NULL DEFAULT '0',
  `Value` text,
  PRIMARY KEY (`ID`),
  KEY `Widget_ID` (`Widget_ID`),
  KEY `Field_ID` (`Field_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Wysiwyg_Panel`
--

CREATE TABLE IF NOT EXISTS `Wysiwyg_Panel` (
  `Wysiwyg_Panel_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Toolbars` longtext NOT NULL,
  `RemoveButtons` longtext NOT NULL,
  `Editor` ENUM( 'ckeditor' ) NOT NULL DEFAULT 'ckeditor',
  PRIMARY KEY (`Wysiwyg_Panel_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;


--
-- Дамп данных таблицы `Wysiwyg_Panel`
--

INSERT INTO `Wysiwyg_Panel` (`Wysiwyg_Panel_ID`, `Name`, `Toolbars`, `RemoveButtons`, `Editor`) VALUES
(1, 'Обычная панель редактирования', 'a:16:{s:9:"clipboard";b:1;s:5:"tools";b:1;s:4:"undo";b:1;s:4:"find";b:1;s:9:"selection";b:1;s:5:"forms";b:1;s:11:"basicstyles";b:1;s:7:"cleanup";b:1;s:4:"list";b:1;s:6:"indent";b:1;s:6:"blocks";b:1;s:5:"align";b:1;s:5:"links";b:1;s:6:"insert";b:1;s:6:"styles";b:1;s:6:"colors";b:1;}', '', 'ckeditor'),
(2, 'Inline панель редактирования', 'a:7:{s:11:"basicstyles";b:1;s:7:"cleanup";b:1;s:4:"list";b:1;s:5:"align";b:1;s:5:"links";b:1;s:6:"styles";b:1;s:6:"colors";b:1;}', 'Styles,Format,Font,Subscript,Superscript,Anchor', 'ckeditor'),
(3, 'Базовые стили', 'a:4:{s:11:"basicstyles";b:1;s:5:"align";b:1;s:6:"styles";b:1;s:6:"colors";b:1;}', '', 'ckeditor'),
(4, 'Поиск и замена', 'a:3:{s:9:"clipboard";b:1;s:4:"undo";b:1;s:4:"find";b:1;}', '', 'ckeditor'),
(5, 'Вставка объектов', 'a:2:{s:5:"links";b:1;s:6:"insert";b:1;}', '', 'ckeditor');


-- --------------------------------------------------------

--
-- Структура таблицы `Component_Revisions`
--

CREATE TABLE IF NOT EXISTS `Component_Revisions` (
  `Revision_ID` int(11) NOT NULL AUTO_INCREMENT,
  `File` varchar(255) NOT NULL DEFAULT '',
  `Subdivision_ID` int(11) NOT NULL DEFAULT '0',
  `Class_ID` int(11) NOT NULL DEFAULT '0',
  `Sub_Class_ID` int(11) NOT NULL DEFAULT '0',
  `Message_ID` int(10) unsigned NOT NULL DEFAULT '0',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`Revision_ID`),
  KEY `Subdivision_ID` (`Subdivision_ID`),
  KEY `Class_ID` (`Class_ID`),
  KEY `Sub_Class_ID` (`Sub_Class_ID`),
  KEY `Message_ID` (`Message_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Csv_Import_History`
--

CREATE TABLE IF NOT EXISTS `Csv_Import_History` (
  `History_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Class_ID` int(11) NOT NULL DEFAULT '0',
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Rollbacked` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`History_ID`),
  KEY `Class_ID` (`Class_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Csv_Import_History`
--

CREATE TABLE IF NOT EXISTS `Csv_Import_History_Ids` (
  `History_ID` int(11) NOT NULL DEFAULT '0',
  `Message_ID` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `History_ID` (`History_ID`),
  KEY `Message_ID` (`Message_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `FieldFilter`
--

CREATE TABLE IF NOT EXISTS `FieldFilter` (
  `SubClass_ID` int(11) NOT NULL DEFAULT '0',
  `Field_Name` char(64) NOT NULL DEFAULT '',
  `DoSearch` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`SubClass_ID`, `Field_Name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Class_StyleCache`
--

CREATE TABLE IF NOT EXISTS `Class_StyleCache` (
  `Catalogue_ID` int(11) NOT NULL,
  `Class_ID` int(11) NOT NULL DEFAULT '0',
  `Class_Template_ID` int(11) NOT NULL,
  `LastUpdate` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `BlockSelector` varchar(255) NOT NULL DEFAULT '',
  `ContainerBreakpoints` varchar(255) NOT NULL DEFAULT '',
  `ListObjectBreakpoints` varchar(255) NOT NULL DEFAULT '',
  UNIQUE `Class_StyleCache` (`Catalogue_ID`, `Class_ID`, `Class_Template_ID`)
) ENGINE=MyISAM;

-- --------------------------------------------------------

--
-- Структура таблицы `Security_FilterLog`
--

CREATE TABLE IF NOT EXISTS `Security_FilterLog` (
  `Security_FilterLog_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Hash` char(32),
  `FilterType` varchar(255),
  `CheckType` varchar(255),
  `Catalogue_ID` int(11) NOT NULL,
  `URL` text,
  `Referer` text,
  `PostData` text,
  `Backtrace` text,
  `IP` char(15),
  `ForwardedForIP` varchar(255),
  `CheckedString` text,
  `ValueSource` varchar(255),
  `Value` text,
  `EmailAlertSent` tinyint DEFAULT 0,
  PRIMARY KEY (`Security_FilterLog_ID`),
  KEY (`Hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

-- --------------------------------------------------------

CREATE TABLE  IF NOT EXISTS  `Excursion` (
  `User_ID` int(11) NOT NULL,
  `ShowNext` int(11) NOT NULL DEFAULT '1',
  UNIQUE KEY `User_ID` (`User_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Version` (
  `Version_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Version_Changeset_ID` int(11) NOT NULL,
  `Previous_Version_ID` int(11) NOT NULL DEFAULT 0,
  `Timestamp` timestamp NOT NULL,
  `Action` enum('initial', 'created', 'enabled', 'disabled', 'updated', 'deleted') NOT NULL,
  `Entity` enum('site', 'subdivision', 'infoblock', 'object') NOT NULL,
  `User_ID` int(11) NOT NULL DEFAULT 0,
  `Catalogue_ID` int(11) NOT NULL DEFAULT 0,
  `Subdivision_ID` int(11) NOT NULL DEFAULT 0,
  `Sub_Class_ID` int(11) NOT NULL DEFAULT 0,
  `Class_ID` int(11) NOT NULL DEFAULT 0,
  `Message_ID` int(11) NOT NULL DEFAULT 0,
  `IsActual` tinyint(1) DEFAULT 0,
  `Snapshot` mediumblob NOT NULL,
  PRIMARY KEY (`Version_ID`),
  KEY `Version_Changeset_ID` (`Version_Changeset_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Version_File` (
  `Version_File_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Version_ID` int(11) NOT NULL,
  `Field_Name` varchar(255) NOT NULL,
  `File_Path` text,
  `File_Hash` char(64),
  PRIMARY KEY (`Version_File_ID`),
  KEY (`Version_ID`),
  KEY `File_Hash` (`File_Hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Version_Changeset` (
  `Version_Changeset_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ChangeCount` smallint UNSIGNED DEFAULT 0,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Version_Changeset_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `Filter` (
  `Filter_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Filter_Sub_Class_ID` int(11) NOT NULL DEFAULT 0,
  `Data_Sub_Class_ID` int(11) NOT NULL DEFAULT 0,
  `Settings` text NOT NULL DEFAULT '',
  PRIMARY KEY (`Filter_ID`),
  KEY `Filter_Sub_Class_ID` (`Filter_Sub_Class_ID`),
  KEY `Data_Sub_Class_ID` (`Data_Sub_Class_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- Cache module

ALTER TABLE `Catalogue` ADD COLUMN `Cache_Access_ID` int(11) unsigned NOT NULL default '2';
ALTER TABLE `Catalogue` ADD COLUMN `Cache_Lifetime` int(11) unsigned NOT NULL default '60';

ALTER TABLE `Subdivision` ADD COLUMN `Cache_Access_ID` int(11) unsigned NOT NULL default '0';
ALTER TABLE `Subdivision` ADD COLUMN `Cache_Lifetime` int(11) unsigned NOT NULL default '0';

ALTER TABLE `Sub_Class` ADD COLUMN `Cache_Access_ID` int(11) unsigned NOT NULL default '0';
ALTER TABLE `Sub_Class` ADD COLUMN `Cache_Lifetime` int(11) unsigned NOT NULL default '0';
ALTER TABLE `Sub_Class` ADD COLUMN `CacheForUser` tinyint(4) NOT NULL default '-1';

ALTER TABLE `Class` ADD COLUMN `CacheForUser` tinyint(3) unsigned NOT NULL default '0';


-- Comments module

ALTER TABLE `Catalogue` ADD COLUMN `Comment_Rule_ID` int(11) NOT NULL default '0';
ALTER TABLE `Subdivision` ADD COLUMN `Comment_Rule_ID` int(11) NOT NULL default '0';
ALTER TABLE `Sub_Class` ADD COLUMN `Comment_Rule_ID` int(11) NOT NULL default '0';


-- Search module

ALTER TABLE `Catalogue` ADD COLUMN `SitemapPriority` float DEFAULT 0.5;
ALTER TABLE `Catalogue` ADD COLUMN `SitemapChangefreq` enum ('always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never' ) default 'daily';
ALTER TABLE `Catalogue` ADD COLUMN `IncludeInSitemap` int DEFAULT 1;

ALTER TABLE `Subdivision` ADD COLUMN `SitemapPriority` float DEFAULT NULL;
ALTER TABLE `Subdivision` ADD COLUMN `SitemapChangefreq` enum ('-1','always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never') default '-1';
ALTER TABLE `Subdivision` ADD COLUMN `IncludeInSitemap` int DEFAULT -1;



--
INSERT INTO `SystemMessage` (`Date`, `Description`, `Checked`, `Message`) VALUES
(NOW(), 'Добро пожаловать!', 0, '<center>Уважаемый пользователь!</center>\r\nПоздравляем вас с приобретением системы управления сайтами NetCat. Мы надеемся, что работа с NetCat станет для вас легкой и приятной.\r\n\r\nДля того чтобы начать работать с системой мы рекомендуем ознакомиться с нашей документацией, актуальную версию которой вы всегда найдёте в разделе <a target=_blank href=https://netcat.ru/support/documentation/>"Документация"</a> на нашем сайте.\r\n\r\nЕсли при работе с системой у вас возникли вопросы, не описанные в наших руководствах, вы можете задать их по телефону (495) 783-6021 или на сайте в личном кабинете, который находится по адресу:\r\n<a target=_blank href=https://netcat.ru/>https://netcat.ru/</a>\r\n\r\nЖелаем удачи!\r\n<div align=right>Команда разработчиков системы</div>');
