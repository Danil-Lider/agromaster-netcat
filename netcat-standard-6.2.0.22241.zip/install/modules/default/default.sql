--
-- Дамп данных таблицы `Module`
--

INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `Checked`) VALUES
('NETCAT_MODULE_DEFAULT', 'default', 'NETCAT_MODULE_DEFAULT_DESCRIPTION', 'SOME_VAR=12', '', '/settings/modules/default/', 1, '', 0, 1);