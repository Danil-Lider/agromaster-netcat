--
--
--
INSERT INTO `Settings` (`Key`, `Value`, `Module`, `Catalogue_ID`) VALUES
('DuplicateRouteAction', '1', 'routing', 0);

--
-- `Module`
--

INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `PerSitePermissions`, `Checked`) VALUES
('NETCAT_MODULE_ROUTING', 'routing', 'NETCAT_MODULE_ROUTING_DESCRIPTION', 'ADMIN_SETTINGS_LOCATION=module.routing', '', '', 1, '', 1, 1, 0);

--
-- Table structure for table `Routing_Route`
--

CREATE TABLE IF NOT EXISTS `Routing_Route` (
  `Route_ID` int(10) unsigned NOT NULL auto_increment,
  `Site_ID` int(10) unsigned NOT NULL,
  `Description` text,
  `AllowGET` tinyint(1) NOT NULL default '1',
  `AllowPOST` tinyint(1) NOT NULL default '1',
  `IsBuiltin` tinyint(1) NOT NULL default '1',
  `Pattern` text NOT NULL,
  `CompiledPattern` mediumblob,
  `ResourceType` varchar(255) NOT NULL,
  `ResourceParameters` blob,
  `QueryVariables` mediumblob,
  `QueryVariablesRequiredForCanonical` TINYINT UNSIGNED NOT NULL DEFAULT '1',
  `Priority` int(10) unsigned NOT NULL default '0',
  `Enabled` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`Route_ID`),
  KEY `SiteRoutes` (`Site_ID`,`Enabled`,`Priority`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
