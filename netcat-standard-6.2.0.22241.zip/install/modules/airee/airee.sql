--
-- Дамп данных таблицы `Module`
--

INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `PerSitePermissions`, `Checked`) VALUES
('NETCAT_MODULE_AIREE', 'airee', 'NETCAT_MODULE_AIREE_DESCRIPTION', 'ADMIN_SETTINGS_LOCATION=module.airee', '', '', 1, '', 1, 1, 1);