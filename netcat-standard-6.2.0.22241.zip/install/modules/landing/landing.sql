INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `PerSitePermissions`, `Checked`) VALUES
('NETCAT_MODULE_LANDING', 'landing', 'NETCAT_MODULE_LANDING_DESCRIPTION', 'ADMIN_SETTINGS_LOCATION=module.landing', '', '', 1, '', 1, 1, 1);

INSERT INTO `Settings` SET `Key` = 'Initialized', `Value` = '1', `Module` = 'landing', `Catalogue_ID` = 0;

CREATE TABLE IF NOT EXISTS `Landing_Page` (
  `Landing_Page_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Preset_Keyword` VARCHAR(255) DEFAULT NULL,
  `Site_ID` int(11) UNSIGNED NOT NULL,
  `Subdivision_ID` int(11) UNSIGNED NOT NULL,
  `Source_Component_ID` int(11) UNSIGNED,
  `Source_Object_ID` int(11) UNSIGNED,
  PRIMARY KEY (`Landing_Page_ID`),
  KEY `Site_ID` (`Site_ID`),
  KEY `Preset_Keyword` (`Preset_Keyword`),
  KEY `Subdivision_ID` (`Subdivision_ID`),
  KEY `Source` (`Source_Component_ID`, `Source_Object_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `Landing_Page_Block` (
  `Landing_Page_ID` int(11) NOT NULL,
  `Infoblock_ID` int(11) UNSIGNED NOT NULL,
  `Block_Class_Keyword` varchar(255),
  UNIQUE KEY (`Infoblock_ID`),
  KEY `Landing_Page_ID` (`Landing_Page_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `Landing_Preset_Setting` (
  `Landing_Preset_Setting_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(255),
  `Preset_Keyword` VARCHAR(255) DEFAULT NULL,
  `Preset_Settings` MEDIUMBLOB,
  `Infoblock_ID` int(11) UNSIGNED NOT NULL,
  `Source_Subdivision_ID` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`Landing_Preset_Setting_ID`),
  KEY `Preset_Keyword` (`Preset_Keyword`)
) ENGINE=MyISAM AUTO_INCREMENT=1 CHARSET=utf8;
