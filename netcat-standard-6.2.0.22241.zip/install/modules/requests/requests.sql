INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `PerSitePermissions`, `Checked`) VALUES
('NETCAT_MODULE_REQUESTS', 'requests', 'NETCAT_MODULE_REQUESTS_DESCRIPTION', 'ADMIN_SETTINGS_LOCATION=module.requests', '', '', 1, '', 1, 1, 1);

INSERT INTO `Classificator` (`Classificator_Name`, `Table_Name`, `System`, `Sort_Type`, `Sort_Direction`) VALUES
('Статус заявки', 'RequestStatus', 0, 0, 0);

CREATE TABLE IF NOT EXISTS `Classificator_RequestStatus` (
  `RequestStatus_ID` int(11) NOT NULL AUTO_INCREMENT,
  `RequestStatus_Name` char(255) NOT NULL DEFAULT '',
  `RequestStatus_Priority` int(11) DEFAULT NULL,
  `Value` text DEFAULT NULL,
  `Checked` int(1) DEFAULT 1,
  `CustomSettings` text NULL DEFAULT NULL,
  PRIMARY KEY (`RequestStatus_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

INSERT INTO `Classificator_RequestStatus` (`RequestStatus_ID`, `RequestStatus_Name`, `RequestStatus_Priority`, `Value`, `Checked`) VALUES
(1, 'в обработке', 1, '', 1),
(2, 'отказ', 2, '', 1),
(3, 'выполнено', 3, '', 1);

-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

CREATE TABLE IF NOT EXISTS `Requests_Form_SubdivisionSetting` (
  `Requests_Form_SubdivisionSetting_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` int(11) UNSIGNED NOT NULL,
  `Subdivision_ID` int(11) UNSIGNED NOT NULL,
  `FormType` VARCHAR(255) NOT NULL DEFAULT 'default',

  `StandaloneForm_ComponentTemplate_ID` int(11) UNSIGNED DEFAULT 0,
  `StandaloneForm_Header` TEXT,
  `StandaloneForm_TextAfterHeader` MEDIUMTEXT,
  `StandaloneForm_SubmitButton_Text` TEXT,
  `StandaloneForm_SubmitButton_BackgroundColor` VARCHAR(255) NULL,
  `StandaloneForm_SubmitButton_ShowPrice` TINYINT(1) DEFAULT 0,

  `Subdivision_VisibleFields` MEDIUMTEXT,
  `Subdivision_FieldProperties` MEDIUMTEXT,
  `Subdivision_NotificationEmail` MEDIUMTEXT,

  `Subdivision_OpenPopupButton_AnalyticsCategories` TEXT,
  `Subdivision_OpenPopupButton_AnalyticsLabels` TEXT,
  `Subdivision_SubmitButton_AnalyticsCategories` TEXT,
  `Subdivision_SubmitButton_AnalyticsLabels` TEXT,

  PRIMARY KEY (`Requests_Form_SubdivisionSetting_ID`),
  UNIQUE INDEX `Form` (`Catalogue_ID`, `Subdivision_ID`, `FormType`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;

-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --

CREATE TABLE IF NOT EXISTS `Requests_Form_InfoblockSetting` (
  `Requests_Form_InfoblockSetting_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Infoblock_ID` int(11) UNSIGNED NOT NULL,
  `FormType` VARCHAR(255) NOT NULL DEFAULT 'default',

  `OpenPopupButton_Text` TEXT,
  `OpenPopupButton_BackgroundColor` VARCHAR(255) NULL,
  `OpenPopupButton_ShowPrice` TINYINT(1) DEFAULT 0,

  `EmbeddedForm_ComponentTemplate_ID` int(11) UNSIGNED DEFAULT 0,
  `EmbeddedForm_Header` TEXT,
  `EmbeddedForm_TextAfterHeader` MEDIUMTEXT,
  `EmbeddedForm_SubmitButton_Text` TEXT,
  `EmbeddedForm_SubmitButton_BackgroundColor` VARCHAR(255) NULL,
  `EmbeddedForm_SubmitButton_ShowPrice` TINYINT(1) DEFAULT 0,

  `Infoblock_OpenPopupButton_AnalyticsCategories` TEXT,
  `Infoblock_OpenPopupButton_AnalyticsLabels` TEXT,
  `Infoblock_SubmitButton_AnalyticsCategories` TEXT,
  `Infoblock_SubmitButton_AnalyticsLabels` TEXT,

  PRIMARY KEY (`Requests_Form_InfoblockSetting_ID`),
  UNIQUE INDEX `Form` (`Infoblock_ID`, `FormType`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
