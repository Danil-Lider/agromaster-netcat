--
-- Дамп данных таблицы `Module`
--

INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `Checked`) VALUES
('NETCAT_MODULE_FILEMANAGER', 'filemanager', 'NETCAT_MODULE_FILEMANAGER_DESCRIPTION', 'DEC_PERMISSION_FORMAT=0\n', '', '/settings/modules/filemanager/', 1, '', 0, 1);