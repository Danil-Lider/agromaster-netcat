--
-- Дамп данных таблицы `Module`
--

INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `PerSitePermissions`, `Checked`) VALUES
('NETCAT_MODULE_CAPTCHA', 'captcha', 'NETCAT_MODULE_CAPTCHA_DESCRIPTION', 'ADMIN_SETTINGS_LOCATION=module.captcha', '', '', 1, '', 1, 1, 1);

INSERT INTO `Settings` (`Key`, `Value`, `Module`, `Catalogue_ID`) VALUES
('Provider', 'nc_captcha_provider_image', 'captcha', 0),
('Image_Characters', 'ABCDEFGHKLMNPQRSTUVWXYZ23456789', 'captcha', 0),
('Image_Length', '5', 'captcha', 0),
('Image_ExpiresIn', '300', 'captcha', 0),
('Image_Width', '150', 'captcha', 0),
('Image_Height', '30', 'captcha', 0),
('Image_Lines', '30', 'captcha', 0),
('Image_HiddenFieldName', 'nc_captcha_hash', 'captcha', 0),
('Image_Audio', '0', 'captcha', 0),
('Image_Voice', 'Natasha', 'captcha', 0),
('RemovedLegacyText', 'Введите символы, изображенные на картинке\nВведите код на картинке\nEnter symbols shown on the picture', 'captcha', 0),
('RemovedLegacyBlocks', '.tpl-block-captcha .tpl-block-field-label', 'captcha', 0);


--
-- Структура таблицы `Captchas`
--

CREATE TABLE IF NOT EXISTS `Captchas` (
  `Captcha_Hash` varchar(32) NOT NULL DEFAULT '',
  `Captcha_Code` varchar(255) NOT NULL DEFAULT '',
  `Captcha_Created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Captcha_Hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Captchas_Settings`
--

CREATE TABLE IF NOT EXISTS `Captchas_Settings` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Key` varchar(255) DEFAULT NULL,
  `Value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Дамп данных таблицы `Captchas_Settings`
--

INSERT INTO `Captchas_Settings` (`ID`, `Key`, `Value`) VALUES
(1, 'time', '2012-08-01 10:55:35'),
(2, 'current_voice', 'Natasha'),
(3, '0.mp3', 'f30467c48ec8b9cf3373b3fd7971acb9.mp3'),
(4, '1.mp3', '406b6766fe4685523294911d23fd32d1.mp3'),
(5, '2.mp3', 'c029bddcd65841bc6945ba4bcd1d3586.mp3'),
(6, '3.mp3', '5c512f1b8e9fb67a2c71d097b92da40f.mp3'),
(7, '4.mp3', '739fd6f02688201ad9d12973955bdf44.mp3'),
(8, '5.mp3', '096b71dc61622dbd3340db055cc9d451.mp3'),
(9, '6.mp3', 'b1e8b2a0a51457cedbe59c109842f34c.mp3'),
(10, '7.mp3', 'e71828f32c1a613de0938bce4389a445.mp3'),
(11, '8.mp3', '8d85661608af8b6ac9be917cd25790d7.mp3'),
(12, '9.mp3', '94dcdcd5a5a9b0bc4dcfcf70d5bae749.mp3'),
(13, 'a.mp3', '38bb1b8af043e436a2d91e24cbdd735d.mp3'),
(14, 'b.mp3', '5f7c94de9695830f066489527fbcc343.mp3'),
(15, 'c.mp3', '11a64a2e0ec861ad9129890a396c3ee9.mp3'),
(16, 'd.mp3', 'ed90f93bce04ae2c0db0256744ac7088.mp3'),
(17, 'e.mp3', 'dd1d4d0bb3adc242d4df4afb6d5dc240.mp3'),
(18, 'f.mp3', 'cbf5512f7efc9ef4fe44a53d5c399f6e.mp3'),
(19, 'g.mp3', '61b546c833519c3cdf6e62198d0a7c70.mp3'),
(20, 'h.mp3', '956faf2cc9878b685ef62cf74372e79a.mp3'),
(21, 'i.mp3', 'f48875f8b81d1c17c95d3202fcc3f4c2.mp3'),
(22, 'j.mp3', '4478108c3c0e08668ff072a58b00bca8.mp3'),
(23, 'k.mp3', '040f7b69468b52c273a2e99c3cc38054.mp3'),
(24, 'l.mp3', '484addf85faa236932992a63f3d6229f.mp3'),
(25, 'm.mp3', '3f274fa855df0819053701a844694524.mp3'),
(26, 'n.mp3', '01eb5683a86fac4d1aa019e2a297a709.mp3'),
(27, 'o.mp3', '570c6b87c7a6af399f86d38b96701726.mp3'),
(28, 'p.mp3', '2869c7ff722f9c2f969698e5e9824497.mp3'),
(29, 'q.mp3', '3e8295df2ae95e745b25e9a0197cc593.mp3'),
(30, 'r.mp3', '9e627ce3096c4682e48160d9f85e3244.mp3'),
(31, 's.mp3', '6803292d2d0833fe8fd83b9237963c38.mp3'),
(32, 't.mp3', '5cd6ed4f3372e80e2607a07d3db988a4.mp3'),
(33, 'u.mp3', 'b8a71e330c97f1f9bc92bf0c6ea90ab6.mp3'),
(34, 'v.mp3', '7f4adcbb74736a68c3980f51d4600b15.mp3'),
(35, 'w.mp3', 'e162403f21779d2f67cf026ae258fd97.mp3'),
(36, 'x.mp3', 'f7aa1752a9257e7164cf57a8b7692578.mp3'),
(37, 'y.mp3', '9802a0071d1ac858a599e277319d01c0.mp3'),
(38, 'z.mp3', 'fa4deeca5bcf93b615a4455ec219f45f.mp3');

-- --------------------------------------------------------

--
-- Структура таблицы `Captchas_Recaptcha`
--

CREATE TABLE IF NOT EXISTS `Captchas_Recaptcha` (
  `Response` blob,
  `Result` blob,
  `Expires` timestamp,
  KEY (`Response`(255))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
