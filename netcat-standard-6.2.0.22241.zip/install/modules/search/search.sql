--
-- Дамп данных таблицы `Module`
--

INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `Checked`) VALUES
('NETCAT_MODULE_SEARCH', 'search', 'NETCAT_MODULE_SEARCH_DESCRIPTION', 'ADMIN_SETTINGS_LOCATION=module.search.generalsettings', '', '', 1, '', 1, 1);

--
-- Структура таблицы `Search_BrokenLink`
--

CREATE TABLE IF NOT EXISTS `Search_BrokenLink` (
  `URL` text NOT NULL,
  `Referrer_URL` text NOT NULL,
  `Referrer_Document_ID` int(11) DEFAULT NULL,
  `ToDelete` tinyint(4) DEFAULT '0',
  KEY `URL` (`URL`(100)),
  KEY `Referrer_URL` (`Referrer_URL`(100))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Document`
--

CREATE TABLE IF NOT EXISTS `Search_Document` (
  `Document_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` int(11) NOT NULL,
  `Subdivision_ID` int(11) DEFAULT NULL,
  `Ancestors` text,
  `Path` text NOT NULL,
  `Title` text NOT NULL,
  `Content` mediumtext,
  `Meta` mediumtext,
  `ContentType` varchar(255) NOT NULL,
  `Language` varchar(255) NOT NULL,
  `IncludeInSitemap` tinyint(4) NOT NULL DEFAULT '0',
  `SitemapChangefreq` enum('','always','hourly','daily','weekly','monthly','yearly','never') DEFAULT NULL,
  `SitemapPriority` decimal(2,1) unsigned DEFAULT NULL,
  `Hash` char(40) DEFAULT NULL,
  `ToDelete` tinyint(4) NOT NULL DEFAULT '0',
  `LastModified` timestamp NULL DEFAULT NULL,
  `LastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Document_ID`),
  KEY `Sitemap` (`Catalogue_ID`,`IncludeInSitemap`),
  KEY `Title` (`Title`(256))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Extension`
--

CREATE TABLE IF NOT EXISTS `Search_Extension` (
  `Rule_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ExtensionInterface` varchar(255) NOT NULL,
  `ExtensionClass` varchar(255) NOT NULL,
  `SearchProvider` varchar(255) DEFAULT NULL,
  `Action` varchar(255) DEFAULT NULL,
  `Language` varchar(255) DEFAULT NULL,
  `ContentType` varchar(255) DEFAULT NULL,
  `Priority` tinyint(5) unsigned NOT NULL DEFAULT '127',
  `Checked` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`Rule_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Дамп данных таблицы `Search_Extension`
--

INSERT INTO `Search_Extension` (`Rule_ID`, `ExtensionInterface`, `ExtensionClass`, `SearchProvider`, `Action`, `Language`, `ContentType`, `Priority`, `Checked`) VALUES
(1, 'nc_search_provider', 'nc_search_provider_zend', '', '', '', '', 127, 1),
(2, 'nc_search_document_parser', 'nc_search_document_parser_html', '', '', '', 'text/html', 127, 1),
(3, 'nc_search_language_analyzer', 'nc_search_language_analyzer_morphy', '', '', 'ru', '', 127, 1),
(4, 'nc_search_language_analyzer', 'nc_search_language_analyzer_morphy', '', '', 'en', '', 127, 1),
(5, 'nc_search_language_filter', 'nc_search_language_filter_normalize', '', '', '', '', 20, 1),
(6, 'nc_search_language_filter', 'nc_search_language_filter_minlength', '', '', '', '', 40, 1),
(7, 'nc_search_language_filter', 'nc_search_language_filter_case', '', '', '', '', 60, 1),
(8, 'nc_search_language_filter', 'nc_search_language_filter_yo', '', '', 'ru', '', 80, 1),
(9, 'nc_search_language_filter', 'nc_search_language_filter_stopwords', '', '', '', '', 120, 1),
(10, 'nc_search_language_filter', 'nc_search_language_filter_synonyms', '', 'searching', '', '', 140, 1),
(11, 'nc_search_language_filter', 'nc_search_language_filter_analyzer', '', '', '', '', 100, 1),
(12, 'nc_search_language_corrector', 'nc_search_language_corrector_quotes', '', '', '', '', 50, 1),
(13, 'nc_search_language_corrector', 'nc_search_language_corrector_basic', '', '', '', '', 100, 1),
(14, 'nc_search_provider', 'nc_search_provider_index', '' , '' , '' , '', 127, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Field`
--

CREATE TABLE IF NOT EXISTS `Search_Field` (
  `Name` varchar(255) NOT NULL,
  `Weight` decimal(5,2) unsigned NOT NULL,
  `Type` tinyint(4) NOT NULL DEFAULT '0',
  `IsIndexed` tinyint(4) NOT NULL DEFAULT '1',
  `IsSearchable` tinyint(4) NOT NULL DEFAULT '1',
  `IsNormalized` tinyint(4) NOT NULL DEFAULT '1',
  `IsSortable` tinyint(4) NOT NULL DEFAULT '0',
  `IsStored` tinyint(4) NOT NULL DEFAULT '0',
  `IsRetrievable` tinyint(4) NOT NULL DEFAULT '0',
  `Query` text,
  `QueryScope` enum('document','content') DEFAULT 'document',
  `QueryUseFirstMatched` tinyint(4) NOT NULL,
  `FilterContent` text,
  `RemoveFromParent` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`Name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Дамп данных таблицы `Search_Field`
--

INSERT INTO `Search_Field` (`Name`, `Weight`, `Type`, `IsIndexed`, `IsSearchable`, `IsNormalized`, `IsSortable`, `IsStored`, `IsRetrievable`, `Query`, `QueryScope`, `QueryUseFirstMatched`, `FilterContent`, `RemoveFromParent`) VALUES
('title', 3.00, 0, 1, 1, 1, 0, 0, 0, 'title', 'document', 0, NULL, 0),
('content', 1.00, 0, 1, 1, 1, 0, 0, 0, '//div[contains(@class,"tpl-container-main")]\r\n#<!--\\s*content\\s*-->(.+?)<!--\\s*/content\\s*-->#si\r\nbody', 'document', 1, '#<!--\\s*noindex\\s*-->(.+?)<!--\\s*/noindex\\s*-->#si\nscript\nstyle', 0),
('meta', 2.00, 0, 1, 1, 1, 0, 0, 0, '//meta[@name="keywords"]/@content\r\n//meta[@name="description"]/@content', 'document', 0, NULL, 0),
('page_type', 1.00, 0, 1, 1, 1, 0, 0, 1, '//*[@data-page-type]/@data-page-type', 'document', 0, NULL, 0),
('page_subtitle', 1.00, 0, 1, 1, 1, 0, 0, 1, '//*[@data-page-type="other"]/@data-subtitle', 'document', 0, NULL, 0),
('page_title', 1.00, 0, 1, 1, 1, 0, 0, 1, '//*[@data-page-type="other"]/@data-title', 'document', 0, NULL, 0),
('subdivision_name', 1.00, 0, 1, 1, 1, 0, 0, 1, '//*[@data-page-type="goods index"]/@data-subdivision-name', 'document', 0, NULL, 0),
('subdivision_id', 1.00, 1, 1, 1, 1, 0, 0, 1, '//*[@data-page-type="goods index"]/@data-subdivision-id', 'document', 0, NULL, 0),
('component_id', 1.00, 1, 1, 1, 1, 0, 0, 1, '//*[@data-page-type="goods full"]/@data-component-id', 'document', 0, NULL, 0),
('message_id', 1.00, 1, 1, 1, 1, 0, 0, 1, '//*[@data-page-type="goods full"]/@data-message-id', 'document', 0, NULL, 0),
('w2', 2.00, 0, 1, 1, 1, 0, 0, 0, 'h1 h2 h3', 'content', 0, NULL, 1),
('w1_5', 1.50, 0, 1, 1, 1, 0, 0, 0, 'b strong', 'content', 0, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Link`
--

CREATE TABLE IF NOT EXISTS `Search_Link` (
  `Link_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Hash` binary(20) NOT NULL,
  `URL` text NOT NULL,
  `Processed` tinyint(4) NOT NULL,
  `Broken` tinyint(4) NOT NULL,
  PRIMARY KEY (`Link_ID`),
  UNIQUE KEY `Hash` (`Hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_LinkReferrer`
--

CREATE TABLE IF NOT EXISTS `Search_LinkReferrer` (
  `Source_Document_ID` int(11) DEFAULT NULL,
  `Source_Link_ID` int(11) NOT NULL,
  `Target_Link_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Log`
--

CREATE TABLE IF NOT EXISTS `Search_Log` (
  `Log_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Type` varchar(255) NOT NULL,
  `Message` mediumtext NOT NULL,
  PRIMARY KEY (`Log_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Query`
--

CREATE TABLE IF NOT EXISTS `Search_Query` (
  `Query_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `QueryString` varchar(255) NOT NULL,
  `Area` text,
  `Catalogue_ID` int(11) DEFAULT NULL,
  `Language` varchar(255) DEFAULT NULL,
  `ResultsCount` int(11) NOT NULL,
  `IP` int(11) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Query_ID`),
  KEY `QueryString` (`QueryString`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Rule`
--

CREATE TABLE IF NOT EXISTS `Search_Rule` (
  `Rule_ID` int(11) NOT NULL auto_increment,
  `Name` varchar(255) NOT NULL,
  `Catalogue_ID` int(11) default NULL,
  `AreaString` text,
  `Interval` smallint(6) default NULL,
  `IntervalType` varchar(255) NOT NULL,
  `Hour` tinyint(4) default NULL,
  `Minute` tinyint(4) default NULL,
  `LastStartTime` int(11) default NULL,
  `LastFinishTime` int(11) default NULL,
  `LastResult` blob NOT NULL,
  PRIMARY KEY  (`Rule_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Schedule`
--

CREATE TABLE IF NOT EXISTS `Search_Schedule` (
  `Schedule_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Type` tinyint(4) NOT NULL,
  `AreaString` text NOT NULL,
  `StartTime` int(11) NOT NULL,
  PRIMARY KEY (`Schedule_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Stopword`
--

CREATE TABLE IF NOT EXISTS `Search_Stopword` (
  `Word_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Language` varchar(10) NOT NULL,
  `Word` varchar(255) NOT NULL,
  PRIMARY KEY (`Word_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=492 ;

-- --------------------------------------------------------

--
-- Дамп данных таблицы `Search_Stopword`
--

INSERT INTO `Search_Stopword` (`Language`, `Word`) VALUES
('ru', 'А'),
('ru', 'БЕЗ'),
('ru', 'БОЛЕЕ'),
('ru', 'БЫ'),
('ru', 'БЫТЬ'),
('ru', 'В'),
('ru', 'ВЕСИТЬ'),
('ru', 'ВЕСЬ'),
('ru', 'ВОТ'),
('ru', 'ВСЕ'),
('ru', 'ВЫ'),
('ru', 'ГДЕ'),
('ru', 'ДА'),
('ru', 'ДАЖЕ'),
('ru', 'ДЛИТЬ'),
('ru', 'ДЛЯ'),
('ru', 'ДО'),
('ru', 'ЕСЛИ'),
('ru', 'ЕЩЕ'),
('ru', 'ЖЕ'),
('ru', 'ЗА'),
('ru', 'ЗДЕСЬ'),
('ru', 'И'),
('ru', 'ИЗ'),
('ru', 'ИЛИ'),
('ru', 'К'),
('ru', 'КАК'),
('ru', 'КО'),
('ru', 'КОГДА'),
('ru', 'КТО'),
('ru', 'ЛИ'),
('ru', 'ЛИБО'),
('ru', 'МНОГО'),
('ru', 'МОЖЕТ'),
('ru', 'МОЧЬ'),
('ru', 'МЫ'),
('ru', 'НА'),
('ru', 'НАДО'),
('ru', 'НЕ'),
('ru', 'НЕТ'),
('ru', 'НИ'),
('ru', 'НО'),
('ru', 'НУ'),
('ru', 'О'),
('ru', 'ОБ'),
('ru', 'ОДНАКО'),
('ru', 'ОН'),
('ru', 'ОНА'),
('ru', 'ОНИ'),
('ru', 'ОНО'),
('ru', 'ОТ'),
('ru', 'ОЧЕНЬ'),
('ru', 'ПЕРЕТЬ'),
('ru', 'ПО'),
('ru', 'ПОД'),
('ru', 'ПРИ'),
('ru', 'ПРЯ'),
('ru', 'С'),
('ru', 'СО'),
('ru', 'ТАК'),
('ru', 'ТАКОЙ'),
('ru', 'ТАМ'),
('ru', 'ТО'),
('ru', 'ТОГО'),
('ru', 'ТОЖЕ'),
('ru', 'ТОЛЬКО'),
('ru', 'ТОТ'),
('ru', 'ТЫ'),
('ru', 'У'),
('ru', 'УЖ'),
('ru', 'УЖЕ'),
('ru', 'УЗКИЙ'),
('ru', 'ХОТЕТЬ'),
('ru', 'ХОТЯ'),
('ru', 'ЧЕГО'),
('ru', 'ЧЕЙ'),
('ru', 'ЧЕМ'),
('ru', 'ЧТО'),
('ru', 'ЧТОБЫ'),
('ru', 'ЭТО'),
('ru', 'ЭТОТ'),
('ru', 'Я'),
('en', 'A'),
('en', 'ABLE'),
('en', 'ABOUT'),
('en', 'ABOVE'),
('en', 'ACCORD'),
('en', 'ACCORDING'),
('en', 'ACCORDINGLY'),
('en', 'ACROSS'),
('en', 'ACTUALLY'),
('en', 'AFTER'),
('en', 'AFTERWARDS'),
('en', 'AGAIN'),
('en', 'AGAINST'),
('en', 'ALL'),
('en', 'ALLOW'),
('en', 'ALMOST'),
('en', 'ALONE'),
('en', 'ALONG'),
('en', 'ALREADY'),
('en', 'ALSO'),
('en', 'ALTHOUGH'),
('en', 'ALWAYS'),
('en', 'AMONG'),
('en', 'AMONGST'),
('en', 'AN'),
('en', 'AND'),
('en', 'ANOTHER'),
('en', 'ANY'),
('en', 'ANYBODY'),
('en', 'ANYHOW'),
('en', 'ANYONE'),
('en', 'ANYTHING'),
('en', 'ANYWAY'),
('en', 'ANYWAYS'),
('en', 'ANYWHERE'),
('en', 'APART'),
('en', 'APPEAR'),
('en', 'APPRECIATE'),
('en', 'APPROPRIATE'),
('en', 'AROUND'),
('en', 'AS'),
('en', 'ASIDE'),
('en', 'ASK'),
('en', 'ASKING'),
('en', 'ASSOCIATE'),
('en', 'ASSOCIATED'),
('en', 'AT'),
('en', 'AVAILABLE'),
('en', 'AWAY'),
('en', 'AWFULLY'),
('en', 'BE'),
('en', 'BECAUSE'),
('en', 'BECOME'),
('en', 'BEFORE'),
('en', 'BEFOREHAND'),
('en', 'BEHIND'),
('en', 'BELIEVE'),
('en', 'BELOW'),
('en', 'BESIDE'),
('en', 'BESIDES'),
('en', 'BEST'),
('en', 'BETTER'),
('en', 'BETWEEN'),
('en', 'BEYOND'),
('en', 'BOTH'),
('en', 'BRIEF'),
('en', 'BUT'),
('en', 'BY'),
('en', 'CAN'),
('en', 'CANNOT'),
('en', 'CANT'),
('en', 'CAUSE'),
('en', 'CERTAIN'),
('en', 'CERTAINLY'),
('en', 'CHANGE'),
('en', 'CLEARLY'),
('en', 'CO'),
('en', 'COME'),
('en', 'CONCERN'),
('en', 'CONCERNING'),
('en', 'CONSEQUENTLY'),
('en', 'CONSIDER'),
('en', 'CONSIDERING'),
('en', 'CONTAIN'),
('en', 'CORRESPOND'),
('en', 'CORRESPONDING'),
('en', 'COURSE'),
('en', 'CURRENTLY'),
('en', 'DEFINITELY'),
('en', 'DESCRIBE'),
('en', 'DESPITE'),
('en', 'DIFFERENT'),
('en', 'DO'),
('en', 'DOE'),
('en', 'DOING'),
('en', 'DOWN'),
('en', 'DOWNWARDS'),
('en', 'DURING'),
('en', 'EACH'),
('en', 'EG'),
('en', 'EITHER'),
('en', 'ELSE'),
('en', 'ELSEWHERE'),
('en', 'ENOUGH'),
('en', 'ENTIRELY'),
('en', 'ESPECIALLY'),
('en', 'ET'),
('en', 'EVEN'),
('en', 'EVER'),
('en', 'EVERY'),
('en', 'EVERYBODY'),
('en', 'EVERYONE'),
('en', 'EVERYTHING'),
('en', 'EVERYWHERE'),
('en', 'EXACTLY'),
('en', 'EXCEPT'),
('en', 'FAR'),
('en', 'FEW'),
('en', 'FOLLOW'),
('en', 'FOR'),
('en', 'FORMER'),
('en', 'FORMERLY'),
('en', 'FROM'),
('en', 'FURTHER'),
('en', 'FURTHERMORE'),
('en', 'GET'),
('en', 'GETTING'),
('en', 'GIVE'),
('en', 'GIVEN'),
('en', 'GO'),
('en', 'GOING'),
('en', 'GONE'),
('en', 'GOOD'),
('en', 'GOTTEN'),
('en', 'GREETING'),
('en', 'HA'),
('en', 'HAPPEN'),
('en', 'HARDLY'),
('en', 'HAVE'),
('en', 'HAVING'),
('en', 'HE'),
('en', 'HELLO'),
('en', 'HENCE'),
('en', 'HER'),
('en', 'HERE'),
('en', 'HEREAFTER'),
('en', 'HEREBY'),
('en', 'HEREIN'),
('en', 'HEREUPON'),
('en', 'HERSELF'),
('en', 'HI'),
('en', 'HIMSELF'),
('en', 'HIS'),
('en', 'HITHER'),
('en', 'HOPEFULLY'),
('en', 'HOW'),
('en', 'HOWBEIT'),
('en', 'HOWEVER'),
('en', 'I'),
('en', 'IF'),
('en', 'IGNORE'),
('en', 'IMMEDIATE'),
('en', 'IN'),
('en', 'INASMUCH'),
('en', 'INDEED'),
('en', 'INDICATE'),
('en', 'INNER'),
('en', 'INSOFAR'),
('en', 'INSTEAD'),
('en', 'INTO'),
('en', 'INWARD'),
('en', 'IT'),
('en', 'ITS'),
('en', 'ITSELF'),
('en', 'JUST'),
('en', 'KEEP'),
('en', 'KEPT'),
('en', 'KNOW'),
('en', 'KNOWN'),
('en', 'LAST'),
('en', 'LATE'),
('en', 'LATELY'),
('en', 'LATER'),
('en', 'LATTER'),
('en', 'LEAST'),
('en', 'LESS'),
('en', 'LEST'),
('en', 'LET'),
('en', 'LIKE'),
('en', 'LIKELY'),
('en', 'LITTLE'),
('en', 'LL'),
('en', 'LOOK'),
('en', 'LOOKING'),
('en', 'LTD'),
('en', 'MAINLY'),
('en', 'MANY'),
('en', 'MAY'),
('en', 'MAYBE'),
('en', 'MEAN'),
('en', 'MEANWHILE'),
('en', 'MERELY'),
('en', 'MORE'),
('en', 'MOREOVER'),
('en', 'MOST'),
('en', 'MOSTLY'),
('en', 'MUCH'),
('en', 'MUST'),
('en', 'MY'),
('en', 'MYSELF'),
('en', 'NAME'),
('en', 'NAMELY'),
('en', 'ND'),
('en', 'NEAR'),
('en', 'NEARLY'),
('en', 'NECESSARY'),
('en', 'NEED'),
('en', 'NEITHER'),
('en', 'NEVER'),
('en', 'NEVERTHELESS'),
('en', 'NEW'),
('en', 'NEXT'),
('en', 'NO'),
('en', 'NOBODY'),
('en', 'NON'),
('en', 'NONE'),
('en', 'NOONE'),
('en', 'NOR'),
('en', 'NORMALLY'),
('en', 'NOT'),
('en', 'NOTHING'),
('en', 'NOW'),
('en', 'NOWHERE'),
('en', 'O'),
('en', 'OBVIOUSLY'),
('en', 'OF'),
('en', 'OFF'),
('en', 'OFTEN'),
('en', 'OH'),
('en', 'OK'),
('en', 'OKAY'),
('en', 'OLD'),
('en', 'ON'),
('en', 'ONCE'),
('en', 'ONE'),
('en', 'ONLY'),
('en', 'ONTO'),
('en', 'OR'),
('en', 'OTHER'),
('en', 'OTHERWISE'),
('en', 'OUGHT'),
('en', 'OUR'),
('en', 'OURSELF'),
('en', 'OUT'),
('en', 'OUTSIDE'),
('en', 'OVER'),
('en', 'OVERALL'),
('en', 'OWN'),
('en', 'PARTICULAR'),
('en', 'PARTICULARLY'),
('en', 'PER'),
('en', 'PERHAPS'),
('en', 'PLACE'),
('en', 'PLACED'),
('en', 'PLEASE'),
('en', 'PLUS'),
('en', 'POSSIBLE'),
('en', 'PRESUMABLY'),
('en', 'PROBABLY'),
('en', 'PROVIDE'),
('en', 'QUITE'),
('en', 'RATHE'),
('en', 'RATHER'),
('en', 'RD'),
('en', 'RE'),
('en', 'REALLY'),
('en', 'REASONABLY'),
('en', 'REGARD'),
('en', 'REGARDING'),
('en', 'REGARDLESS'),
('en', 'RELATIVELY'),
('en', 'RESPECTIVELY'),
('en', 'RIGHT'),
('en', 'SAME'),
('en', 'SAW'),
('en', 'SAY'),
('en', 'SAYING'),
('en', 'SEE'),
('en', 'SEEING'),
('en', 'SEEM'),
('en', 'SEEMING'),
('en', 'SELF'),
('en', 'SENSIBLE'),
('en', 'SERIOUS'),
('en', 'SERIOUSLY'),
('en', 'SEVERAL'),
('en', 'SHALL'),
('en', 'SHE'),
('en', 'SINCE'),
('en', 'SO'),
('en', 'SOME'),
('en', 'SOMEBODY'),
('en', 'SOMEHOW'),
('en', 'SOMEONE'),
('en', 'SOMETHING'),
('en', 'SOMETIME'),
('en', 'SOMETIMES'),
('en', 'SOMEWHAT'),
('en', 'SOMEWHERE'),
('en', 'SOON'),
('en', 'SORRY'),
('en', 'SPECIFY'),
('en', 'STILL'),
('en', 'SUCH'),
('en', 'SURE'),
('en', 'TAKE'),
('en', 'TELL'),
('en', 'TEND'),
('en', 'THAN'),
('en', 'THANK'),
('en', 'THANX'),
('en', 'THAT'),
('en', 'THE'),
('en', 'THEIR'),
('en', 'THEMSELVES'),
('en', 'THEN'),
('en', 'THENCE'),
('en', 'THERE'),
('en', 'THEREAFTER'),
('en', 'THEREBY'),
('en', 'THEREFORE'),
('en', 'THEREIN'),
('en', 'THERES'),
('en', 'THEREUPON'),
('en', 'THEY'),
('en', 'THINK'),
('en', 'THIS'),
('en', 'THOROUGH'),
('en', 'THOROUGHLY'),
('en', 'THOUGH'),
('en', 'THROUGH'),
('en', 'THROUGHOUT'),
('en', 'THRU'),
('en', 'THUS'),
('en', 'TO'),
('en', 'TOGETHER'),
('en', 'TOO'),
('en', 'TOWARD'),
('en', 'TOWARDS'),
('en', 'TRULY'),
('en', 'TRY'),
('en', 'TRYING'),
('en', 'U'),
('en', 'UN'),
('en', 'UNDER'),
('en', 'UNFORTUNATELY'),
('en', 'UNLESS'),
('en', 'UNLIKELY'),
('en', 'UNTIL'),
('en', 'UNTO'),
('en', 'UP'),
('en', 'UPON'),
('en', 'USE'),
('en', 'USED'),
('en', 'USEFUL'),
('en', 'USUALLY'),
('en', 'V'),
('en', 'VALUE'),
('en', 'VARIOUS'),
('en', 'VERY'),
('en', 'VIA'),
('en', 'VIZ'),
('en', 'WANT'),
('en', 'WAY'),
('en', 'WE'),
('en', 'WELL'),
('en', 'WHAT'),
('en', 'WHATEVER'),
('en', 'WHEN'),
('en', 'WHENCE'),
('en', 'WHENEVER'),
('en', 'WHERE'),
('en', 'WHEREAFTER'),
('en', 'WHEREAS'),
('en', 'WHEREBY'),
('en', 'WHEREIN'),
('en', 'WHEREUPON'),
('en', 'WHEREVER'),
('en', 'WHETHER'),
('en', 'WHICH'),
('en', 'WHILE'),
('en', 'WHITHER'),
('en', 'WHO'),
('en', 'WHOEVER'),
('en', 'WHOLE'),
('en', 'WHOSE'),
('en', 'WHY'),
('en', 'WILL'),
('en', 'WILLING'),
('en', 'WISH'),
('en', 'WITH'),
('en', 'WITHIN'),
('en', 'WITHOUT'),
('en', 'WOULD'),
('en', 'YES'),
('en', 'YET'),
('en', 'YOU'),
('en', 'YOUR'),
('en', 'YOURSELF');

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Synonym`
--

CREATE TABLE IF NOT EXISTS `Search_Synonym` (
  `Synonyms_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Language` varchar(10) NOT NULL,
  `Words` text NOT NULL,
  PRIMARY KEY (`Synonyms_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `Search_Synonym`
--

INSERT INTO `Search_Synonym` (`Synonyms_ID`, `Language`, `Words`) VALUES
(1, 'ru', 'a:2:{i:0;s:6:"NETCAT";i:1;s:14:"НЕТКЭТА";}');

-- --------------------------------------------------------

--
-- Структура таблицы `Search_Task`
--

CREATE TABLE IF NOT EXISTS `Search_Task` (
  `Task_ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `RunnerType` TINYINT UNSIGNED,
  `Links` mediumblob NOT NULL,
  `Area` mediumblob NOT NULL,
  `Disallowed` mediumblob,
  `Rule_ID` int(11) DEFAULT NULL,
  `StartTime` int(11) DEFAULT NULL,
  `TotalProcessed` int(11) DEFAULT '0',
  `TotalChecked` int(11) DEFAULT '0',
  `TotalNotFound` int(11) DEFAULT '0',
  `TotalDeleted` int(11) DEFAULT '0',
  `Token` int(11) NOT NULL,
  `LastActivity` int(11) DEFAULT NULL,
  `IsIdle` TINYINT UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`Task_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `Settings`
--

INSERT INTO `Settings` (`Key`, `Value`, `Module`, `Catalogue_ID`) VALUES
('ExcludeUrlRegexps', 'subscribe_\r\nadd_reply\r\nadd_topic\r\nbacklink\r\nnetcat/\r\nrss\r\nxml\r\ntag=\r\nsortBy=\r\nsortDesc=\r\nrecNum=', 'search', 0),
('SearchFormTemplate', '// Общие компоненты формы\r\n$form_start = "<form class=''nc_search'' action=''$actionurl'' method=''GET''>";\r\n$input = "<input class=''text'' type=''text'' size=''$inputsize'' name=''search_query''" .\r\n         " id=''nc_search_query'' value=''$inputvalue'' />";\r\n$submit = "<input class=''submit'' type=''submit'' value=''" . htmlspecialchars($submitname) . "'' />";\r\n$advanced = (!in_array($showadvancedlink, array(1, true, "on", "yes")) ? "" :\r\n    "<div class=''advancedlink''><a href=''$actionurl?advanced=1''>" .\r\n       NETCAT_MODULE_SEARCH_ADVANCED_LINK_TEXT .\r\n    "</a></div>");\r\n\r\n// Форма поиска без уточнения области\r\n$searchform["empty"]["prefix"] = $form_start . $input . $submit;\r\n$searchform["empty"]["active"] = "";\r\n$searchform["empty"]["unactive"] = "";\r\n$searchform["empty"]["divider"] = "";\r\n$searchform["empty"]["suffix"] = $advanced . "</form>";\r\n\r\n// Форма поиска со скрытой областью поиска\r\n$searchform["hidden"]["prefix"] = $form_start . $input . $submit;\r\n$searchform["hidden"]["active"] = "<input type=''hidden'' id=''nc_search_area_%AREANUM'' name=''area[]'' value=''%AREA'' />";\r\n$searchform["hidden"]["unactive"] = "<input type=''hidden'' id=''nc_search_area_%AREANUM'' name=''area[]'' value=''%AREA'' />";\r\n$searchform["hidden"]["divider"] = "<input type=''hidden'' id=''nc_search_area_%AREANUM'' name=''area[]'' value=''%AREA'' />";\r\n$searchform["hidden"]["suffix"] = $advanced . "</form>";\r\n\r\n// Форма поиска с выбором области поиска радиокнопкой\r\n$searchform["radio"]["prefix"] = $form_start . $input . $submit . "<div class=''areas''>";\r\n$searchform["radio"]["unactive"] =\r\n  "<span class=''radio''><input type=''radio'' id=''nc_search_area_%AREANUM'' name=''area'' value=''%AREA'' />" .\r\n  "<label for=''nc_search_area_%AREANUM''>%NAME</label></span>";\r\n$searchform["radio"]["active"] =\r\n  "<span class=''radio''><input type=''radio'' id=''nc_search_area_%AREANUM'' name=''area'' value=''%AREA'' checked=''checked'' /> " .\r\n  "<label for=''nc_search_area_%AREANUM''>%NAME</label></span>";\r\n$searchform["radio"]["divider"] = " ";\r\n$searchform["radio"]["suffix"] = "</div>" . $advanced . "</form>";\r\n\r\n// Форма поиска с выбором области поиска чекбоксом\r\n$searchform["checkbox"]["prefix"] = $form_start . $input . $submit . "<div class=''areas''>";\r\n$searchform["checkbox"]["unactive"] =\r\n  "<span class=''checkbox''><input type=''checkbox'' id=''nc_search_area_%AREANUM'' name=''area[]'' value=''%AREA'' />" .\r\n  "<label for=''nc_search_area_%AREANUM''>%NAME</label></span>";\r\n$searchform["checkbox"]["active"] =\r\n  "<span class=''checkbox''><input type=''checkbox'' id=''nc_search_area_%AREANUM'' name=''area'' value=''%AREA'' checked=''checked'' /> " .\r\n  "<label for=''nc_search_area_%AREANUM''>%NAME</label></span>";\r\n$searchform["checkbox"]["divider"] = " ";\r\n$searchform["checkbox"]["suffix"] = "</div>" . $advanced . "</form>";\r\n\r\n// Форма поиска с выбором области поиска выпадающим списком\r\n$searchform["select"]["prefix"] = $form_start . $input . "<select name=''area'' class=''area_select''>";\r\n$searchform["select"]["unactive"] = "<option value=''%AREA''>%NAME</option>";\r\n$searchform["select"]["active"] = "<option value=''%AREA'' selected=''1''>%NAME</option>";\r\n$searchform["select"]["divider"] = "\\n";\r\n$searchform["select"]["suffix"] = "</select>" . $submit . $advanced . "</form>";\r\n\r\n// Форма поиска с выбором области поиска ссылкой (нажатие на ссылку перезагружает\r\n// текущую страницу с параметром &area=; для использования на странице поиска)\r\n$searchform["links"]["prefix"] = $form_start . $input . $submit . "<div class=''areas''>";\r\n$searchform["links"]["unactive"] = "<span class=''link''><a href=''%URL&amp;area=%AREA''>%NAME</a></span>";\r\n$searchform["links"]["active"] = "<span class=''link link_active''>%NAME</span>";\r\n$searchform["links"]["divider"] = " ";\r\n$searchform["links"]["suffix"] = "</div>" . $advanced . "</form>";\r\n', 'search', 0),
('AdvancedSearchFormTemplate', '$advsearchform["prefix"] = "\r\n<form class=''nc_search'' method=''GET''>\r\n<table class=''nc_search_extra_form''>";\r\n\r\n$advsearchform["input"] = "\r\n    <tr>\r\n        <td>\r\n            <div class=''param''>\r\n                <div class=''caption''>" . NETCAT_MODULE_SEARCH_FIND_CAPTION . ":</div>\r\n            </div>\r\n        </td>\r\n\r\n        <td>\r\n            <div class=''input''>\r\n                <input type=''text'' name=''search_query'' value=''$inputvalue'' />\r\n            </div>\r\n        </td>\r\n    </tr>";\r\n\r\n$advsearchform["exclude"] = "\r\n    <tr>\r\n        <td>\r\n            <div class=''param''>\r\n                <div class=''caption''>" . NETCAT_MODULE_SEARCH_EXCLUDE_CAPTION . ":</div>\r\n            </div>\r\n        </td>\r\n\r\n        <td>\r\n            <div class=''input''>\r\n                <input type=''text'' name=''search_query_exclude'' value='''' />\r\n            </div>\r\n        </td>\r\n    </tr>";\r\n\r\n$advsearchform["field"] = "\r\n    <tr>\r\n        <td>\r\n            <div class=''param''>\r\n                <div class=''caption''>" . NETCAT_MODULE_SEARCH_FIELD_CAPTION . ":</div>\r\n            </div>\r\n        </td>\r\n\r\n        <td>\r\n            <div>\r\n                <div>\r\n                    <input type=''radio'' name=''field'' value='''' checked=''checked'' id=''nc_search_field_any'' />\r\n                    " . NETCAT_MODULE_SEARCH_FIELD_ANY . "\r\n                </div>\r\n\r\n                <div>\r\n                   <input type=''radio'' name=''field'' value=''title'' id=''nc_search_field_title'' />\r\n                   " . NETCAT_MODULE_SEARCH_FIELD_TITLE . "\r\n               </div>\r\n           </div>\r\n       </td>\r\n   </tr>";\r\n\r\n$advsearchform["interval"] = "\r\n    <tr>\r\n        <td style=''vertical-align: top; padding-top: 15px; ''>\r\n            <div class=''param''>\r\n                <div class=''caption''>" . NETCAT_MODULE_SEARCH_TIME_CAPTION . ":</div>\r\n            </div>\r\n        </td>\r\n\r\n        <td>\r\n            <div>\r\n                <div>\r\n                    <input type=''radio'' name=''interval'' value='''' checked=''checked'' id=''nc_search_datetime_any'' />\r\n                    " . NETCAT_MODULE_SEARCH_TIME_ANY . "\r\n                </div>\r\n\r\n                <div>\r\n                    <input type=''radio'' name=''interval'' value=''1'' id=''nc_search_datetime_interval'' />\r\n                    " . NETCAT_MODULE_SEARCH_TIME_LAST . "\r\n                    <input class=''interval_value'' type=''input'' name=''intervalvalue'' value=''1'' size=''2'' />\r\n                </div>\r\n\r\n                <div>\r\n                    <select class=''interval_unit'' name=''intervalunit''>\r\n                        <option value=''hour''>" . NETCAT_MODULE_SEARCH_TIME_LAST_HOURS . "</option>\r\n                        <option value=''day''>" . NETCAT_MODULE_SEARCH_TIME_LAST_DAYS . "</option>\r\n                        <option value=''week''>" . NETCAT_MODULE_SEARCH_TIME_LAST_WEEKS . "</option>\r\n                        <option value=''month''>" . NETCAT_MODULE_SEARCH_TIME_LAST_MONTHS . "</option>\r\n                    </select>\r\n                </div>\r\n            </div>\r\n        </td>\r\n    </tr>";\r\n\r\n$advsearchform["suffix"] = "\r\n    <tr>\r\n        <td></td>\r\n\r\n        <td>\r\n            <div class=''submit''>\r\n                <input class=''submit'' type=''submit'' value=''" . htmlspecialchars(NETCAT_MODULE_SEARCH_SUBMIT_BUTTON_TEXT) . "'' />\r\n            </div>\r\n        </td>\r\n    </tr>\r\n</table>\r\n</form>";', 'search', 0);


