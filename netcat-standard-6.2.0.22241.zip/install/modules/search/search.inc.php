<?php

function nc_install_module_search(array $component_ids = array()) {
    $nc_core = nc_core::get_object();
    $nc_core->set_settings('ComponentID', $component_ids['netcat_module_search_result'], 'search', 0);
}