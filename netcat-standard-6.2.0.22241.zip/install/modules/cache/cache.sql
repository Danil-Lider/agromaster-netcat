--
-- Дамп данных таблицы `Module`
--

INSERT INTO `Module` (`Module_Name`, `Keyword`, `Description`, `Parameters`, `Example_URL`, `Help_URL`, `Installed`, `Number`, `Inside_Admin`, `Checked`) VALUES
('NETCAT_MODULE_CACHE', 'cache', 'NETCAT_MODULE_CACHE_DESCRIPTION', 'DEBUG_MODE=0\nEFFICIENCY_LOW=0.2\nEFFICIENCY_MID=0.7\nDEFAULT_LIFETIME=60\n', '', '/settings/modules/cache/', 1, '', 1, 0);

--
-- Структура таблицы `Cache_Audit`
--

CREATE TABLE IF NOT EXISTS `Cache_Audit` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Subdivision_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Sub_Class_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Class_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Message_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Essence` varchar(16) NOT NULL DEFAULT '',
  `Query_String` varchar(255) NOT NULL DEFAULT '',
  `Unique_String` varchar(32) NOT NULL DEFAULT '',
  `Attempt_Write` int(11) unsigned NOT NULL DEFAULT '0',
  `Attempt_Read` int(11) unsigned NOT NULL DEFAULT '0',
  `Writed` int(11) unsigned NOT NULL DEFAULT '0',
  `Readed` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Cache_Clear`
--

CREATE TABLE IF NOT EXISTS `Cache_Clear` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Subdivision_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Sub_Class_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Class_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Message_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Essence` varchar(16) NOT NULL DEFAULT '',
  `Efficiency` float unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `Cache_Settings`
--

CREATE TABLE IF NOT EXISTS `Cache_Settings` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Catalogue_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `Audit_Begin` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Audit_Time` smallint(6) unsigned NOT NULL DEFAULT '0',
  `Status_list` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Quota_list` int(11) unsigned NOT NULL DEFAULT '0',
  `Overdraft_list` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Status_full` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Quota_full` int(11) unsigned NOT NULL DEFAULT '0',
  `Overdraft_full` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Status_browse` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Quota_browse` int(11) unsigned NOT NULL DEFAULT '0',
  `Overdraft_browse` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Status_calendar` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Quota_calendar` int(11) unsigned NOT NULL DEFAULT '0',
  `Overdraft_calendar` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Status_function` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `Quota_function` int(11) unsigned NOT NULL DEFAULT '0',
  `Overdraft_function` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `IO_Interface` varchar(255) DEFAULT 'file',
  `Memcached_Host` varchar(255) DEFAULT 'localhost',
  `Memcached_Port` int(11) DEFAULT '11211',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Catalogue_ID` (`Catalogue_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------
