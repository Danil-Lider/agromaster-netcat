<?php

header('Content-Type: text/html; charset=utf-8');
header('X-Accel-Buffering: no');
session_start();

@set_time_limit(0);
@ignore_user_abort(true);
error_reporting(E_ALL);

define('INSTALL_GET_INFO_URL', 'https://netcat.ru/download/distrib/latest/info.php');
define('INSTALL_MIN_PHP_VERSION', '5.3.0');
define('INSTALL_MIN_MYSQL_VERSION', '4.1.0');
define('INSTALL_ENABLE_LOGGING', false);
define('INSTALL_DIR_CHMOD', 0755);

// скрипт без дистрибутива (архив будет скачан с netcat.ru)
$standalone_script = !is_dir(__DIR__ . '/sql');

// main NetCat folder
define('NETCAT_FOLDER', ($standalone_script ? __DIR__ : dirname(__DIR__)) . '/');
// folder that contains installation files
define('INSTALL_FILES_FOLDER', NETCAT_FOLDER . "install/");

// custom installation folder
$SUB_FOLDER = str_replace(realpath($_SERVER['DOCUMENT_ROOT']), '', rtrim(NETCAT_FOLDER, '/'));
if (strlen($SUB_FOLDER)) {
    $SUB_FOLDER = str_replace('\\', '/', $SUB_FOLDER); // Windows
}
$SUB_FOLDER = rtrim($SUB_FOLDER, '/');

if (nc_installer_post_get('pwd')) {
    $_SESSION['pwd'] = nc_installer_post_get('pwd');
}

$action = nc_installer_post_get('action');
$json = nc_installer_post_get('json');

if (!$json) {
    nc_installer_html_beg();
}
switch ($action) {
    case 0:
        echo nc_installer_html_status_bar(array("'color': '#444', 'opacity': 1", "можно приступать"));
        echo "Вас приветствует установщик системы управления сайтами <a href='https://netcat.ru/' target='_blank'>NetCat</a>.<br /><br />Сейчас я протестирую ваш сервер на совместимость с NetCat, после чего установлю систему, и вы сможете начать работу. Вы можете ознакомиться с нашими <a href='https://netcat.ru/cms/requirements/' target='_blank'>системными требованиями</a>.<br /><br />На втором шаге проверки мне потребуется доступ к базе данных MySQL.";
        echo nc_installer_html_form(1, 'Приступить к проверке');
        break;
    case 1:
        // Проверка настроек сервера: основных и дополнительных
        $php_version = phpversion();
        $log_header =
            '--------------------------------------------------' . PHP_EOL .
            'Дата ' . date("d.m.Y") . PHP_EOL .
            '--------------------------------------------------' . PHP_EOL .
            'Установка NetCat' . PHP_EOL .
            '--------------------------------------------------';
        nc_installer_log($log_header, false);

        nc_installer_log("Этап №" . $action . ": Начало проверки параметров хостинга.");
        nc_installer_log("Текущая версия PHP: " . $php_version);

        $errors = array();
        $notices = array();

        if (version_compare($php_version, INSTALL_MIN_PHP_VERSION) == '-1') {
            $errors['phpversion'] = "Версия PHP должна быть не ниже ". INSTALL_MIN_PHP_VERSION . ".";
            nc_installer_log("Ошибка: " . $errors['phpversion']);
        }

        // проверка возможности распаковки архивов
        if ($standalone_script && !nc_installer_archive_format()) {
            $errors["unzip"] = "Для установки необходимо, чтобы в PHP было включено расширение zip. " .
                "<a href='http://php.net/manual/ru/zip.installation.php' target='_blank'>Установите это расширение</a>, либо " .
                "скачайте и распакуйте на сервере <a href='https://netcat.ru/democentre/demdownload/'>полный дистрибутив системы</a>, " .
                "и перезапустите установку системы.";
            nc_installer_log("Ошибка: нет расширения zip");
        }

        // проверка значений обязательных директив в php.ini
        $arr_ini = array(
            'allow_url_fopen' => 1,
            'safe_mode' => 0,
            'short_open_tag' => 1,
            'zend.ze1_compatibility_mode' => 0
        );
        foreach ($arr_ini as $key => $value) {
            if (intval(ini_get($key)) != $value) {
                if (strtolower(ini_get($key)) != ($value ? 'on' : 'off')) {
                    echo $key . " - " . $value;
                    $errors[$key] = "Необходимо " . ($value ? "включить " : "отключить ") . "параметр " . $key . ".";
                    nc_installer_log("Ошибка: " . $errors[$key]);
                }
            }
        }
        $memory_limit_with_units = trim(ini_get('memory_limit'));
        $memory_limit_units = strtolower($memory_limit_with_units[strlen($memory_limit_with_units) - 1]);
        $memory_limit = (int)$memory_limit_with_units;
        switch($memory_limit_units) {
            case 'g':
                $memory_limit *= 1024;
            case 'm':
                $memory_limit *= 1024;
            case 'k':
                $memory_limit *= 1024;
        }
        if ($memory_limit > 0 && $memory_limit < 24 * 1024 * 1024) {
            $errors['memory_limit'] = "Необходимо увеличить параметр memory_limit.";
            nc_installer_log("Ошибка: " . $errors['memory_limit']);
        }

        // 1 необязательная директива
        if (intval(ini_get('mbstring.func_overload')) != 0) {
            $notices['mbstring.func_overload'] = "Необходимо выключить параметр mbstring.func_overload.";
            nc_installer_log("Предупреждение: " . $notices['mbstring.func_overload']);
        }

        $extensions_name = array(
            'mysqli' => 'mysqli',
            'session' => 'Session',
            'mbstring' => 'mbstring',
            'iconv' => 'iconv',
            'tokenizer' => 'Tokenizer',
            'ctype' => 'Ctype',
            'dom' => 'DOM',
            'json' => 'JSON',
            'libxml' => 'libxml',
            'simplexml' => 'SimpleXML',
            'openssl' => 'OpenSSL',
            'curl' => 'cURL',
            'gmp' => 'GMP'
        );

        // проверка наличия обязательных расширений
        $arr_ext = array('session', 'mysqli', 'mbstring', 'simplexml');
        foreach ($arr_ext as $ext) {
            if (!extension_loaded($ext)) {
                $errors[$ext] = "Не хватает расширения " . (isset($extensions_name[$ext]) ? $extensions_name[$ext] : $ext) . ".";
                nc_installer_log("Ошибка: " . $errors[$ext]);
            }
        }

        // проверка наличия "необязательных" расширений
        $arr_ext_opt = array('ctype', 'curl', 'dom', 'gd', 'iconv', 'json', 'libxml', 'openssl', 'gmp', 'tokenizer');
        foreach ($arr_ext_opt as $ext) {
            if (!extension_loaded($ext)) {
                $notices[$ext] = "Не хватает расширения " . (isset($extensions_name[$ext]) ? $extensions_name[$ext] : $ext) . ".";
                nc_installer_log("Предупреждение: " . $notices[$ext]);
            }
            else if ($ext == 'gd') {
                if (function_exists('gd_info')) {
                    $gd = gd_info();
                    preg_match('/\d/', $gd['GD Version'], $match);
                    $gd = $match[0];
                    if ($gd < 2) {
                        $notices['gd'] = "Расширения gd имеет версию ниже 2.0.0.";
                        nc_installer_log("Предупреждение: " . $notices['gd']);
                    }
                }
                else {
                    $notices['gd'] = "Не удалось выяснить версию расширения gd.";
                    nc_installer_log("Предупреждение: " . $notices['gd']);
                }
            }
        }

        $dir = dirname($_SERVER['PHP_SELF']);
        $test_dir = "testdirtestdir";
        if (!@mkdir($test_dir)) {
            $errors['mkdir'] = "Нет прав на создание директорий.";
            nc_installer_log("Ошибка: " . $errors['mkdir']);
        }
        if (!is_writable($test_dir)) {
            $errors['is_writable'] = "Нет прав на изменение директорий.";
            nc_installer_log("Ошибка: " . $errors['is_writable']);
        }
        if (!@rmdir($test_dir)) {
            $errors['rmdir'] = "Нет прав на удаление директорий.";
            nc_installer_log("Ошибка: " . $errors['rmdir']);
        }

        if (empty($errors)) {
            if (empty($notices)) {
                nc_installer_log("Этап №1: Проверка параметров завершена. Все параметры подходят.");
            }
            if (!empty($notices)) {
                nc_installer_log("Этап №1: Проверка параметров завершена.");
            }
            $result = nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': '#444', 'opacity': 1", "можно начинать"), false, array(1, 0));
            $result .= "Ваш хостинг" . (empty($notices) ? " прекрасно" : "") . " подходит для работы NetCat.
                Теперь я проверю базу данных MySQL. Введите параметры доступа к ней.
                Если вы их не знаете, обратитесь к сотруднику службы поддержки или системному администратору.
                В случае, когда вы используете обычный хостинг, эти параметры, скорее всего, были
                присланы вам по электронной почте после регистрации на сайте хостинг-провайдера.";

            if (!empty($notices)) {
                $result .= "<br /><br />Эти предупреждения нужно учесть, чтобы обеспечить корректную работу
                    системы в будущем:<br /><div style='margin: 7px 0; font-style: italic; color: orange;'>" .
                    join("<br />", $notices) . "</div>
                    Система может быть установлена, но её функциональность может быть ограничена.";
            }

            $result .= "<div class='db'>";
            $opt_html = "
            <div class='row'>
                <div class='cell'>
                    <span class='item'>Хост (host)</span><br />
                    <input type='text' name='host' id='host' value='" .
                        htmlspecialchars(nc_installer_post_get('host') ?: ini_get('mysqli.default_host') ?: 'localhost', ENT_QUOTES) .
                        "' />
                </div>
                <div class='cell'>
                    <span class='item'>Имя БД (database name)</span><br />
                    <input type='text' name='dbname' id='dbname' value='" . htmlspecialchars(nc_installer_post_get('dbname'), ENT_QUOTES) . "' />
                </div>
                <div class='cell'>
                    <span class='item'>Логин (user)</span><br />
                    <input type='text' name='user' id='user' value='" . htmlspecialchars(nc_installer_post_get('user'), ENT_QUOTES) . "' />
                </div>
                <div class='cell'>
                    <span class='item'>Пароль (password)</span><br />
                    <input type='password' name='pass' id='pass' value='" . htmlspecialchars(nc_installer_post_get('pass'), ENT_QUOTES) . "' />
                </div>
            </div>
            <p>Параметры, представленные ниже, обычно менять не нужно — если на сервере используются стандартные настройки MySQL, оставьте их без изменения:</p>
            <div class='row'>
                <div class='cell'>
                    <span class='item'>Порт (port)</span><br />
                    <input type='text' name='port' id='port' value='" . (htmlspecialchars(nc_installer_post_get('port'), ENT_QUOTES) ?: ini_get('mysqli.default_port')) . "' />
                </div>
                <div class='cell'>
                    <span class='item'>Сокет (socket)</span><br />
                    <input type='text' name='socket' id='socket' value='" . (htmlspecialchars(nc_installer_post_get('socket'), ENT_QUOTES) ?: ini_get('mysqli.default_socket')) . "' />
                </div>
            </div>";
            $result .= nc_installer_html_form(2, 'Проверить БД', $opt_html);
            $result .= "</div>";
        }
        else {
            $result = nc_installer_html_status_bar(array("'color': 'red', 'opacity': 1", "возникли проблемы!"));
            $result .= "<span style='font-style: italic; padding: 10pt; color: red;'>" . join(" ", $errors) . "</span><br /><br />
                Эти проблемы не позволяют использовать NetCat на вашем хостинге.
                Если вы не можете решить их самостоятельно, перешлите их описание
                сотруднику технической поддержки или системному администратору.
                Извините, но это зависит не от меня. Я очень надеюсь, что эти
                проблемы можно решить, и тогда установку можно будет произвести еще раз. ";
        }

        echo $result;
        break;
    case 2:
        // Проверка настроек БД
        nc_installer_log("Этап №" . $action . ": Начало проверки БД.");
        $error = "";
        $link_id = nc_installer_connect_db();
        // проверка соединения с БД
        if (!$link_id) {
            $error = "Нет соединение с указанной БД. MySQL ошибка: " . mysqli_connect_error();
            nc_installer_log($error);
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'red', 'opacity': 1", "возникли проблемы!"), false, array(1, 0));
            echo "Не удалось произвести подключение к указанной БД, возможно были указаны не все параметры подключения. Проверьте правильность и повторите попытку.";
            echo nc_installer_html_form(1, "Вернуться и повторить");
            break;
        }
        else {
            nc_installer_log("Соединение с БД успешно установлено.");
        }

        // проверка версии MySQL
        if (version_compare(mysqli_get_server_info($link_id), INSTALL_MIN_MYSQL_VERSION) == '-1') {
            $error = "Версия MySQL ниже требуемой (" . INSTALL_MIN_MYSQL_VERSION . "). Обратитесь, пожалуйста, к системному администратору или хостинг-провайдеру для решения этой проблемы.";
            nc_installer_log($error);
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'red', 'opacity': 1", "возникли проблемы!"), false, array(1, 0));
            echo $error;
            break;
        }

        // проверка прав заданного пользователя на действия в БД
        if (!nc_installer_check_user_grants()) {
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'red', 'opacity': 1", "возникли проблемы!"), false, array(1, 0));
            echo "Указанный вами пользователь не имеет прав записи в базу данных.
                Может, есть какой-то другой? Обратитесь в службу поддержки вашего
                хостинг-провайдера или к системному администратору, чтобы решить эту проблему.";
            echo nc_installer_html_form(1, 'Вернуться');
            break;
        }

        // найдены таблицы NetCat
        if (nc_installer_post_get('deltables')) {
            nc_installer_drop_netcat_tables();
        }

        if (nc_installer_get_existing_netcat_tables()) {
            $error = "В указанной БД найдены таблицы CMS NetCat.";
            nc_installer_log($error);
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'red', 'opacity': 1", "внимание!"), false, array(1, 0));
            echo "В указанной вами базе данных уже есть таблицы, которые хочет создать установщик. Хотите удалить их и продолжить установку?";
            echo nc_installer_html_form(2, 'Удалить и продолжить', "<input type='hidden' id='deltables' name='deltables' value='1' />");
            break;
        }

        nc_installer_log("Этап №" . $action . ": Проверка параметров БД успешно завершена.");
        echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': '#444', 'opacity': 1", "осталось совсем немного"), array(1, 1));
        echo nc_installer_post_get('demodistr')
                ? nc_installer_html_form(3, 'Продолжить', 'Сейчас я установлю бесплатную версию системы, которая будет работать 30 дней, после чего нужно будет приобрести полноценный вариант.<br />')
                : nc_installer_html_choice($standalone_script, $SUB_FOLDER);
        break;
    case 3:
        // Ввод настроек для установки
        nc_installer_log("Этап №" . $action . ": Настройки установки.");
        $errors = array();
        if (!nc_installer_post_get('demodistr') && !(nc_installer_post_get('code') || nc_installer_post_get('regnum'))) {
            nc_installer_log('Не выбран дистрибутив для установки или не введены данные по коммерческой версии системы.');
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "возникла проблема!"), array(1, 1));
            echo "Не выбран дистрибутив для установки или введены не все данные по коммерческой версии системы. Вернитесь и выберите какую-либо из предложенных версий системы.";
            echo nc_installer_html_form(2, 'Вернуться');
            break;
        }
        echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': '#444', 'opacity': 1", "последний вопрос"), array(1, 1));
        $settings = nc_installer_html_design() . nc_installer_html_config();
        echo "<div id='settings'>" .
                ($standalone_script
                    ? nc_installer_html_form(41, 'Скачать файлы NetCat', $settings)
                    : nc_installer_html_form(4, 'Установить NetCat', $settings)
                ) .
             "</div>";
        break;
    case 4:
        // Установка выбранной редакции
        nc_installer_log("Этап №" . $action . ": Установка дистрибутива.");
        $errors = array();

        if (!$json) {
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': '#444', 'opacity': 1", "устанавливаем систему"), array(1, 1));

            echo "Установка может занять от нескольких секунд до нескольких минут, все зависит от производительности вашего сервера.<br />
        <ul>";
        }

        $update_status_on_success = "<script>$('.timer').last().html('<span style=\'color: green;\'>готово!</span>');</script>";
        $update_status_on_error = "<script>$('.timer').last().html('<span style=\'color: red;\'>ошибка!</span>');</script>";

        try {
            if (!nc_installer_connect_db()) {
                if ($json) {
                    nc_installer_json_response('Ошибка', array('Не удалось подключиться к БД'));
                } else {
                    echo "<script>location='$SUB_FOLDER/install/';</script></body></html>";
                }
                die;
            }
            nc_installer_drop_netcat_tables();

            // (1) Создание основных таблиц системы
            if (!$json) {
                echo "<li>Разворачиваю базу данных... <span class='timer'></span></li>";
            }

            nc_installer_create_core_tables();
            if (!$json) {
                echo $update_status_on_success;
                @ob_flush(); @flush();
            }

            nc_installer_log('Распаковка базы данных прошла успешно.');
            nc_installer_update_db();

            // (2) update vars.inc.php
            nc_installer_write_varsinc($SUB_FOLDER);
            // (3) update .htaccess
            nc_installer_change_htaccess($SUB_FOLDER);

            // (4) Установка модулей
            if (!$json) {
                echo "<li>Установка модулей... <span class='timer'></span></li>";
                @ob_flush(); @flush();
            }
            nc_installer_install_modules();
            if (!$json) {
                echo $update_status_on_success;
                @ob_flush(); @flush();
            }

            // (5) Установка компонентов
            if (nc_installer_post_get('custom_system_components')) {
                if (!$json) {
                    echo "<li>Установка компонентов... <span class='timer'></span></li>";
                    @ob_flush(); @flush();
                }
                nc_installer_import_archives(glob(INSTALL_FILES_FOLDER . "components/*.tgz"));
                echo $update_status_on_success;
            }

            // (6) Скачивание готового сайта из Netcat Store, если указан параметр store_site_id
            $site_to_install = (int)nc_installer_post_get('store_site_id');
            if ($site_to_install) {
                nc_installer_init_netcat();
                /** @var nc_core $nc_core */
                global $nc_core;
                $store_request_parameters = http_build_query(array(
                    'site_id' => $site_to_install,
                    'copy_id' => $nc_core->get_copy_id(),
                    'version' => $nc_core->get_full_version_number(),
                    'edition' => $nc_core->get_edition_name(),
                    'host' => $_SERVER['HTTP_HOST'],
                    'code' => $nc_core->get_settings('Code'),
                ), null, '&');
                $site_download_url = 'https://store.netcat.ru/api/v1/site/get/?' . $store_request_parameters;
                $length = nc_installer_download($site_download_url, INSTALL_FILES_FOLDER . 'autoinstall/store_site_' . $site_to_install . '.tgz');
                if (!$length) {
                    $errors['no_site_archive'] = "Не получен архив сайта: $url";
                }
            }

            if ($json) {
                // Автоматически разворачиваемые файлы экспорта — используется в дистрибутивах
                // системы с дистрибутивом готового сайта.
                // Для запроса с json=1 выполняется на этапе 4; для обычной установки — на этапе 5
                $autoinstall_files = nc_installer_get_autoinstall_files();
                if ($autoinstall_files) {
                    nc_installer_import_archives($autoinstall_files);
                }

                nc_installer_json_response('Произведена установка системы', $errors);
            } else {
                echo "</ul>";
                echo nc_installer_html_form('5', 'Завершить установку');
            }
        }
        catch (Exception $e) {
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "возникла проблема!"), array(1, 1));
            echo $update_status_on_error;
            echo "</ul>";
            echo $e->getMessage();
            nc_installer_log($e->getMessage());
            echo nc_installer_html_form(4, 'Повторить');
            if ($json) {
                nc_installer_json_response('Система не установлена', array('exception' => $e->getMessage()));
            }
        }

        break;

    case 41:
        // Загрузка выбранной редакции
        nc_installer_log("Этап №" . $action . ": Загрузка и распаковка выбранной редакции.");
        $errors = array();

        if (!nc_installer_check_perm(NETCAT_FOLDER)) {
            nc_installer_log('У директории для установки не хватает прав на запись файлов');
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "возникла проблема!"), array(1, 1));
            echo "У директории для установки не хватает прав на запись файлов. Проставьте права 777 на директорию установки и повторите установку";
            echo nc_installer_html_form(41, 'Повторить');
            break;
        }

        if (!nc_installer_check_domain('netcat.ru')) {
            $errors['rmdir'] = "Нет соединения с netcat.ru.";
            nc_installer_log($errors['rmdir']);
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "возникла проблема!"), array(1, 1));
            echo $errors['rmdir'] . " Установка системы невозможна.";
            break;
        }

        // найдены файлы NetCat
        $delfiles = nc_installer_post_get('delfiles');
        if ($delfiles) {
            $catch_nc_files = nc_installer_existing_files(NETCAT_FOLDER);
            foreach ($catch_nc_files as $item) {
                $file = NETCAT_FOLDER . $item;
                if (is_dir($file)) {
                    nc_installer_clear_dir($file);
                    nc_installer_log('Папка ' . $file . ' была удалена');
                }
                else {
                    @unlink($file);
                    nc_installer_log('Файл ' . $file . ' был удалён');
                }
            }
        }

        if (nc_installer_existing_files(NETCAT_FOLDER)) {
            nc_installer_log('В директории для установки уже содержатся файлы или папки, которые хочет установить NetCat');
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "внимание!"), array(1, 1));
            echo "В указанной Вами директории уже есть файлы, которые хочет создать установщик. Хотите удалить их и продолжить установку?";
            echo nc_installer_html_form(41, 'Удалить и продолжить', "<input type='hidden' id='delfiles' name='delfiles' value='1' />");
            break;
        }
        echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': '#000', 'opacity': 1", "в процессе"), array(1, 1));
        @ob_flush();
        @flush();
        echo "Установка может занять от нескольких секунд до нескольких минут, все зависит от скорости вашего соединения с Интернетом.<br />
		<ul>";
        @ob_flush();
        @flush();
        $notify['success0'] = "<script>$('#timer0').html('<span style=\'color: green;\'>готово!</span>');</script>";
        $notify['error0'] = "<script>$('#timer0').html('<span style=\'color: red;\'>ошибка!</span>');</script>";
        $notify['success1'] = "<script>$('#timer1').html('<span style=\'color: green;\'>готово!</span>');</script>";
        $notify['error1'] = "<script>$('#timer1').html('<span style=\'color: red;\'>ошибка!</span>');</script>";
        $notify['success2'] = "<script>$('#timer2').html('<span style=\'color: green;\'>готово!</span>');</script>";
        $notify['error2'] = "<script>$('#timer2').html('<span style=\'color: red;\'>ошибка!</span>');</script>";

        echo "<li>Скачиваю... <span id='timer0'></span></li>";
        @ob_flush();
        @flush();

        $get_info_params = array(
            'format' => nc_installer_archive_format(),
        );
        nc_installer_log('Выбрана компрессия ' . $get_info_params['format']);

        if (nc_installer_post_get('demodistr') && !(nc_installer_post_get('code') || nc_installer_post_get('regnum'))) {
            $is_trial = true;
            $get_info_params['edition'] = nc_installer_post_get('demodistr');
        }
        else {
            $is_trial = false;
            $get_info_params['regnum'] = nc_installer_post_get('regnum');
            $get_info_params['code'] = nc_installer_post_get('code');
        }

        $file_info = json_decode(file_get_contents(INSTALL_GET_INFO_URL . '?' . http_build_query($get_info_params, null, '&')), true);
        if (!$file_info || $file_info['error'] || !$file_info['url'] || !$file_info['md5']) {
            if (!$file_info) {
                $errors['load'] = 'Не получен ответ с сервера.';
                $message['load'] = 'Не получен ответ с сервера. Пожалуйста, повторите установку.';
            }
            elseif ($is_trial) {
                $errors['load'] = 'Выбрана некорректная редакция системы.';
                $message['load'] = 'Выбрана редакция системы, для которой отсутствуют файлы установки. Пожалуйста, повторите установку, выбрав другую редакцию.';
            }
            else {
                $errors['load'] = 'Регистрационный код и/или ключ активации неверные.';
                $message['load'] = 'Не существует такого сочетания лицензии и ключа активации. Проверьте правильность введённых вами данных и повторите установку.';
            }

            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "возникла проблема!"), array(1, 1));
            nc_installer_log($errors['load']);
            echo "</ul>";
            echo $message['load'];
            echo nc_installer_html_form(2, 'Повторить');
            break;
        }
        else {
            $filename = basename($file_info['url']);
            $file_md5 = $file_info['md5'];
            nc_installer_download($file_info['url'], NETCAT_FOLDER . $filename);
        }

        if (md5_file(NETCAT_FOLDER . $filename) == $file_md5) {
            echo $notify['success0'];
            @ob_flush();
            @flush();
            $errors['file_md5'] = "Архив с дистрибутивом успешно скачан.";
            nc_installer_log($errors['file_md5']);
        }
        else {
            echo $notify['error0'];
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "возникла проблема!"), array(1, 1));
            $errors['file_md5'] = "При скачивании архива возникла проблема. Контрольная сумма скачанного архива не совпадает с оригинальной. Попробуйте повторить процедуру установки снова.";
            nc_installer_log($errors['file_md5']);
            $message['file_md5'] = $errors['file_md5'];
            echo "</ul>";
            echo $message['file_md5'];
            echo nc_installer_html_form(41, 'Повторить');
            break;
        }

        echo "<li>Распаковываю архив... <span id='timer1'></span></li>";
        @ob_flush();
        @flush();
        nc_installer_log('Файл для распаковки: ' . $filename);
        nc_installer_log('Директория для распаковки: ' . NETCAT_FOLDER);
        if (nc_installer_unzip($filename, NETCAT_FOLDER)) {
            echo $notify['success1'];
            @ob_flush();
            @flush();
            $errors['unzip'] = "Архив " . $filename . " был успешно распакован.";
            nc_installer_log($errors['unzip']);
            unlink($filename);
        }
        else {
            echo $notify['error1'];
            echo nc_installer_html_status_bar(array("'color': 'green', 'opacity': 1", "всё отлично!"), array("'color': 'green', 'opacity': 1", "всё прекрасно!"), array("'color': 'red', 'opacity': 1", "возникла проблема!"), array(1, 1));
            $errors['unzip'] = "Ошибка распаковки файла " . $filename . ". Проверьте, есть ли права на запись файлов в директории архива, есть ли свободное место на жестком диске и не поврежден ли архив.";
            nc_installer_log($errors['unzip']);
            $message['upzip'] = $errors['unzip'];
            echo "</ul>";
            echo $message['upzip'];
            echo nc_installer_html_form(41, 'Повторить');
            break;
        }

        echo nc_installer_html_form('4', 'Установить NetCat');
        break;

    case 5:
        if (!$json) {
            // Автоматически разворачиваемые файлы экспорта — используется в дистрибутивах
            // системы с дистрибутивом готового сайта.
            // Для запроса с json=1 выполняется на этапе 4; для обычной установки — на этапе 5
            $autoinstall_files = nc_installer_get_autoinstall_files();
            if ($autoinstall_files) {
                echo "<li>Установка сайта... <span class='timer'></span></li>";
                @ob_flush();
                @flush();
                nc_installer_import_archives($autoinstall_files);
                echo $update_status_on_success;
                @ob_flush();
                @flush();
            }
        }

        // NetCat установлен

        $site_url = $_SERVER['HTTP_HOST'] . $SUB_FOLDER . '/';
        $site_url = preg_replace('#/{2,}$#', '/', $site_url);

        $result = nc_installer_html_status_bar(
            array("'color': 'green', 'opacity': 1", "всё отлично!"),
            array("'color': 'green', 'opacity': 1", "всё прекрасно!"),
            array("'color': 'green', 'opacity': 1", "готово!"),
            array(1, 1)
        );
        $is_mail_sent = nc_installer_mail_user($site_url);
        $email = nc_installer_post_get('email');
        $login = $email ?: nc_installer_get_default_email();
        if ($email) {
            $email = htmlspecialchars($email, ENT_QUOTES);
        }
        $result .= "Ура, NetCat установлен, теперь вы можете начать работу. Смотрите:<br />" .
            "<ul>" .
            "<li>Вход в систему администрирования: <a href='//" . $site_url . "netcat/admin/' target='_blank'>http://" . $site_url . "netcat/admin/</a></li>" .
            "<li>Установка готового сайта из <a href='http://store.netcat.ru/' target='_blank'>магазина</a>: <a href='//" . $site_url . "netcat/admin/#site.add' target='_blank'>http://" . $site_url . "netcat/admin/#site.add</a></li>" .
            "<li>Вход на сайт в режиме редактирования: <a href='//" . $site_url . "netcat/' target='_blank'>http://" . $site_url . "netcat/</a></li>" .
            "<li>Логин для входа: <strong>$login</strong></li>" .
            "<li>Пароль: тот, который вы ввели " . ($is_mail_sent ? "(и еще он выслан на e-mail <a href='mailto:" . $email . "'>" . $email . "</a>)" : "") . "</li>" .
            "</ul>" .
            "<br />" .
            "<em style='color: red;'>Обязательно удалите папку install с сервера!</em>";
        echo $result;

        // clear session
        unset($_SESSION['pwd']);
        break;
}
if (!$json) {
    nc_installer_html_end();
}

function nc_installer_existing_files($distr_dir) {
    $nc_files = array(
        "install",
        "netcat",
        "netcat_cache",
        "netcat_dump",
        "netcat_files",
        "netcat_template",
        "netcat_trash",
        ".htaccess",
        "favicon.ico",
        "index.php",
        "vars.inc.php"
    );

    return array_intersect($nc_files, scandir($distr_dir));
}

function nc_installer_html_beg() {
    // Для оффлайн установки из архива
    $jquery = '../netcat_template/jquery/jquery.min.js';
    if (!file_exists($jquery)) {
        $jquery = '//code.jquery.com/jquery-latest.js';
    }

    echo <<<HEREDOC
<!DOCTYPE html>
<html>
<head>
    <title>Установка NetCat</title>
    <meta http-equiv="Content-Language" content="ru" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style type="text/css">
		.valid {margin-top:12px; margin-left:10px; position:absolute; font-size:13pt;}
		body {font-family: 'Segoe UI', SegoeWP, Arial, Helvetica, Verdana; background-color: white; margin:0;}
		form {margin: 0; padding: 0;}
		a {color: #1A87C2;}
		a.dashed {border-bottom:1px dashed #000; text-decoration:none; outline:none;}
		a.dashed:hover {border-bottom:none; outline:none;}
		.main {position:relative; top:50px; width:740px; display:block; left:auto; right:auto; background-color: white; color: #444; font-size:12pt; margin:0 auto; padding:30pt 30pt 20pt; border: 2px solid #1A87C2;}
		.top {font-size:30pt;}
		.support {margin-top: 30pt; font-size: 11pt; text-align: right;}
		.status_bar {font-size:16pt; padding:12pt 0 20pt; text-transform: lowercase;}
		.status_bar .pair,#arrow0,#arrow1 {float:left;}
		.status_bar #arrow0,#arrow1 {opacity:0.4; margin:0 5pt;}
		.status_bar .pair #item0,#item1,#item2 {opacity:0.4;}
		.status_bar .pair #status0,#status1,#status2 {font-size:11pt; opacity:0.4;}
		#submit_button {font-size:12pt; margin:20pt 0 0 0; padding:8px 15px; background-color: #1A87C2; color: white; text-align: center; font-family: 'Segoe UI', SegoeWP, Arial; cursor: pointer; text-transform: lowercase; border: none;}
		.db {padding:18pt 0 0;}
		.db .row {overflow:hidden;}
		.db .row + .row {margin-top:10pt;}
		.db .cell {float:left; padding:0 10pt 0 0;}
		.db .item {font-size:10pt; font-weight:700;}
		.db input {font-size:14pt; width:115pt; margin:5pt 0 0; padding:2pt 4pt;}
		.demos {padding-left:30pt; padding-top:10pt;}
		.demos input {font-size:14pt; margin-right:7pt;}
		.demo_ttl {font-size:14pt; margin-left:-22pt;}
		.selected_tab {font-size:14pt; border-bottom:none; text-decoration:none; cursor:text;}
		.nonselected_tab {font-size:14pt; border-bottom:1pt dashed; text-decoration:none; color:blue;}
		.pwd_create {padding:20pt 0;}
		#pwd_gen {color:blue; cursor:pointer; border-bottom:1pt dashed; font-size:10pt; margin-left:7pt;}
		#pwd_show {margin:5pt 5pt 0 10pt;}
		#regnum,#code {font-size:14pt; margin-top:5pt;}
		#code {width:265pt;}
		#regnum {width:90pt;}
		.hidden {display:none;}
		#newfolder {margin-top:20pt;}
		.color_block {margin:5px 0 0 7px; padding:0;}
		.color_item {cursor:pointer; height:10px; width:20px; border:0; padding:0;}
		.layout {float:left; margin-top:10pt; text-align:center;}
		select[name=distrib], select[name=current_distrib], #setupdir {margin-top:5pt; font-size:12pt; width:265pt;}
		#setupdirname {width:265pt; font-size:14pt; margin-top:5pt;}
		ul {padding-top:20pt; margin:0;}
		.select,.email_form,.regnum_block {margin-bottom:20pt;}
		.demo_def,.pwd_show_block {font-size:10pt;}
		#pwd_field,#pwd_field_clear,#email_field {font-size:14pt; width:265pt; margin:5pt 0 0;}
    </style>
    <script src="{$jquery}"></script>
</head>
<body>
    <div class='main'>
            <div class='top'>Установка CMS NetCat</div>
            <div class='status_bar'>
                <div class='pair'>
                    <span id='item0'>Проверка хостинга</span><br />
                    <span id='status0'>можно приступать</span>
                </div>
                <div id='arrow0'>&rarr;</div>
                <div class='pair'>
                    <span id='item1' >Проверка базы данных</span><br />
                    <span id='status1' >еще не производилась</span>
                </div>
                <div id='arrow1'>&rarr;</div>
                <div class='pair'>
                    <span id='item2' >Установка NetCat</span><br />
                    <span id='status2'>сначала все проверим</span>
                </div>
                <div style='clear:both;'></div>
            </div>
            <div id='content'>
HEREDOC;
}

function nc_installer_html_end() {
    $html = "</div>
    <div class='support'>Служба технической поддержки и по работе с клиентами: +7 (495) 783-60-21, <a href='mailto:support@netcat.ru'>support@netcat.ru</a></div>
    </div>
<script>
    $(function() {

	$('#show_block1').click(function(){
		if ($('#show_block1').is('.nonselected_tab')) {
			$('#show_block1').removeClass('nonselected_tab');
			$('#show_block1').addClass('selected_tab');

			$('#show_block2').removeClass('selected_tab');
			$('#show_block2').addClass('nonselected_tab');

			$('#block1').removeClass('hidden');
			$('#block2').addClass('hidden');

			$('#code').val('');
			$('#code_valid').html('');
			$('#regnum').val('');
			$('#regnum_valid').html('');
		}

		return false;
	});

	$('#show_block2').click(function() {
		if ($('#show_block2').is('.nonselected_tab')) {
			$('#show_block2').removeClass('nonselected_tab');
			$('#show_block2').addClass('selected_tab');

			$('#show_block1').removeClass('selected_tab');
			$('#show_block1').addClass('nonselected_tab');

			$('#block2').removeClass('hidden');
			$('#block1').addClass('hidden');

			for(var i = 1; i < 6; i++) {
			$('#db' + i).attr('checked', null);
			}
		}

		return false;
	});

        $('#pwd_gen').click( function() {
          var sign = ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f',
          'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 'Q', 'W',
          'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'A', 'S', 'D', 'F', 'G', 'H',
          'J', 'K', 'L', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '1', '2', '3', '4',
          '5', '6', '7', '8', '9', '0'];
          var result = '';
          var end = sign.length - 1;
          for(var i = 0; i < 10; i++) {
            result += sign[Math.floor(Math.random()*end)];
          }
          $('#pwd_field').val(result);
          return false;
        });

        $('#pwd_show').change( function() {
          nc_show_hide_pwd('#pwd_field', this.checked);
        });

        $('#email_field').focusout(function(){
          nc_check_email($('#email_field').val(), '#email_field');
        });

        $('#regnum').focusout(function(){
          if ($('#regnum').val()) {
            $('#regnum_valid').removeClass('hidden');
            nc_is_valid_regnum($('#regnum').val());
          }
        });

        $('#code').focusout(function(){
          if ($('#code').val()) {
            $('#code_valid').removeClass('hidden');
            nc_is_valid_key($('#code').val());
          }
        });

        $('#code').focus(function(){
          $('#code_valid').addClass('hidden');
        });

        $('#regnum').focus(function(){
          $('#regnum_valid').addClass('hidden');
        });
    });

    function nc_show_hide_pwd(id, checked) {
        checked ? nc_show_pwd(id) : nc_hide_pwd(id);
    }

    function nc_show_pwd(id) {
        var id_clear = id+'_clear';
        $(id_clear).removeClass('hidden');
        $(id).addClass('hidden');
        $(id_clear).val($(id).val());
    }

    function nc_hide_pwd(id) {
      var id_clear = id+'_clear';
      $(id).removeClass('hidden');
      $(id_clear).addClass('hidden');
      $(id).val($(id_clear).val());
    }

    function nc_check_email(value, id) {
        var email = value;
        if(email != '') {
          if (nc_is_valid_email(email) == false) {
            $('#email_valid').html('<span style=\'color: red;\'>не похоже на настоящий email</span>');
          }
          else {
            $('#email_valid').html('');
          }
        }
        else {
          $('#email_valid').html('');
        }
    }

    function nc_is_valid_email(emailAddress) {
        var pattern=/[0-9a-z_]+@[0-9a-z_]+\.[a-z]{2,5}/i;
        return pattern.test(emailAddress);
    }

    function nc_write_message(result, id) {
        return result ? nc_write_good(id) : nc_write_bad(id);
    }

    function nc_write_good(id) {
      $('#' + id).html('<span style=\'color: green;\'>похоже на настоящий</span>');
      return true;
    }

    function nc_write_bad(id) {
      $('#' + id).html('<span style=\'color: red;\'>не похоже на настоящий</span>');
      return false;
    }

    function nc_is_valid_regnum(regnum) {
        return nc_write_message(/^[0-9]{8}$/.test(regnum), 'regnum_valid');
    }

    function nc_is_valid_key(code) {
        return nc_write_message(/^([\dA-Z]{5}-){4}[\dA-Z]{4}$/.test(code), 'code_valid');
    }

</script>
</body>
</html>";
    echo $html;
}

function nc_installer_html_status_bar($array1 = array(), $array2 = array(), $array3 = array(), $array4 = array()) {
    return "<script>
    " . (!empty($array1) && $array1[0] ? "$('#item0, #status0').css({" . $array1[0] . "});" : "") . "
    " . (!empty($array1) && $array1[1] ? "$('#status0').html('" . $array1[1] . "');" : "") . "
    " . (!empty($array4) && $array4[0] ? "$('#arrow0').css({'color': '#444', 'opacity': 1});" : "") . "
    " . (!empty($array2) && $array2[0] ? "$('#item1, #status1').css({" . $array2[0] . "});" : "") . "
    " . (!empty($array2) && $array2[1] ? "$('#status1').html('" . $array2[1] . "');" : "") . "
    " . (!empty($array4) && $array4[1] ? "$('#arrow1').css({'color': '#444', 'opacity': 1});" : "") . "
    " . (!empty($array3) && $array3[0] ? "$('#item2, #status2').css({" . $array3[0] . "});" : "") . "
    " . (!empty($array3) && $array3[1] ? "$('#status2').html('" . $array3[1] . "');" : "") . "
    </script>";
}

function nc_installer_html_form($action, $button, $opt = '') {
    $html = "<form method='post' action='" . $_SERVER['SCRIPT_NAME'] . "' name='main_form' id='main_form' >";
    $html .= "<input type='hidden' name='action' id='action' value='" . htmlspecialchars($action, ENT_QUOTES) . "' />";
    $params = array(
        "host", "user", "dbname", "pass", "port", "socket", "pwd", "email",
        "demodistr", "regnum", "code",
        "custom_system_classificators", "custom_system_components", "custom_system_widgets",
    );
    foreach ($params as $param) {
        $html .= "<input type='hidden' name='" . $param . "' value='" .
                 htmlspecialchars(nc_installer_post_get($param), ENT_QUOTES) .
                 "' />";
    }
    $html .= $opt . "<input type='submit' name='submit_button' id='submit_button' value='" .
             htmlspecialchars($button, ENT_QUOTES) .
             "' /></form>";

    return $html;
}

function nc_installer_query($query) {
    global $link_id;
    $res = mysqli_query($link_id, $query);
    if (mysqli_error($link_id)) {
        print mysqli_error($link_id) . "\n<br /><strong>Query:</strong> <pre>$query</pre>\n";
        return false;
    }
    else {
        return $res;
    }
}

function nc_installer_post_get($param) {
    if (empty($_GET) && empty($_POST)) {
        return false;
    }
    if ($param) {
        return array_key_exists($param, $_GET) ? $_GET[$param] : (array_key_exists($param, $_POST) ? $_POST[$param] : "");
    }
    else {
        return array_merge($_POST, $_GET);
    }
}

function nc_installer_connect_db() {
    global $link_id;
    $host = nc_installer_post_get('host');
    $user = nc_installer_post_get('user');
    $pass = nc_installer_post_get('pass');
    $dbname = nc_installer_post_get('dbname');
    $port = nc_installer_post_get('port') ?: ini_get('mysqli.default_port');
    $socket = nc_installer_post_get('socket') ?: ini_get('mysqli.default_socket');

    $link_id = @mysqli_connect($host, $user, $pass, $dbname, $port, $socket);
    if (!$link_id) {
        return false;
    }

    if (!mysqli_select_db($link_id, $dbname)) {
        nc_installer_log('Не удалось произвести подключение к указанной БД');
        return false;
    }
    mysqli_query($link_id, "SET NAMES 'utf8'");
    mysqli_query($link_id, "ALTER DATABASE `" . $dbname . "` DEFAULT CHARACTER SET 'utf8'");

    return $link_id;
}

function nc_installer_check_user_grants() {
    $sql_create = "CREATE TABLE test_table (ID int(11) NOT NULL, FIO varchar(128) NOT NULL)";
    $sql_drop = "DROP TABLE `test_table`";
    $error = false;
    if (!(nc_installer_query($sql_create) && nc_installer_query($sql_drop))) {
        $error = true;
    }
    if ($error) {
        return false;
    }
    else {
        return true;
    }
}

function nc_installer_html_form_demo($standalone_inst) {

    if (!$standalone_inst) {
        $html = "<div style='display: none; '>
			Выберите редакцию NetCat:";
        $html .= "<input type='hidden' name='demodistr' value='extra' id='extra' />";
        $html .= "</div>";
    }
    else {
        $html = "<div id='block1'>
			Выберите редакцию NetCat:";
        $html .= nc_installer_html_form_demo_item('Standard', 'standard', 'rgb(38, 144, 207)', 'Подходит для несложных веб-проектов, сайтов-визиток.');
        $html .= nc_installer_html_form_demo_item('Standard+', 'standard-plus', 'rgb(23, 81, 115)', 'Подходит для корпоративного сайта с личным кабинетом клиента.');
        $html .= nc_installer_html_form_demo_item('Business', 'business', 'rgb(253, 204, 109)', 'Оптимальный вариант для небольшого интернет-магазина или корпоративного сайта.');
        $html .= nc_installer_html_form_demo_item('Corporate', 'corporate', 'rgb(82, 95, 103)', 'Отлично подходит для больших сложных корпоративных сайтов.');
        $html .= nc_installer_html_form_demo_item('E-commerce', 'ecommerce', 'rgb(240, 125, 34)', 'Прекрасный выбор для больших и функционально сложных интернет-магазинов и торговых систем.');
        $html .= nc_installer_html_form_demo_item('Extra', 'extra', 'rgb(204, 51, 0);', 'Самая полная редакция NetCat, для крупных порталов и нестандартных веб-проектов.');
        $html .= "</div>";
    }

    return $html;
}

function nc_installer_html_form_demo_item($name, $id, $color, $description) {
    $html = "
			<div class='demos'>
	  		<div class='demo_ttl' style='color:" . $color . ";'>
	  			<input type='radio' name='demodistr' value='" . $id . "' id='" . $id . "' /><label for='" . $id . "'>" . $name . "</label>
	  		</div>
	  		<div class='demo_def'>" . $description . "</div>
	  	</div>";
    return $html;
}

function nc_installer_html_form_license() {
    $html = "
        <div id='block2' class='hidden'>
        <div class='regnum_block'>
            Регистрационный номер:<br />
            <input type='text' name='regnum' id='regnum' maxlength='8' />
            <span id='regnum_valid' class='valid'></span>
        </div>
        <div class='code_block'>
            Ключ активации:<br />
            <input type='text' name='code' id='code' maxlength='28' />
            <span id='code_valid' class='valid'></span>
        </div>
      </div>";

    return $html;
}

function nc_installer_html_choice($standalone_inst, $SUB_FOLDER) {
    $html = "Сейчас я установлю и настрою систему NetCat" . ($SUB_FOLDER ? " в папке <code>$SUB_FOLDER</code>" : "") . ".
        Перед этим хотелось бы определиться, ставим ли мы демо-версию (бесплатную версию системы,
        которая будет работать 30 дней, после чего нужно будет приобрести полноценный вариант)
        или коммерческую версию (в этом случае у вас должен быть регистрационный номер и ключ активации).<br /><br />
        Сравнить редакции и приобрести NetCat вы можете
        <a href='https://netcat.ru/products/editions/compare/' target='_blank'>здесь</a>.<br /><br />
        <div class='select'>
            <a href='#' id='show_block1' class='selected_tab'>демо-версия</a>
            &nbsp;&nbsp;
            <a href='#' id='show_block2' class='nonselected_tab'>коммерческая версия</a>
        </div>";

    $html .= nc_installer_html_form(3, 'Продолжить', nc_installer_html_form_demo($standalone_inst) . nc_installer_html_form_license());

    return $html;
}

function nc_installer_html_design() {
    $result = "
        <div>
            <label>
                <input type='checkbox' id='install_options' />
                Выбрать комплектацию системы
             </label>

            <div id='custom_system_block' style='display: none; margin: 5px 0 20px 23px'>
                <div>
                    <input type='checkbox' name='custom_system_classificators' id='custom_system_classificators' value='1' checked />
                    <label for='custom_system_classificators'>Списки</label>
                </div>
                <div>
                    <input type='checkbox' name='custom_system_components' id='custom_system_components' value='1' checked />
                    <label for='custom_system_components'>Компоненты</label>
                </div>
                <div>
                    <input type='checkbox' name='custom_system_widgets' id='custom_system_widgets' value='1' checked />
                    <label for='custom_system_widgets'>Виджет-компоненты</label>
                </div>
            </div>

            <script>
            $('#install_options').change(function() {
                var options_div = $('#custom_system_block');
                if ($(this).is(':checked')) {
                    options_div.show();
                }
                else {
                    options_div.hide().find('input:checkbox').prop('checked', true);
                }
            });
            </script>

         </div>";

    return $result;
}

function nc_installer_html_config() {
    $default_email = nc_installer_get_default_email();
    $html = <<<HTML
                <div class='pwd_create'>
                    Введите пароль пользователя <strong id='login'>$default_email</strong> 
                    (если вы ввели e-mail в поле ниже, этот адрес будет использоваться для входа в систему) 
                    для входа в систему администрирования системы:<br />
                    <input type='password' name='pwd' id='pwd_field' />
                    <a href='#' id='pwd_gen' class='selected_tab'>сгенерировать пароль</a>
                    <div>
            						<input type='checkbox' name='show_pwd' value='1' id='show_pwd' />
                        <label for='show_pwd'>Показать пароль</label>
                    </div>
                </div>
                <div class='email_form'>
                    Выслать параметры доступа на e-mail:<br />
                    <input class='email' type='text' name='email' id='email_field' />
                    <span id='email_valid' class='valid'></span>
                </div>
                <script>
                    $('#show_pwd').on('click', function() {
                        $('#pwd_field').attr('type', this.checked ? 'text' : 'password');
                    });
                    $('#email_field').on('keyup input', function() {
                        function escapeHtml(str) {
                            var map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
                            return str.replace(/[&<>"']/g, function(m) { return map[m]; });
                        }
                        $('#login').html(escapeHtml(this.value) || '$default_email')
                    });
                </script>
HTML;

    return $html;
}

function nc_installer_check_domain($domain) {
    if (extension_loaded('curl')) {
        $curl_handle = curl_init($domain);
        curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl_handle, CURLOPT_HEADER, true);
        curl_setopt($curl_handle, CURLOPT_NOBODY, true);
        curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($curl_handle);
        curl_close($curl_handle);
    }
    else {
        $response = file_get_contents("http://" . $domain);
    }

    if ($response) {
        return true;
    }
    else {
        return false;
    }
}

function nc_installer_create_core_tables() {
    $installed_content = array('core', 'version');

    if (nc_installer_post_get('custom_system_classificators')) {
        $installed_content[] = 'classificators';
    }

    if (nc_installer_post_get('custom_system_widgets')) {
        $installed_content[] = 'widgets';
    }

    nc_installer_log('Выбраны для установки SQL-файлы: ' . join(', ', $installed_content));

    foreach ($installed_content as $row) {
        $file_name = $row . '.sql';
        $file = INSTALL_FILES_FOLDER . 'sql/' . $file_name;
        if (file_exists($file)) {
            if (!nc_installer_exec_sql($file)) {
                nc_installer_log('Возможно, система уже установлена: ' . $file);
                throw new nc_installer_exception('При установке базы данных возникла проблема.');
            }
        }
    }

    return true;
}

function nc_installer_update_db() {
    global $link_id;
    if (nc_installer_post_get('demodistr')) {
        $nc47976400764121497450652a10251140849b947a48ee4e73049438777a4917ba6a4 = date("Y-m-d 00:00:00", time() + 30 * 24 * 60 * 60);
        $key = "nc63968534304df688ffedc8ca2e3f59f4a26c255b010e5bc647121dca79e55017726";
        global $standalone_script;
        if ($standalone_script) {
            if ($file_data = @file_get_contents('install/index.php')) {
                preg_match("/[\'\"](nc[a-z0-9]{50,100})[\'\"]/", $file_data, $matches);
                if (isset($matches[1])) {
                    $key = $matches[1];
                }
            }
        }
        $nc66633889950dc1f73c5d27e692b9d6bea1ccf88c82dcd3a2f30e98dfade9649f8ed = sha1("Net_^^_Cat" . $nc47976400764121497450652a10251140849b947a48ee4e73049438777a4917ba6a4 . $key . substr($nc47976400764121497450652a10251140849b947a48ee4e73049438777a4917ba6a4, 7, 3));
        nc_installer_query("INSERT INTO `Settings` (`Key`, `Value`) VALUES ('InstallationID', '" . $nc66633889950dc1f73c5d27e692b9d6bea1ccf88c82dcd3a2f30e98dfade9649f8ed . "'), ('InstallationDateOut', '" . $nc47976400764121497450652a10251140849b947a48ee4e73049438777a4917ba6a4 . "')");
    }

    $sql = array(
        "UPDATE `Settings` SET `Value` = '" . mysqli_real_escape_string($link_id, nc_installer_post_get('regnum')) . "', `Module` = 'system' WHERE `Key` = 'ProductNumber'",
        "UPDATE `Settings` SET `Value` = '" . mysqli_real_escape_string($link_id, nc_installer_post_get('code')) . "', `Module` = 'system' WHERE `Key` = 'Code'",
        "UPDATE `Settings` SET `Value` = 'admin', `Module` = 'system' WHERE `Key` = 'SpamFromName'",
        "UPDATE `Settings` SET `Value` = '" . mysqli_real_escape_string($link_id, nc_installer_post_get('email')) . "', `Module` = 'system' WHERE `Key` = 'SpamFromEmail'",
        "UPDATE `Settings` SET `Value` = '" . mysqli_real_escape_string($link_id, md5(nc_installer_post_get('regnum') . srand((double)microtime() * 1000000))) . "', `Module` = 'system' WHERE `Key` = 'SecretKey'",
        "UPDATE `User`
            SET `Created` = NOW(),
                `Password` = '" . md5(isset($_SESSION['pwd']) ? $_SESSION['pwd'] : '') . "',
                `Email` = '" . mysqli_real_escape_string($link_id, nc_installer_post_get('email') ?: nc_installer_get_default_email()) . "',
                `Name` = 'admin',
                `InsideAdminAccess` = 1
          WHERE `User_ID` = 1",
        "UPDATE `Catalogue` 
            SET `Domain` = REPLACE(`Domain`, '%HOST%', '$_SERVER[HTTP_HOST]')",
    );
    foreach ($sql as $query) {
        nc_installer_query($query);
    }
}

function nc_installer_lowercase_table_names() {
    return array_map('strtolower', nc_installer_netcat_table_names());
}

function nc_installer_netcat_table_names() {
    $cattables = array('Banner_CampaignBanner', 'Banner_CampaignZone', 'Banner_Log',
        'Banner_StatsBanner', 'Banner_StatsCampaign', 'Banner_StatsReferer',
        'Banner_StatsZone', 'Catalogue', 'Class', 'Classificator', 'CronTasks',
        'Field', 'Log', 'MailTmp', 'Module', 'Module_Catalog', 'Patch', 'Permission', 'PermissionGroup', 'Module_Permission',
        'Poll_Protect', 'Redirect', 'Redirect_Group', 'Settings', 'Stats_Attendance', 'Stats_Browser',
        'Stats_IP', 'Stats_Log', 'Stats_OS', 'Stats_Popularity', 'Stats_Referer',
        'Stats_Phrases', 'Stats_Geo', 'Stats_Openstat_Counters', 'Sub_Class', 'Subdivision', 'Subscriber',
        'SystemMessage', 'System_Table', 'Template', 'Template_Partial', 'TemplateNav', 'User', 'User_Group',
        'Captchas', 'Captchas_Settings', 'Captchas_Recaptcha',
        'Stats_IP2Country', 'Widget_Class', 'Widget', 'Widget_Field', 'Block_Widget',
        'Mixin_Preset',
        /* Таблицы 3.0 */
        'Calendar_Settings', 'Classificator_BlogCommentsAccess',
        'Classificator_BlogMessagesAccess', 'Classificator_BlogPermissionGroup',
        'Tags_Data', 'Tags_Message', 'Tags_Weight',
        /* Еще таблицы */
        'Filetable', 'Forum_categories', 'Forum_forums', 'Forum_permgroup',
        'Forum_repliesXX', 'Forum_subdiv', 'Forum_subscribe', 'Forum_topicsXX',
        'Forum_usergroup', 'Links_Settings', 'Mail_Queue', 'Mail_Attachment',
        'SQLQueries', 'Trash_Data', 'Multifield',
        /* Условия выборки для областей */
        'Sub_Class_AreaCondition_Subdivision',
        'Sub_Class_AreaCondition_Subdivision_Exception',
        'Sub_Class_AreaCondition_Class',
        'Sub_Class_AreaCondition_Class_Exception',
        'Sub_Class_AreaCondition_Message',
        /* Кэш стилей компонентов*/
        'Class_StyleCache',
        /* Многоцелевой шаблон */
        'Class_Multipurpose_Template_Cache',
        /* И еще таблицы  */
        'Auth_Settings', 'Auth_UserRelation', 'Auth_ExternalAuth', 'Auth_Token', 'Auth_Pseudo', 'Auth_FailedAttempt',
        'User_OpenID', 'Session',
        'Blog_Parent', 'Blog_Subdivision',
        /* Приём платежей */
        'Classificator_PaymentSystem',
        'Classificator_PaymentRegister',
        'Payment_SystemCatalogue',
        'Payment_SystemSetting',
        'Payment_Log',
        'Payment_Invoice',
        'Payment_Receipt',
        'Payment_RegisterBill', // obsolete
        'Payment_RegisterLog',
        'Payment_Invoice_Item',

        'Component_Revisions',
        'Csv_Import_History',
        'Csv_Import_History_Ids',

        /* Интернет-магазин */
        'Netshop_CouponBatch',
        'Netshop_Coupon',
        'Netshop_Currency',
        'Netshop_DeliveryMethod',
        'Netshop_DeliveryDiscount',
        'Netshop_DeliveryPoint',
        'Netshop_DeliveryPointInterval',
        'Netshop_ImportMap',
        'Netshop_ImportSources',
        'Netshop_CartDiscount',
        'Netshop_ItemDiscount',
        'Netshop_MailTemplate',
        'Netshop_MailRule',
        'Netshop_OfficialRate',
        'Netshop_OrderDiscounts',
        'Netshop_OrderDelivery',
        'Netshop_OrderGoods',
        'Netshop_OrderIds',
        'Netshop_PaymentMethod',
        'Netshop_PriceRule',
        'Netshop_RecentGoods',
        'Netshop_FavoriteGoods',
        'Netshop_CompareGoods',
        'Netshop_StoreGoods',
        'Netshop_Stores',
        'Russianpost_Indexes', 'Russianpost_Code', 'Russianpost_Locality', 'Russianpost_District', 'Russianpost_Region',
        'Netshop_YandexBundles',
        'Netshop_YandexBundlesMap',
        'Netshop_GoogleBundles',
        'Netshop_GoogleBundlesMap',
        'Netshop_MailBundles',
        'Netshop_MailBundlesMap',
        'Netshop_ItemIndex',
        'Netshop_Exchange',
        'Netshop_ExchangeLog',

        'Classificator_ShopCurrency',
        'Classificator_ShopDeliveryService',
        'Classificator_ShopOrderSource',
        'Classificator_ShopOrderStatus',
        'Classificator_ShopUnits',
        'Classificator_RobokassaCurrency',

        /* Счета и акты */
        'Bills_Company',
        'Bills_Act',
        'Bills_Bill',
        'Classificator_BillsClientOPF',

        /* Лендинг-конструктор */
        'Landing_Page',
        'Landing_Page_Block',
        'Landing_Preset_Setting',

        /* Заявки */
        'Requests_Form_SubdivisionSetting',
        'Requests_Form_InfoblockSetting',
        'Classificator_RequestStatus',

        /* Модуль маршрутизации */
        'Routing_Route',

        /* Модуль безопасности */
        'Security_FilterLog',
        /* Модуль комментариев */
        'Comments_Count', 'Comments_Rules', 'Comments_Text', 'Comments_Settings', 'Comments_Subscribe', 'Comments_Template', 'Comments_LastVisit',
        /* Модуль кеширования */
        'Cache_Audit', 'Cache_Clear', 'Cache_Settings',
        /* Модуль форума v2 */
        'Forum_Count', 'Forum_Groups', 'Forum_Subdivisions', 'Forum_Topics', 'Classificator_ForumTopicType',
        /* Модуль подписок */
        'Subscriber_Mailer', 'Subscriber_Message', 'Subscriber_Prepared', 'Subscriber_Settings', 'Subscriber_Subscription', 'Subscriber_UserMessage', 'Subscriber_Log',
        /* Модуль логирования */
        'Logging',
        /* Минимагазин */
        'Minishop_OrderGoods', 'Documentation',
        /* Модуль поиска */
        'Search_Document', 'Search_Extension', 'Search_Field', 'Search_Log',
        'Search_Query', 'Search_Rule', 'Search_Schedule', 'Search_Stopword',
        'Search_Synonym', 'Search_Task', 'Search_Link', 'Search_LinkReferrer',
        'Search_BrokenLink',
        /* Списки для виджетов */
        'Classificator_facebook_like_action', 'Classificator_facebook_like_colorscheme', 'Classificator_facebook_like_font',
        'Classificator_facebook_like_layout', 'Classificator_twitter_follow_img', 'Classificator_vkontakte_comment_limit',
        'Classificator_vkontakte_like_name', 'Classificator_vkontakte_like_type', 'Classificator_vkontakte_link_type',
        'Classificator_whoyougle_oo', 'Classificator_yandex_dai_rub', 'Classificator_yandex_dai_rub_color',
        'Classificator_yandex_novosti', 'Classificator_yandex_novosti_data', 'Classificator_yandex_novosti_kol',
        'Classificator_yandex_novosti_lang', 'Classificator_yandex_novosti_sort',
        /* Classificator_ */
        'Classificator_Country', 'Classificator_Gallery', 'Classificator_Manufacturer', 'Classificator_Region',
        'Classificator_Sex', 'Classificator_SubscriberPeriod', 'Classificator_TypeOfData', 'Classificator_TypeOfEdit',
        'Classificator_TypeOfModeration', 'Classificator_TypeOfRight', 'Classificator_UserGroup', 'Classificator_MinishopStatus',
        'Classificator_MinishopPayment', 'Classificator_MinishopDelivery', 'Classificator_BannerSize', 'Classificator_BannerType',
        'Classificator_MiniShopCurrency', 'Classificator_MiniShopUnits', 'Classificator_MiniShopDeliveryService', 'Classificator_MiniShopOrderStatus',
        'Classificator_FrameFormat',
        'Classificator_OffersType',
        'Classificator_ContactType',

        'Wysiwyg_Panel',
        'Filter', 'FieldFilter',
        'Excursion',
        'Version', 'Version_File', 'Version_Changeset',
    );

    return $cattables;
}

function nc_installer_drop_netcat_tables() {
    $existing_tables = nc_installer_get_existing_netcat_tables();
    foreach ($existing_tables as $d_t) {
        $query = "DROP TABLE `" . $d_t . "`";
        nc_installer_query($query);
    }
}

function nc_installer_get_all_existing_tables() {
    global $link_id;
    $tables = array();
    $showt = mysqli_query($link_id, "SHOW TABLES");
    while ($row = mysqli_fetch_array($showt)) {
        $tables[] = $row[0];
    }

    return $tables;
}

function nc_installer_lower_case_table_names() {
    $res = nc_installer_query("SHOW VARIABLES LIKE 'lower_case_table_names'");
    $var = mysqli_fetch_row($res);
    return ($var[1] == 1 ? true : false);
}

function nc_installer_get_existing_netcat_tables() {
    $user_tables = nc_installer_get_all_existing_tables();
    if (nc_installer_lower_case_table_names()) {
        $tables = array_intersect(nc_installer_lowercase_table_names(), $user_tables);
        $tables = array_merge($tables, nc_installer_get_message_tables($user_tables, 1));
    }
    else {
        $tables = array_intersect(nc_installer_netcat_table_names(), $user_tables);
        $tables = array_merge($tables, nc_installer_get_message_tables($user_tables, 0));
    }

    return $tables;
}

function nc_installer_get_message_tables($user_tables, $lower_case) {
    $user_message_tables = array();
    $name = 'Message';
    if ($lower_case) {
        $name = strtolower($name);
    }
    foreach ($user_tables as $key => $value) {
        if (preg_match("/^" . $name . "[1-9][0-9]*?$/", $value)) {
            $user_message_tables[] = $value;
        }
    }
    return $user_message_tables;
}

function nc_installer_mail_user($path) {
    $mail = nc_installer_post_get('email');
    if (!preg_match('/^.+@.+\..+$/', $mail)) {
        return false;
    }
    $pwd = nc_installer_post_get('pwd');

    $login = $mail ?: nc_installer_get_default_email();

    $subject = "NetCat успешно установлен";
    $message = 'Поздравляю!

Вы успешно установили CMS NetCat на сайт http://' . $path . '.

Ваши авторизационные данные для доступа в административную часть:
— адрес: http://' . $path . 'netcat/admin
— логин: ' . $login . '
' . ($pwd ? '— пароль: ' . $pwd : '— вход в систему без пароля') . '

Спасибо, что выбрали нашу систему!

С уважением,
Скрипт Установки NetCat';

    $headers = "Content-type: text/plain; charset=UTF-8\r\n";
    $headers .= "From: info@{$_SERVER['SERVER_NAME']}\r\n";
    return @mail($mail, $subject, $message, $headers);
}

function nc_installer_log($message, $time = true) {
    if (!INSTALL_ENABLE_LOGGING) {
        return;
    }

    $message_time = "";
    if ($time) {
        $message_time = date("Y-m-d H:i:s") . ' ';
        if (substr($message, -1) != '.') {
            $message = $message . '.';
        }
    }
    $result_str = PHP_EOL . $message_time . $message;

    file_put_contents("install.log", $result_str, FILE_APPEND);
}

function nc_installer_unzip($file, $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, INSTALL_DIR_CHMOD, true);
    }
    $zip_handle = zip_open($dir . $file);
    if (is_resource($zip_handle)) {
        while ($zip_entry = zip_read($zip_handle)) {
            if ($zip_entry) {
                $zip_name = zip_entry_name($zip_entry);
                $zip_dir = dirname(zip_entry_name($zip_entry));
                $zip_size = zip_entry_filesize($zip_entry);

                if (!(file_exists($dir . $zip_dir) && is_dir($dir . $zip_dir))) {
                    mkdir($dir . $zip_dir, INSTALL_DIR_CHMOD, true);
                }

                zip_entry_open($zip_handle, $zip_entry, 'r');
                if (is_writable($dir . $zip_dir)) {
                    $fp = @fopen($dir . $zip_name, 'w');
                    if (is_resource($fp)) {
                        @fwrite($fp, zip_entry_read($zip_entry, $zip_size));
                        @fclose($fp);
                    }
                }
                else {
                    nc_installer_log('Директория не доступна для записи: ' . $dir . $zip_dir);
                }
                zip_entry_close($zip_entry);
            }
        }
        zip_close($zip_handle);
        return true;
    }
    else {
        $error = 127;
        if (nc_installer_func_enabled('exec')) {
            exec("tar -xvzf " . $dir . $file . " -C " . $dir, $output, $error);
            $error = false;
        }

        return !$error;
    }
}

function nc_installer_func_enabled($function) {
    $function = strtolower(trim($function));
    if ($function == '') {
        return false;
    }
    $dis_functions = explode(",", @ini_get("disable_functions"));
    if (!empty($dis_functions)) {
        $dis_functions = array_map('trim', array_map('strtolower', $dis_functions));
    }
    if (function_exists($function) && is_callable($function) && !in_array($function, $dis_functions)) {
        return true;
    }
    else {
        return false;
    }
}

function nc_installer_clear_dir($directory) {
    $files = scandir($directory);
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') {
            continue;
        }
        $file = $directory . '/' . $file;
        if (is_dir($file)) {
            nc_installer_clear_dir($file);
        }
        else {
            @unlink($file);
        }
    }
    @rmdir($directory);
}

function nc_installer_exec_sql($file) {
    global $link_id;
    $fp = fopen($file, "r");
    if (!$fp) {
        nc_installer_log('Не удалось открыть sql-файл: ' . $file);
        return false;
    }
    while (!feof($fp)) {
        $statement = chop(fgets($fp, 65536));
        if (strlen($statement)) {
            while (substr($statement, strlen($statement) - 1, 1) <> ";" && substr($statement, 0, 1) <> "#" && substr($statement, 0, 2) <> "--") {
                $statement .= chop(fgets($fp, 65536));
            }
            if (substr($statement, 0, 1) <> "#" && substr($statement, 0, 2) <> "--") {
                if (!nc_installer_query($statement)) {
                    nc_installer_log('Неудачное выполнение запроса в файле ' . $file . ' MySQL ошибка: ' . mysqli_error($link_id));
                }
            }
        }
    }

    fclose($fp);
    return true;
}

function nc_installer_get_varsinc($SUB_FOLDER, $MYSQL_HOST, $MYSQL_USER, $MYSQL_PASSWORD, $MYSQL_DB_NAME, $MYSQL_PORT, $MYSQL_SOCKET, $MYSQL_ENCRYPT, $AUTHORIZE_BY, $AUTHORIZATION_TYPE) {
    ob_start();
    ?>
$DOCUMENT_ROOT = rtrim( getenv("DOCUMENT_ROOT"), "/\\" );
$HTTP_HOST = getenv("HTTP_HOST");

# подпапка в которой стоит NetCat
$SUB_FOLDER = '<?= $SUB_FOLDER ?>';
# Если NetCat стоит в подпапке, то раскомментируйте следующую строчку
#$SUB_FOLDER = str_replace( str_replace("\\", "/", $DOCUMENT_ROOT), "", str_replace("\\", "/", dirname(__FILE__)) );

# установка переменных окружения
error_reporting(E_ALL & ~(E_NOTICE | E_STRICT | E_DEPRECATED));
@ini_set("session.auto_start", "0");
@ini_set("session.use_trans_sid", "0");
@ini_set("session.use_cookies", "1");
@ini_set("session.use_only_cookies", "1");
@ini_set("url_rewriter.tags", ""); // to disable trans_sid on PHP < 5.0
@ini_set('session.cookie_domain', (strpos(str_replace("www.", "", $HTTP_HOST),'.') !== false) ? str_replace("www.", "", $HTTP_HOST) : '');
@ini_set("session.gc_probability", "1");
@ini_set("session.gc_maxlifetime", "1800");
@ini_set("session.hash_bits_per_character", "5"); // PHP < 7.1.0
@ini_set("session.sid_bits_per_character", "5"); // PHP ≥ 7.1.0
@ini_set("session.sid_length", "32"); // PHP ≥ 7.1.0; максимально поддерживаемая длина SID — 32
@ini_set("mbstring.internal_encoding", "UTF-8");
@ini_set("default_charset", "UTF-8");
@ini_set("session.name", ini_get("session.hash_bits_per_character")>=5 ? "sid" : "ced");

# параметры доступа к базе данных
$MYSQL_HOST = "<?= addslashes($MYSQL_HOST) ?>";
$MYSQL_USER = "<?= addslashes($MYSQL_USER) ?>";
$MYSQL_PASSWORD = "<?= addslashes($MYSQL_PASSWORD) ?>";
$MYSQL_DB_NAME = "<?= addslashes($MYSQL_DB_NAME) ?>";
$MYSQL_PORT = "<?= addslashes($MYSQL_PORT) ?>";
$MYSQL_SOCKET = "<?= addslashes($MYSQL_SOCKET) ?>";
$MYSQL_CHARSET = "utf8";
$MYSQL_ENCRYPT = "<?= addslashes($MYSQL_ENCRYPT) ?>";

# кодировка
$NC_UNICODE = 1;
$NC_CHARSET = "utf-8";

# настройки авторизации
$AUTHORIZE_BY = "Email";
$AUTHORIZATION_TYPE = "<?= addslashes($AUTHORIZATION_TYPE) ?>"; # 'http', 'session' or 'cookie'

#разрешить вход только по https
$NC_ADMIN_HTTPS = 0;  # 0 или 1

# серверные настройки
$PHP_TYPE = "module"; # 'module' or 'cgi'
$REDIRECT_STATUS = "on"; # 'on' or 'off'

# настройки безопасности
$SECURITY_XSS_CLEAN = false;

# инструмент "Переадресация" не доступен
$NC_REDIRECT_DISABLED = 0; # 0 или 1

# не загружать устаревшие файлы и функции
$NC_DEPRECATED_DISABLED = 1; # 0 или 1

$ADMIN_LANGUAGE = "Russian"; # Язык административной части NetCat "по-умолчанию"
$FILECHMOD = 0644; # Права на файл при добавлении через систему
$DIRCHMOD = 0755; # Права на директории для закачки пользовательских файлов
$SHOW_MYSQL_ERRORS = 'off'; # Показ ошибок MySQL на страницах сайта
$ADMIN_AUTHTIME = 2592000; # Время жизни авторизации в секундах (при $AUTHORIZATION_TYPE = session, cookie)
$ADMIN_AUTHTYPE = "manual"; # Выбор типа авторизации: 'session', 'always' or 'manual'
$use_gzip_compression = false; # Для включения сжатия вывода установите true

# настройки проекта
$DOMAIN_NAME = $HTTP_HOST; # $HTTP_HOST is server environment variable

#$DOCUMENT_ROOT = "/usr/local/etc/httpd/htdocs/www";

$HTTP_IMAGES_PATH = "/images/";
$HTTP_ROOT_PATH = "/netcat/";
$HTTP_TMP_PATH = $HTTP_ROOT_PATH."tmp/";
$HTTP_FILES_PATH = "/netcat_files/";
$HTTP_DUMP_PATH = "/netcat_dump/";
$HTTP_CACHE_PATH = "/netcat_cache/";
$HTTP_TEMPLATE_PATH = "/netcat_template/";
$HTTP_TEMPLATE_CACHE_PATH = $HTTP_TEMPLATE_PATH;
$HTTP_TRASH_PATH = "/netcat_trash/";

# относительный путь в админку сайта, для ссылок
$ADMIN_PATH = $SUB_FOLDER.$HTTP_ROOT_PATH."admin/";
# относительный путь к теме админки, для изображений и .css файлов
$ADMIN_TEMPLATE = $ADMIN_PATH."skins/default/";
# полный путь к теме админки
$ADMIN_TEMPLATE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$ADMIN_TEMPLATE;

$SYSTEM_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_ROOT_PATH."system/";
$ROOT_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_ROOT_PATH;
$FILES_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_FILES_PATH;
$DUMP_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_DUMP_PATH;
$CACHE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_CACHE_PATH;
$TRASH_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_TRASH_PATH;
$INCLUDE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_ROOT_PATH."require/";
$TMP_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_TMP_PATH;
$MODULE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_ROOT_PATH."modules/";
$ADMIN_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_ROOT_PATH."admin/";
$EDIT_DOMAIN = $DOMAIN_NAME;
$DOC_DOMAIN = "netcat.ru/developers/docs";

$TEMPLATE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_TEMPLATE_PATH."template/";
$CLASS_TEMPLATE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_TEMPLATE_PATH."class/";
$WIDGET_TEMPLATE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_TEMPLATE_PATH."widget/";
$JQUERY_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_TEMPLATE_PATH."jquery/";
$MODULE_TEMPLATE_FOLDER = $DOCUMENT_ROOT.$SUB_FOLDER.$HTTP_TEMPLATE_PATH."module/";

# set include_path: require/lib folder (PEAR and other 3rd-party libraries)
set_include_path("{$INCLUDE_FOLDER}lib/");

# название разработчика, отображаемое на странице «О программе»
#$DEVELOPER_NAME = 'ООО «НетКэт»';
#$DEVELOPER_URL = 'http://www.netcat.ru/';

<?php
    $cfg_file = ob_get_clean();

    $cfg_file = '<?php' . PHP_EOL . PHP_EOL . $cfg_file;

    return $cfg_file;
}

function nc_installer_write_varsinc($custom_dir) {
    $vars_inc_path = NETCAT_FOLDER . 'vars.inc.php';
    if (!is_file($vars_inc_path)) {
        nc_installer_log('Конфигурационный файл ' . $vars_inc_path . ' не найден!');
        return false;
    }

    $cfg_file = nc_installer_get_varsinc($custom_dir, nc_installer_post_get('host'), nc_installer_post_get('user'), nc_installer_post_get('pass'), nc_installer_post_get('dbname'), nc_installer_post_get('port'), nc_installer_post_get('socket'), 'MD5', 'Login', 'cookie');

    if (is_writable($vars_inc_path)) {
        file_put_contents($vars_inc_path, $cfg_file);
        nc_installer_log('Конфигурационный файл ' . $vars_inc_path . ' записан успешно.');
        return true;
    }
    else {
        nc_installer_log('Конфигурационный файл vars.inc.php недоступен для записи. Установите нужные права на этот файл и повторите установку заново.');
        return false;
    }
}

function nc_installer_change_htaccess($custom_dir) {
    // no changes needed
    if (!$custom_dir) {
        return false;
    }

    // path to the .htaccess
    $htaccess_path = NETCAT_FOLDER . '.htaccess';
    // file not exist
    if (!is_file($htaccess_path)) {
        nc_installer_log('Управляющий файл ' . $htaccess_path . ' не найден!');
        return false;
    }

    // file content
    $htaccess = file($htaccess_path);

    // walk
    foreach ($htaccess as $num => $str) {
        if (strpos($str, 'ErrorDocument 404') === 0) {
            $htaccess[$num] = "ErrorDocument 404 " . rtrim($custom_dir, '/') . "/netcat/require/e404.php\n\r";
        }
        if (strpos($str, 'RewriteRule ^(.+)$') === 0) {
            $htaccess[$num] = "RewriteRule ^(.+)$ " . rtrim($custom_dir, '/') . "/netcat/require/e404.php?REQUEST_URI=$1 [L,QSA]\n\r";
        }
    }

    // update file content
    if (is_writable($htaccess_path)) {
        file_put_contents($htaccess_path, join('', $htaccess));
        nc_installer_log('Управляющий файл ' . $htaccess_path . ' записан успешно.');
    }
    return true;
}

function nc_installer_check_perm($dir_name) {
    $filepath = $dir_name . "n123.tmp";
    $h = @fopen($filepath, "w");
    if ($h === false) {
        $result = false;
    }
    else {
        fclose($h);
        @unlink($filepath);
        $result = true;
    }

    return $result;
}

function nc_installer_is_windows() {
    return (DIRECTORY_SEPARATOR == '\\');
}

function nc_installer_archive_format() {
    if (!nc_installer_is_windows() && nc_installer_func_enabled('exec')) {
        exec("tar --version", $output, $return_value);
        if (!$return_value) {
            return 'tgz';
        }
    }
    return function_exists('zip_open') ? 'zip' : null;
}

function nc_installer_init_netcat() {
    static $is_initialised = false;
    if (!$is_initialised) {
        require_once NETCAT_FOLDER . 'vars.inc.php';
        foreach (get_defined_vars() as $k => $v) {
            $GLOBALS[$k] = $v;
        }

        /** @var string $ROOT_FOLDER */
        global $nc_core;
        require $ROOT_FOLDER . "connect_io.php";
        foreach (get_defined_vars() as $k => $v) {
            $GLOBALS[$k] = $v;
        }

        /** @var nc_core $nc_core */
        $nc_core->modules->load_env("", false, true, true);
        require_once $nc_core->ADMIN_FOLDER . 'lang/Russian_utf8.php';
        $is_initialised = true;
    }
}

function nc_installer_import_archives(array $files) {
    nc_installer_init_netcat();
    $nc_core = nc_core::get_object();
    $results = array();

    foreach ($files as $file) {
        $key = basename($file, ".tgz");
        $import_result = $nc_core->backup->import($file, array('save_ids' => false));
        $results[$key] = $import_result['new_id'];
    }

    return $results;
}

function nc_installer_install_modules() {
    // install modules
    $module_folders = glob(INSTALL_FILES_FOLDER . 'modules/*', GLOB_ONLYDIR);

    foreach ($module_folders as $module_folder) {
        $module = basename($module_folder);

        // (1) sql
        foreach (glob("$module_folder/*.sql") as $sql_file) {
            nc_installer_exec_sql($sql_file);
        }

        // (2) components, widgets and other stuff
        $component_ids = array();
        $component_files = glob("$module_folder/*.tgz");
        if ($component_files) {
            $component_ids = nc_installer_import_archives($component_files);
        }

        // (3) .inc file
        if (file_exists("$module_folder/$module.inc.php")) {
            require "$module_folder/$module.inc.php";
            $install_function = 'nc_install_module_' . $module;
            $install_function($component_ids);
        }
    }
}

function nc_installer_get_default_email() {
    return 'admin@' . ($_SERVER['HTTP_HOST'] ?: 'example.com');
}

function nc_installer_json_response($message, $errors = array()) {
    @ob_end_clean();
    header('Content-Type: application/json');
    $status = 200;
    $data['message'] = $message;
    if ($errors) {
        $status = 500;
        $data['errors'] = $errors;
    }
    http_response_code($status);
    echo json_encode($data, 256);
    exit();
}

function nc_installer_download($url, $save_path) {
    $src = fopen($url, 'rb');
    $dst = fopen($save_path, 'wb');

    while (!feof($src)) {
        fwrite($dst, fread($src, 4096));
    }

    fclose($dst);
    fclose($src);

    $length = filesize($save_path);
    nc_installer_log("Из $url в $save_path записано $length байт");
    return $length;
}

function nc_installer_get_autoinstall_files() {
    return glob(INSTALL_FILES_FOLDER . '/autoinstall/*.{tgz,gz,tar}', GLOB_BRACE);
}

class nc_installer_exception extends Exception {}
