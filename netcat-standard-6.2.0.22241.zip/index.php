<?php

$NETCAT_FOLDER = realpath(dirname(__FILE__)) . DIRECTORY_SEPARATOR;
include_once $NETCAT_FOLDER . "vars.inc.php";
require $INCLUDE_FOLDER . "e404.php";