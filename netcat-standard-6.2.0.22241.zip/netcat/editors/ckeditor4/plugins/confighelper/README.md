confighelper
============

Configuration Helper + HTML5 placeholder for CKEditor.
See docs/install.html for full details and install instructions
