<?php
if (!class_exists('nc_core')) {
    die;
}
?>

<div id='nc_modal_status'>
    <div id='nc_error'>
        <?=$error?>
    </div>
</div>