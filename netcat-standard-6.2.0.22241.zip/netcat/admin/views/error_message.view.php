<?php
if (!class_exists('nc_core')) {
    die;
}
?>

<?= $ui->alert->error($message) ?>