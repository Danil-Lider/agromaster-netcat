<?php

class nc_patch_installer_exception extends nc_tgz_installer_exception {
}