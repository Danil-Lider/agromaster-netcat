<?php

/**
 *
 */
class nc_record_exception extends Exception {
}