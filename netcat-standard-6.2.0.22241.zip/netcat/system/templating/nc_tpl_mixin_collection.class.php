<?php

class nc_tpl_mixin_collection extends nc_record_collection {
    protected $items_class = 'nc_tpl_mixin';
    protected $index_property = 'keyword';
}