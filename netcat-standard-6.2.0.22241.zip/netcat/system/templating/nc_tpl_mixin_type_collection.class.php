<?php

class nc_tpl_mixin_type_collection extends nc_record_collection {
    protected $items_class = 'nc_tpl_mixin_type';
    protected $index_property = 'type';
}