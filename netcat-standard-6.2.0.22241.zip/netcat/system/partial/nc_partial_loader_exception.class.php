<?php

class nc_partial_loader_exception extends Exception {
}