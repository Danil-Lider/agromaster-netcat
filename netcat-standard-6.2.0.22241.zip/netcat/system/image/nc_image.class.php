<?php

class nc_image {
    const PROVIDER_ICON = 'icon';
    const PROVIDER_UPLOAD = 'upload';
    const PROVIDER_WEB = 'web';
}