<?php

/**
 * Класс для реализации поля типа "Произвольный Файл"
 */
class nc_a2f_field_file_any extends nc_a2f_field_file {

}
