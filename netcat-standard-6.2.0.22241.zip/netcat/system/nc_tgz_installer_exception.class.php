<?php

class nc_tgz_installer_exception extends Exception {
}