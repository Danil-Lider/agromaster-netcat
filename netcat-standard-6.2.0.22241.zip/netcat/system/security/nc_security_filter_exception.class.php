<?php

/**
 *
 */
class nc_security_filter_exception extends Exception {
}